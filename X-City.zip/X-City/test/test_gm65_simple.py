#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GM65扫码枪串口通信简单测试脚本
"""

import serial
import time
from serial.tools import list_ports

def test_gm65_serial():
    """测试GM65扫码枪串口通信"""
    print("开始测试GM65扫码枪串口通信")
    
    # 查找GM65扫码枪虚拟串口
    ports = list_ports.comports()
    print(f"检测到 {len(ports)} 个串行端口")
    
    # 显示所有端口信息
    for port in ports:
        print(f"端口信息：设备={port.device}, 描述={port.description}, 制造商={port.manufacturer}")
    
    # 查找GM65扫码枪虚拟串口
    gm65_port = None
    for port in ports:
        description = port.description.lower() if port.description else ""
        device_name = port.device.lower()
        
        if any(keyword in description or keyword in device_name 
               for keyword in ['usbserial', 'usbmodem', 'virtual', 'acm', 'serial']):
            gm65_port = port.device
            print(f"找到GM65扫码枪虚拟串口：{gm65_port}")
            break
    
    if gm65_port:
        try:
            # 配置GM65串口参数
            ser = serial.Serial(
                port=gm65_port,
                baudrate=9600,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.1
            )
            
            print(f"成功连接到GM65扫码枪串口：{gm65_port} (9600波特率)")
            print("请扫描条形码进行测试...")
            print("按 Ctrl+C 退出测试")
            
            # 测试读取数据
            serial_buffer = ""
            while True:
                if ser.in_waiting > 0:
                    data = ser.read(ser.in_waiting).decode('utf-8', errors='ignore')
                    if data:
                        serial_buffer += data
                        print(f'缓冲区数据：{repr(serial_buffer)}')
                        
                        # 处理完整的扫码数据
                        if '\r' in serial_buffer or '\n' in serial_buffer:
                            lines = serial_buffer.replace('\r\n', '\n').split('\n')
                            for line in lines[:-1]:
                                line = line.strip()
                                if line:
                                    print(f'识别到完整的条形码：{line}')
                            serial_buffer = lines[-1]
                time.sleep(0.1)
        except KeyboardInterrupt:
            print('\n测试结束')
            ser.close()
        except Exception as e:
            print(f'测试出错：{str(e)}')
    else:
        print('未找到GM65扫码枪虚拟串口')

if __name__ == "__main__":
    test_gm65_serial()