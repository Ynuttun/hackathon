#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
扫码枪测试脚本
"""

import sys
import time
import serial
from serial.tools import list_ports

def test_serial_ports():
    """测试可用的串行端口"""
    print("=== 测试可用的串行端口 ===")
    
    try:
        # 获取所有可用的串行端口
        ports = list_ports.comports()
        print(f"找到 {len(ports)} 个串行端口")
        
        for port in ports:
            print(f"\n端口: {port.device}")
            print(f"  描述: {port.description}")
            print(f"  制造商: {port.manufacturer}")
            print(f"  产品ID: {port.product}")
            print(f"  供应商ID: {port.vid}")
            print(f"  产品ID: {port.pid}")
            
        # 查找GM65扫码枪端口
        gm65_ports = []
        for port in ports:
            # 检查端口描述或设备名称是否包含GM65相关信息
            if port.device.lower() in ['usbmodem', 'usbserial'] or 'gm65' in port.description.lower() or 'barcode' in port.description.lower() or 'scanner' in port.description.lower():
                gm65_ports.append(port)
        
        print(f"\n找到 {len(gm65_ports)} 个可能的GM65扫码枪端口")
        for port in gm65_ports:
            print(f"  - {port.device}: {port.description}")
        
        return gm65_ports
    except Exception as e:
        print(f"获取串行端口失败: {e}")
        return []

def test_serial_connection(port_name):
    """测试与特定串行端口的连接"""
    print(f"\n=== 测试与端口 {port_name} 的连接 ===")
    
    try:
        # 尝试连接到串行端口
        ser = serial.Serial(
            port=port_name,
            baudrate=9600,
            timeout=1,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS
        )
        
        print(f"✓ 成功连接到端口 {port_name}")
        print(f"  波特率: {ser.baudrate}")
        print(f"  数据位: {ser.bytesize}")
        print(f"  停止位: {ser.stopbits}")
        print(f"  奇偶校验: {ser.parity}")
        
        # 测试读取数据
        print("\n等待扫码枪数据...")
        print("请使用扫码枪扫描二维码或条形码")
        print("按Ctrl+C退出")
        
        start_time = time.time()
        while time.time() - start_time < 10:  # 等待10秒
            try:
                # 读取可用数据
                if ser.in_waiting > 0:
                    data = ser.read_all().decode('utf-8', errors='ignore')
                    if data:
                        cleaned_data = data.replace('\n', '').replace('\r', '').strip()
                        print(f"\n✓ 读取到数据: {repr(data)}")
                        print(f"  原始数据: {data}")
                        print(f"  清理后: {cleaned_data}")
                        
                        # 重置超时计时器
                        start_time = time.time()
                time.sleep(0.1)
            except KeyboardInterrupt:
                print("\n用户中断")
                break
        
        ser.close()
        print(f"\n✓ 已关闭端口 {port_name}")
        return True
    except serial.SerialException as e:
        print(f"✗ 连接端口 {port_name} 失败: {e}")
        return False
    except Exception as e:
        print(f"✗ 测试端口 {port_name} 时发生未知错误: {e}")
        return False

def main():
    """主函数"""
    print("GM65扫码枪测试工具")
    print("=" * 50)
    
    # 测试可用的串行端口
    gm65_ports = test_serial_ports()
    
    # 专门测试USBKey Module端口，这很可能是GM65扫码枪
    print("\n=== 专门测试USBKey Module端口 ===")
    usbkey_port = None
    ports = list_ports.comports()
    for port in ports:
        if "USBKey Module" in port.description:
            usbkey_port = port.device
            break
    
    if usbkey_port:
        test_serial_connection(usbkey_port)
    elif gm65_ports:
        # 如果找到GM65扫码枪端口，测试连接
        # 测试第一个找到的GM65端口
        test_serial_connection(gm65_ports[0].device)
    else:
        # 如果没有找到GM65端口，尝试测试所有可用端口
        print("\n=== 尝试测试所有可用端口 ===")
        if ports:
            test_serial_connection(ports[0].device)
        else:
            print("✗ 没有找到可用的串行端口")
    
    print("\n" + "=" * 50)
    print("测试完成")
    print("如果没有读取到数据，请检查:")
    print("1. 扫码枪是否正确连接到电脑")
    print("2. 扫码枪是否处于正确的工作模式")
    print("3. 扫码枪是否有正确的配置（波特率、数据格式等）")
    print("4. 是否有权限访问串行端口")

if __name__ == "__main__":
    main()