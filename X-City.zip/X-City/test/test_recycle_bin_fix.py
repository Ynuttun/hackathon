#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试回收站显示修复
"""

import json
import os
from datetime import datetime

def test_recycle_bin_display():
    """测试回收站显示修复"""
    print("=== 测试回收站显示修复 ===")
    
    # 创建测试数据
    test_items = [
        {
            'timestamp': '20251227_120000_000',
            'item_name': '测试物品1',
            'item_number': 1,
            'shelf_life_days': 30,
            'production_date': '2025-12-27',
            'expiry_date': '2026-01-25',
            'position': 1,
            'weight': 100.0,
            'id_code': 'test123',
            'deletion_time': datetime.now().isoformat()
        },
        {
            'timestamp': '20251227_120100_000',
            'name': '测试物品2',  # 注意：这里使用'name'而不是'item_name'
            'number': 2,  # 注意：这里使用'number'而不是'item_number'
            'shelf_life_days': 30,
            'production_date': '2025-12-27',
            'expiry_date': '2026-01-25',
            'position': 2,
            'weight': 200.0,
            'id_code': 'test456',
            'deletion_time': datetime.now().isoformat()
        }
    ]
    
    # 写入测试数据到recycle_bin.json
    with open('test_recycle_bin.json', 'w') as f:
        json.dump(test_items, f, indent=4)
    
    print("✓ 测试数据已写入test_recycle_bin.json")
    
    # 模拟update_recycle_bin_display方法的逻辑
    print("\n=== 测试修复后的显示逻辑 ===")
    
    for i, item_data in enumerate(test_items):
        # 修复后的逻辑：支持两种字段名
        id_code = item_data.get('id_code', '无')
        # 支持两种字段名：'name'（来自load_items_data）和'item_name'（直接从recognition_log.json）
        item_name = item_data.get('name', item_data.get('item_name', '未知物品'))
        # 支持两种字段名：'number'（来自load_items_data）和'item_number'（直接从recognition_log.json）
        item_number = item_data.get('number', item_data.get('item_number', 0))
        
        # 构建显示文本
        display_text = f"{i+1}. {item_name} (编号: {item_number}, id_code: {id_code})"
        print(f"✓ 物品 {i+1} 显示: {display_text}")
    
    # 清理测试文件
    os.remove('test_recycle_bin.json')
    print("\n✓ 测试完成，已清理测试文件")
    
    print("\n=== 修复总结 ===")
    print("问题：回收站中显示'未知物品'而不是实际物品名称")
    print("原因：物品数据在不同上下文中使用了不同的字段名")
    print("   - 当从load_items_data方法返回时，字段名是'name'和'number'")
    print("   - 当直接从recognition_log.json读取时，字段名是'item_name'和'item_number'")
    print("解决方案：修改update_recycle_bin_display方法，使其支持两种字段名")
    
    return True

if __name__ == "__main__":
    test_recycle_bin_display()