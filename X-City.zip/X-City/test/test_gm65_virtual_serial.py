#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GM65扫码枪虚拟串口模式测试脚本
"""

import serial
import time
from serial.tools import list_ports

def test_gm65_virtual_serial():
    """测试GM65扫码枪的虚拟串口模式"""
    print("GM65扫码枪虚拟串口模式测试工具")
    print("=" * 50)
    
    # 1. 检测可用的串行端口
    print("1. 检测可用的串行端口...")
    ports = list_ports.comports()
    print(f"   找到 {len(ports)} 个串行端口")
    
    # 详细显示所有端口信息
    for i, port in enumerate(ports):
        print(f"   端口 {i+1}: {port.device}")
        print(f"      描述: {port.description}")
        print(f"      制造商: {port.manufacturer}")
        print(f"      产品: {port.product}")
        print(f"      VID: {port.vid}")
        print(f"      PID: {port.pid}")
    
    # 2. 查找GM65扫码枪虚拟串口
    print("\n2. 查找GM65扫码枪虚拟串口...")
    gm65_ports = []
    for port in ports:
        # 检查端口是否可能是GM65扫码枪
        device_name = port.device.lower()
        description = port.description.lower() if port.description else ""
        manufacturer = port.manufacturer.lower() if port.manufacturer else ""
        product = port.product.lower() if port.product else ""
        
        # GM65扫码枪的特征
        is_gm65 = any(keyword in device_name or keyword in description or keyword in manufacturer or keyword in product 
                     for keyword in ['usbmodem', 'usbserial', 'gm65', 'usbkey', 'barcode', 'scanner'])
        
        if is_gm65:
            gm65_ports.append(port.device)
            print(f"   ✓ 找到GM65扫码枪端口: {port.device} ({port.description})")
    
    if not gm65_ports:
        print("   ✗ 没有找到GM65扫码枪端口")
        print("   请检查扫码枪是否正确连接并设置为虚拟串口模式")
        return False
    
    # 3. 测试连接到GM65扫码枪
    print(f"\n3. 测试连接到GM65扫码枪...")
    gm65_port = gm65_ports[0]
    try:
        ser = serial.Serial(
            port=gm65_port,
            baudrate=9600,
            timeout=1,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS
        )
        print(f"   ✓ 成功连接到GM65扫码枪端口: {gm65_port}")
        print(f"   波特率: 9600")
        print(f"   数据位: 8")
        print(f"   停止位: 1")
        print(f"   奇偶校验: 无")
        print(f"   流控制: 无")
    except serial.SerialException as e:
        print(f"   ✗ 连接到GM65扫码枪失败: {e}")
        return False
    
    # 4. 测试读取扫码数据
    print("\n4. 测试读取扫码数据...")
    print("   请使用GM65扫码枪扫描二维码或条形码")
    print("   按Ctrl+C退出")
    
    try:
        buffer = ""
        while True:
            # 检查是否有可用数据
            if ser.in_waiting > 0:
                # 读取所有可用数据
                raw_bytes = ser.read_all()
                data = raw_bytes.decode('utf-8', errors='ignore')
                
                if data:
                    print(f"   读取到数据: {repr(data)}")
                    buffer += data
                    print(f"   当前缓冲区: {repr(buffer)}")
                    
                    # 检查数据中是否包含终止符
                    if '\r' in data or '\n' in data:
                        # 处理完整的扫码数据
                        qr_content = buffer.strip()
                        print(f"   ✓ 扫码完成: {qr_content}")
                        print(f"   原始缓冲区: {repr(buffer)}")
                        print(f"   清理后: {qr_content}")
                        
                        # 清空缓冲区，准备下一次扫码
                        buffer = ""
            
            # 短暂休眠，避免CPU占用过高
            time.sleep(0.1)
            
    except KeyboardInterrupt:
        print("\n   用户中断测试")
    except Exception as e:
        print(f"   ✗ 读取数据时出错: {e}")
    finally:
        # 关闭串口连接
        ser.close()
        print(f"\n5. 已关闭与GM65扫码枪的连接")
    
    print("\n测试完成")
    print("=" * 50)
    print("如果扫码枪仍无法正常工作，请检查：")
    print("1. 扫码枪是否已正确设置为虚拟串口模式")
    print("2. 扫码枪的波特率是否设置为9600")
    print("3. 扫码枪是否已正确连接到电脑")
    print("4. 是否有权限访问串行端口")
    print("5. 扫码枪是否已设置为添加回车/换行后缀")
    
    return True

if __name__ == "__main__":
    test_gm65_virtual_serial()