#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试单片机串口通信程序包
用于模拟单片机发送数据，验证日志记录是否包含原始数据和解析数据
"""

import serial
import struct
import time
import threading
import os

# 数据帧结构定义
FRAME_HEADER = b'\xAA\x55'  # 帧头
FRAME_FOOTER = b'\x0D\x0A'  # 帧尾
FRAME_LENGTH = 13  # 完整帧长度

class MockMCU:
    """模拟单片机发送数据"""
    
    def __init__(self, port):
        """初始化模拟单片机"""
        self.port = port
        self.running = False
        self.serial_port = None
        self.thread = None
    
    def calculate_checksum(self, data):
        """计算校验和"""
        checksum = 0
        for byte in data:
            checksum += byte
        return checksum & 0xFF
    
    def generate_frame(self):
        """生成模拟数据帧"""
        # 模拟传感器状态（4个格子）
        sensor_status = [1, 0, 1, 0]  # 格子1和3有东西
        
        # 模拟总重量
        total_weight = 250.5  # 250.5g
        
        # 模拟稳定标志
        stable_flag = 1  # 稳定
        
        # 构建数据部分
        data_part = b''
        # 传感器状态（4字节）
        for status in sensor_status:
            data_part += struct.pack('B', status)
        # 总重量（4字节，大端序float）
        data_part += struct.pack('>f', total_weight)
        # 稳定标志（1字节）
        data_part += struct.pack('B', stable_flag)
        
        # 计算校验和
        checksum = self.calculate_checksum(data_part)
        
        # 构建完整帧
        frame = FRAME_HEADER + data_part + struct.pack('B', checksum) + FRAME_FOOTER
        
        return frame
    
    def start(self):
        """启动模拟单片机"""
        try:
            # 打开串口
            self.serial_port = serial.Serial(
                port=self.port,
                baudrate=115200,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.1
            )
            
            self.running = True
            self.thread = threading.Thread(target=self.send_data, daemon=True)
            self.thread.start()
            print(f"模拟单片机已启动，正在向 {self.port} 发送数据")
            return True
        except Exception as e:
            print(f"启动模拟单片机失败：{str(e)}")
            return False
    
    def send_data(self):
        """发送模拟数据"""
        while self.running:
            try:
                # 生成数据帧
                frame = self.generate_frame()
                
                # 发送数据
                self.serial_port.write(frame)
                print(f"发送数据帧：{frame.hex()}")
                
                # 等待1秒
                time.sleep(1)
            except Exception as e:
                print(f"发送数据失败：{str(e)}")
                break
    
    def stop(self):
        """停止模拟单片机"""
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(1)
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
        print("模拟单片机已停止")

if __name__ == "__main__":
    # 模拟数据发送测试
    print("测试单片机串口通信程序包")
    print("=" * 50)
    
    # 清理旧日志
    log_file = "logs/serial.log"
    if os.path.exists(log_file):
        os.remove(log_file)
        print(f"已清理旧日志：{log_file}")
    
    # 创建MCUSerial实例
    from mcu_serial import MCUSerial
    mcu_serial = MCUSerial()
    
    # 定义数据回调函数
    def handle_mcu_data(data):
        """处理单片机发送的数据"""
        print(f"收到单片机数据：{data}")
    
    # 设置回调函数
    mcu_serial.set_data_callback(handle_mcu_data)
    
    # 启动串口通信
    if mcu_serial.start():
        print("\n单片机串口通信已启动")
        print("等待5秒后停止...")
        
        # 等待5秒，让串口有时间读取数据
        time.sleep(5)
        
        # 停止串口通信
        mcu_serial.stop()
        print("\n单片机串口通信已停止")
        
        # 检查日志文件
        print("\n" + "=" * 50)
        print("日志文件内容：")
        print("=" * 50)
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                content = f.read()
                print(content)
        else:
            print(f"日志文件不存在：{log_file}")
    else:
        print("\n单片机串口通信启动失败")
        print("可能是没有找到合适的串口设备")
        print("请确保有可用的串口设备")
