#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests

# 测试百度AI API Key和Secret Key
API_KEY = "L9AUgPB7roGfkSTeZezlz81"
SECRET_KEY = "6muhTlSx8Deybe6k0fMSbfMfNfhyULXp"

# 获取百度AI的access token
token_url = f"https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={API_KEY}&client_secret={SECRET_KEY}"
print(f"测试URL: {token_url}")

response = requests.post(token_url)
print(f"响应状态码: {response.status_code}")
print(f"响应内容: {response.text}")

# 解析响应
token_json = response.json()
access_token = token_json.get("access_token")

if access_token:
    print(f"成功获取access token: {access_token}")
else:
    print(f"获取access token失败: {token_json.get('error_description', '未知错误')}")
