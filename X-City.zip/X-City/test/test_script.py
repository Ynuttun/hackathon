#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试脚本，用于验证USB摄像头AI识别应用的功能
"""

import os
import sys

def check_files():
    """检查项目文件是否存在"""
    required_files = [
        'usb_camera_ai.py',
        'config.json',
        'README.md'
    ]
    
    print("检查项目文件...")
    for file in required_files:
        if os.path.exists(file):
            print(f"✓ {file} 存在")
        else:
            print(f"✗ {file} 不存在")
    
    print("\n项目文件检查完成！")

def show_readme():
    """显示README内容"""
    if os.path.exists('README.md'):
        with open('README.md', 'r', encoding='utf-8') as f:
            content = f.read()
            print("README.md内容：")
            print(content)
    else:
        print("README.md文件不存在")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "check":
            check_files()
        elif sys.argv[1] == "readme":
            show_readme()
    else:
        print("使用方法：")
        print("python3 test_script.py check    # 检查项目文件")
        print("python3 test_script.py readme  # 显示README内容")