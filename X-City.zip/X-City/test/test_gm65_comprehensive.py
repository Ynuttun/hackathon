#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GM65扫码枪串口通信综合测试脚本
用于测试GM65扫码枪在虚拟串口模式下的通信功能
"""

import serial
import time
import logging
from serial.tools import list_ports

# 配置日志
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/gm65_test.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class GM65Tester:
    """GM65扫码枪测试类"""
    
    def __init__(self):
        self.serial_port = None
        self.buffer = ""
    
    def find_gm65_port(self):
        """查找GM65扫码枪的虚拟串口"""
        logger.info("开始查找GM65扫码枪虚拟串口")
        
        ports = list_ports.comports()
        logger.info(f"共检测到 {len(ports)} 个串行端口")
        
        for port in ports:
            logger.debug(f"端口信息：设备={port.device}, 描述={port.description}, 制造商={port.manufacturer}, 产品={port.product}")
        
        gm65_port = None
        for port in ports:
            description = port.description.lower() if port.description else ""
            device_name = port.device.lower()
            manufacturer = port.manufacturer.lower() if port.manufacturer else ""
            
            # GM65虚拟串口的特征
            if any(keyword in description or keyword in device_name or keyword in manufacturer 
                   for keyword in ['usbserial', 'usbmodem', 'virtual', 'acm', 'serial', 'gm65']):
                gm65_port = port.device
                logger.info(f"找到GM65扫码枪虚拟串口：{gm65_port}")
                break
        
        if not gm65_port:
            logger.warning("未找到GM65扫码枪虚拟串口，将使用第一个可用端口进行测试")
            if ports:
                gm65_port = ports[0].device
                logger.info(f"将使用端口：{gm65_port} 进行测试")
        
        return gm65_port
    
    def connect(self, port_name):
        """连接到GM65扫码枪串口"""
        logger.info(f"尝试连接到GM65扫码枪串口：{port_name}")
        
        try:
            # 配置GM65串口参数
            self.serial_port = serial.Serial(
                port=port_name,
                baudrate=9600,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.1,
                write_timeout=0.1
            )
            
            logger.info(f"成功连接到GM65扫码枪串口：{port_name} (9600波特率)")
            return True
        except Exception as e:
            logger.error(f"连接到GM65扫码枪串口出错：{str(e)}")
            return False
    
    def test_read(self):
        """测试读取GM65扫码枪数据"""
        logger.info("开始测试读取GM65扫码枪数据")
        logger.info("请扫描条形码或二维码进行测试")
        logger.info("按 Ctrl+C 退出测试")
        
        try:
            while True:
                if self.serial_port.in_waiting > 0:
                    logger.debug(f"检测到 {self.serial_port.in_waiting} 字节可用数据")
                    
                    # 读取所有可用数据
                    raw_bytes = self.serial_port.read(self.serial_port.in_waiting)
                    logger.debug(f"读取到原始字节数据：{raw_bytes}")
                    
                    # 尝试多种编码解码
                    encodings = ['utf-8', 'gbk', 'latin-1']
                    for encoding in encodings:
                        try:
                            data = raw_bytes.decode(encoding, errors='ignore')
                            logger.debug(f"使用 {encoding} 解码结果：{repr(data)}")
                        except Exception as e:
                            logger.error(f"使用 {encoding} 解码出错：{str(e)}")
                    
                    # 主要使用utf-8解码
                    try:
                        data = raw_bytes.decode('utf-8', errors='ignore')
                        self.buffer += data
                        logger.info(f"当前缓冲区内容：{repr(self.buffer)}")
                        
                        # 处理完整的扫码数据
                        if '\r' in self.buffer or '\n' in self.buffer:
                            logger.info("检测到完整的扫码数据")
                            # 按回车或换行分割数据
                            lines = self.buffer.replace('\r\n', '\n').split('\n')
                            logger.debug(f"分割后的行数据：{lines}")
                            
                            # 处理所有完整的行
                            for line in lines[:-1]:
                                line = line.strip()
                                if line:
                                    logger.info(f"🎉 成功读取到扫码数据：{line}")
                                    logger.info(f"扫码数据长度：{len(line)} 字符")
                                    logger.info(f"扫码数据类型：{'数字' if line.isdigit() else '字母数字混合'}")
                            
                            # 保留最后一个不完整的行作为新的缓冲区
                            self.buffer = lines[-1]
                            logger.info(f"处理完成，剩余缓冲区内容：{repr(self.buffer)}")
                    except Exception as e:
                        logger.error(f"解码数据出错：{str(e)}")
                
                time.sleep(0.05)
        except KeyboardInterrupt:
            logger.info("\n测试结束")
        except Exception as e:
            logger.error(f"读取数据时发生异常：{str(e)}")
    
    def close(self):
        """关闭GM65扫码枪串口连接"""
        if self.serial_port is not None and self.serial_port.is_open:
            try:
                self.serial_port.close()
                logger.info("已关闭GM65扫码枪串口连接")
            except Exception as e:
                logger.error(f"关闭GM65扫码枪串口连接出错：{str(e)}")
    
    def run_test(self):
        """运行完整的GM65扫码枪测试"""
        logger.info("======================================")
        logger.info("GM65扫码枪串口通信综合测试")
        logger.info("======================================")
        
        # 查找GM65串口
        gm65_port = self.find_gm65_port()
        
        if gm65_port:
            # 连接到串口
            if self.connect(gm65_port):
                try:
                    # 测试读取数据
                    self.test_read()
                finally:
                    # 关闭连接
                    self.close()
        else:
            logger.error("未找到可用的串行端口，测试无法继续")

if __name__ == "__main__":
    tester = GM65Tester()
    tester.run_test()