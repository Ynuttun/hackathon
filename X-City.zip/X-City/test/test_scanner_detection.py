#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试扫码枪检测功能的脚本
"""

import os
import subprocess
import re
import sys

def detect_scanners():
    """检测扫码枪设备"""
    scanners = []
    
    is_mac = sys.platform.startswith('darwin')
    
    try:
        if is_mac:
            # macOS系统：使用ioreg命令检测USB设备
            cmd = ['ioreg', '-p', 'IOUSB', '-l', '-w', '0']
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
            
            if result.returncode == 0:
                # 获取所有USB设备的完整信息
                all_usb_info = result.stdout
                
                # 解析输出，查找扫码枪设备
                lines = all_usb_info.split('\n')
                
                # 正则表达式模式，用于匹配设备信息
                device_pattern = re.compile(r'\+-o\s+(.+?)@\w+\s+<class\s+IOUSBHostDevice')
                
                # 遍历所有行，查找设备
                for i, line in enumerate(lines):
                    # 查找设备名称
                    match = device_pattern.search(line)
                    if match:
                        device_name = match.group(1)
                        
                        # 提取设备详细信息
                        vendor_name = ""
                        product_name = ""
                        vendor_id = ""
                        product_id = ""
                        
                        # 查找后续行中的设备信息
                        for j in range(i+1, min(i+20, len(lines))):
                            next_line = lines[j]
                            
                            # 停止条件：遇到新设备或结束当前设备
                            if device_pattern.search(next_line) or next_line.strip() == '| }':
                                break
                            
                            # 提取USB Product Name
                            if 'USB Product Name' in next_line:
                                product_name = next_line.split('"USB Product Name" = ')[1].strip('"')
                            # 提取USB Vendor Name
                            elif 'USB Vendor Name' in next_line:
                                vendor_name = next_line.split('"USB Vendor Name" = ')[1].strip('"')
                            # 提取idVendor - 兼容带引号的键名和十进制值
                            elif 'idVendor' in next_line:
                                # 提取带引号的键名和十进制值
                                match = re.search(r'"idVendor"\s*=\s*(\d+)', next_line)
                                if match:
                                    vendor_id = match.group(1)
                            # 提取idProduct - 兼容带引号的键名和十进制值
                            elif 'idProduct' in next_line:
                                # 提取带引号的键名和十进制值
                                match = re.search(r'"idProduct"\s*=\s*(\d+)', next_line)
                                if match:
                                    product_id = match.group(1)
                        
                        # 检查是否为扫码枪设备
                        product_name_lower = product_name.lower()
                        vendor_name_lower = vendor_name.lower()
                        
                        # 调试：打印设备信息
                        print(f"检测到USB设备：{product_name} ({vendor_name})")
                        print(f"  Vendor ID: '{vendor_id}', Product ID: '{product_id}'")
                        
                        # 使用更宽松的条件检测扫码枪
                        if any(keyword in product_name_lower or keyword in vendor_name_lower for keyword in ['scanner', 'barcode', 'scan', '扫码', '条码', 'gm65', 'usbkey', 'usbkey module']):
                            # 调试：打印匹配的设备
                            print(f"匹配到扫码枪：{product_name} ({vendor_name})")
                            print(f"  匹配的设备ID: '{vendor_id}:{product_id}'")
                            # 构建设备ID
                            device_id = f"{vendor_id}:{product_id}"
                            scanners.append((device_id, f"{product_name} ({vendor_name})"))
    except Exception as e:
        print(f"检测出错：{str(e)}")
    
    return scanners

if __name__ == "__main__":
    print("开始检测扫码枪...")
    scanners = detect_scanners()
    
    print(f"\n检测结果：")
    if scanners:
        print(f"找到 {len(scanners)} 个扫码枪设备：")
        for scanner_id, scanner_name in scanners:
            print(f"- {scanner_name} (ID: {scanner_id})")
    else:
        print("未检测到扫码枪设备")
