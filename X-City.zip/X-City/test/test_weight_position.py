#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试重量和位置信息的保存功能
"""

import json
import os

def test_save_item():
    """测试保存带有重量和位置信息的物品"""
    print("=== 测试保存带有重量和位置信息的物品 ===")
    
    # 测试数据
    item = {
        'timestamp': '20251227_120000_000',
        'item_name': '测试物品',
        'item_number': 1,
        'shelf_life_days': 30,
        'production_date': '2025-12-27',
        'expiry_date': '2026-01-25',
        'position': 1,
        'weight': 100.0,
        'id_code': 'test123'
    }
    
    # 写入测试数据
    with open('test_recognition_log.json', 'w') as f:
        json.dump([item], f, indent=4)
    
    print("✓ 测试数据已写入test_recognition_log.json")
    print("物品信息：")
    print(f"  名称: {item['item_name']}")
    print(f"  位置: {item['position']}")
    print(f"  重量: {item['weight']}g")
    print(f"  ID: {item['id_code']}")
    
    # 测试从文件读取
    with open('test_recognition_log.json', 'r') as f:
        data = json.load(f)
    
    print("\n✓ 从文件读取的数据：")
    for i, saved_item in enumerate(data):
        print(f"  物品 {i+1}：")
        print(f"    名称: {saved_item['item_name']}")
        print(f"    位置: {saved_item.get('position', '无')}")
        print(f"    重量: {saved_item.get('weight', '无')}g")
        print(f"    ID: {saved_item.get('id_code', '无')}")
    
    # 测试将物品移到回收站
    print("\n=== 测试将物品移到回收站 ===")
    item['deletion_time'] = '2025-12-27T12:00:00'
    
    with open('test_recycle_bin.json', 'w') as f:
        json.dump([item], f, indent=4)
    
    print("✓ 测试数据已写入test_recycle_bin.json")
    
    # 读取回收站数据
    with open('test_recycle_bin.json', 'r') as f:
        bin_data = json.load(f)
    
    print("\n✓ 从回收站读取的数据：")
    for i, bin_item in enumerate(bin_data):
        print(f"  回收站物品 {i+1}：")
        print(f"    名称: {bin_item['item_name']}")
        print(f"    位置: {bin_item.get('position', '无')}")
        print(f"    重量: {bin_item.get('weight', '无')}g")
        print(f"    ID: {bin_item.get('id_code', '无')}")
        print(f"    删除时间: {bin_item.get('deletion_time', '无')}")
    
    # 清理测试文件
    os.remove('test_recognition_log.json')
    os.remove('test_recycle_bin.json')
    print("\n✓ 测试完成，已清理测试文件")

if __name__ == "__main__":
    test_save_item()