# USB摄像头AI识别应用

这个应用可以实时显示USB摄像头画面，拍照并使用AI识别画面中央的物品。

## 功能特性

- 实时显示USB摄像头画面
- 点击"拍照"按钮保存当前画面
- 自动将照片发送给AI进行识别
- 显示识别结果和置信度
- 支持配置文件自定义设置
- 拍照后定格画面并弹出确认对话框
- 用户可确认或修改识别结果
- 自动保存图片和识别结果到本地
- 左上角"Debug"按钮可切换调试模式
- 调试模式下拍照不调用AI API，直接返回示例结果

## 依赖库

- PyQt5
- OpenCV (cv2)
- requests
- base64
- json

## 安装依赖

```bash
pip3 install PyQt5 opencv-python requests
```

## 配置API密钥

在使用AI识别功能前，需要配置API密钥：

1. 在百度AI开放平台注册账号并创建应用
2. 获取API Key和Secret Key
3. 编辑`config.json`文件，将`your_api_key_here`和`your_secret_key_here`替换为真实的密钥

```json
{
    "baidu_ai": {
        "api_key": "你的API Key",
        "secret_key": "你的Secret Key"
    },
    "camera": {
        "device_index": 0,
        "frame_width": 640,
        "frame_height": 480
    },
    "app": {
        "window_width": 800,
        "window_height": 600
    }
}
```

## 使用方法

运行应用：

```bash
python3 usb_camera_ai.py
```

界面说明：
- 上方显示摄像头实时画面
- 中间的"拍照"按钮用于触发识别
- 下方显示识别结果

新功能说明：
- 点击"拍照"后，画面会定格
- 弹出确认对话框显示AI识别结果
- 用户可以选择确认识别结果或输入正确的物品名称
- 点击"确定"后，图片和识别结果会自动保存
- 左上角有"Debug"按钮，可切换调试模式
- 在调试模式下，拍照不会调用AI API，而是直接返回"示例物品"

## 性能优化

- 摄像头缓冲区设置为1，减少延迟
- 使用多线程处理摄像头采集和AI识别，避免界面卡顿
- 支持配置摄像头分辨率以平衡画质和性能

## 注意事项

- 应用会自动创建`config.json`配置文件（如果不存在）
- 拍照后会生成带时间戳的图片文件（保存在captured_images文件夹中）
- 识别结果会保存到recognition_log.txt文件中
- 如需使用其他AI服务，可修改AIDetectionThread类中的API调用部分