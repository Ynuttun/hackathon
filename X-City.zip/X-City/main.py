#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
USB摄像头AI识别应用 - 主入口文件
"""

import sys
from PyQt5.QtWidgets import QApplication
from camera_app import CameraApp

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CameraApp()
    window.show()
    sys.exit(app.exec_())
