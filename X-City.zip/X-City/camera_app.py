#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
USB摄像头AI识别应用 - 主应用类
"""

import json
import os
import time
import glob
from datetime import datetime, timedelta

from PyQt5.QtWidgets import (QMainWindow, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
                            QWidget, QProgressBar, QLineEdit, QTextEdit, QDialog, QMessageBox)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPixmap

from utils import logger
from threads import CameraThread, AIDetectionThread, DeepseekThread, EANQueryThread
from dialogs import ConfirmationDialog, SettingsDialog
from item_manager import ItemManagerDialog
from mcu_serial import MCUSerial

from PyQt5.QtCore import QObject, pyqtSignal, QTimer

class CameraApp(QMainWindow):
    """摄像头应用主窗口"""
    # 信号声明必须在类级别
    scan_result_ready = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        logger.info("应用程序启动")
        
        # 删除根目录下的临时图片
        import glob
        import os
        import json
        try:
            temp_images = glob.glob("capture_*.jpg")
            for img in temp_images:
                os.remove(img)
                logger.info(f"删除临时图片：{img}")
        except Exception as e:
            logger.error(f"删除临时图片出错：{str(e)}")
        
        # 清理captured_images文件夹中没有记录的图片
        try:
            # 创建captured_images目录（如果不存在）
            captured_dir = "captured_images"
            if not os.path.exists(captured_dir):
                os.makedirs(captured_dir)
                logger.info(f"创建图片存储目录：{captured_dir}")
            
            # 读取recognition_log.json中的记录
            used_images = set()
            
            # 读取recognition_log.json
            try:
                with open("data/recognition_log.json", "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        recognition_log = json.loads(content)
                        for item in recognition_log:
                            timestamp = item.get("timestamp")
                            if timestamp:
                                # 添加所有可能的图片文件名格式
                                used_images.add(f"{timestamp}.jpg")
            except Exception as e:
                logger.error(f"读取recognition_log.json出错：{str(e)}")
            
            # 读取recycle_bin.json
            try:
                with open("data/recycle_bin.json", "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        recycle_bin = json.loads(content)
                        for item in recycle_bin:
                            timestamp = item.get("timestamp")
                            if timestamp:
                                # 添加所有可能的图片文件名格式
                                used_images.add(f"{timestamp}.jpg")
            except Exception as e:
                logger.error(f"读取recycle_bin.json出错：{str(e)}")
            
            logger.info(f"记录在数据库中的图片文件：{used_images}")
            
            # 遍历captured_images文件夹中的所有图片
            all_images = glob.glob(os.path.join(captured_dir, "*.jpg"))
            logger.info(f"captured_images文件夹中共有 {len(all_images)} 张图片")
            
            # 统计要删除的图片数量
            deleted_count = 0
            
            # 删除没有记录的图片
            for img_path in all_images:
                img_name = os.path.basename(img_path)
                if img_name not in used_images:
                    os.remove(img_path)
                    deleted_count += 1
                    logger.info(f"删除未记录的图片：{img_path}")
            
            logger.info(f"共删除 {deleted_count} 张未记录的图片")
        except Exception as e:
            logger.error(f"清理captured_images文件夹出错：{str(e)}")
        
        # 读取配置文件
        self.config = self.load_config()
        logger.info(f"配置文件加载完成，窗口大小: {self.config.get('app', {}).get('window_width', 1200)}x{self.config.get('app', {}).get('window_height', 600)}")
        
        # 设置窗口
        window_width = self.config.get("app", {}).get("window_width", 1400)  # 默认宽度从1200改为1400，更宽
        window_height = self.config.get("app", {}).get("window_height", 600)
        self.setWindowTitle("USB摄像头AI识别")
        self.setGeometry(100, 100, window_width, window_height)
        # 设置窗口最小大小，防止内容过多时自动变长，同时允许用户自由拉长
        self.setMinimumSize(window_width, window_height)
        
        # 初始化调试模式标志
        self.debug_mode = False
        
        # 初始化画面定格标志
        self.frame_frozen = False
        
        # 初始化历史记录列表
        self.history = []
        
        # 初始化物品编号字典，用于跟踪每个物品的编号
        self.item_counter = {}
        
        # 初始化保质期记录字典
        self.shelf_life_records = {}
        
        # 扫码枪相关初始化
        self.qr_scan_buffer = ""  # 用于存储扫码枪输入的字符
        self.last_key_time = 0     # 用于检测扫码枪输入的时间间隔
        self.scan_timeout = 0.1    # 扫码枪输入字符的最大时间间隔（秒）
        self.last_qr_content = ""  # 用于保存上一个识别到的二维码内容
        self.scan_timer = None     # 用于检测扫码完成的定时器
        self.last_id_code_time = 0  # 用于记录上次处理id_code的时间，实现3秒防抖
        
        # GM65扫码枪虚拟串口通信相关初始化
        self.serial_port = None  # 用于串行通信的端口
        self.serial_timer = None  # 用于检测和重连串行端口的定时器
        self.serial_buffer = ""  # 用于存储串口接收的数据
        self.serial_thread = None  # 用于读取串口数据的线程
        self.running = False  # 线程运行标志
        
        # 连接信号和槽
        self.scan_result_ready.connect(self.process_scan_result)
        
        # 初始化GM65扫码枪串口通信
        self.init_gm65_serial()
        
        # 临时存储EAN码和商品信息
        self.temp_ean_code = None  # 临时保存当前扫码的EAN码
        self.temp_product_info = None  # 临时保存从EAN码获取的商品信息
        self.temp_id_code = None  # 临时保存当前扫码的id_code（非EAN码）
        
        # 初始化UI
        self.init_ui()
        logger.info("UI初始化完成")
        
        # 确保窗口能够捕获键盘事件
        self.setFocusPolicy(Qt.StrongFocus)
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        
        # 自动获取焦点
        self.activateWindow()
        self.setFocus()
        

        
        # 加载保质期记录
        self.load_shelf_life_records()
        logger.info(f"保质期记录加载完成，共 {len(self.shelf_life_records)} 条记录")
        
        # 加载历史记录
        self.load_history()
        logger.info(f"历史记录加载完成，共 {len(self.history)} 条记录")
        
        # 初始化mcu_serial，使用配置文件中的串口设置
        mcu_port = self.config.get("mcu_serial", {}).get("port", "")
        self.mcu_serial = MCUSerial(port=mcu_port)
        # 设置数据回调函数
        self.mcu_serial.set_data_callback(self.on_mcu_data_received)
        # 启动mcu_serial线程
        if self.mcu_serial.start():
            logger.info(f"MCU串口线程启动成功，端口：{mcu_port}")
        else:
            logger.error(f"MCU串口线程启动失败，端口：{mcu_port}")
        
        # 初始化定时器，用于检测serial_data.json的变化
        self.serial_data_timer = QTimer()
        self.serial_data_timer.setInterval(500)  # 每500毫秒检测一次
        self.serial_data_timer.timeout.connect(self.update_ui_from_serial_data)
        self.serial_data_timer.start()
        logger.info("串口数据检测定时器启动")
        
        # 初始化摄像头线程
        self.camera_thread = CameraThread(self.config.get("camera", {}))
        self.camera_thread.frame_ready.connect(self.update_frame)
        
        # 初始化AI识别线程
        self.ai_thread = None
        
        # 启动摄像头
        self.camera_thread.start()
        logger.info("摄像头线程启动")
        
        # 初始化串口数据相关变量
        self.current_serial_data = {
            "sensor_status": [0, 0, 0, 0],
            "total_weight": 0.0,
            "stable_flag": 0,
            "timestamp": 0
        }
    
    def on_mcu_data_received(self, data):
        """处理从MCU接收的数据"""
        logger.info(f"接收到MCU数据：{data}")
        
        # 更新当前串口数据
        self.current_serial_data = data
        
        # 读取现有数据或初始化
        serial_data = {
            "sensor_status": [0, 0, 0, 0],
            "total_weight": 0.0,
            "stable_flag": 0,
            "timestamp": 0
        }
        
        # 检查serial_data.json是否存在，存在则读取
        serial_data_path = "data/serial_data.json"
        if os.path.exists(serial_data_path):
            try:
                with open(serial_data_path, "r", encoding="utf-8") as f:
                    serial_data = json.load(f)
            except Exception as e:
                logger.error(f"读取serial_data.json出错：{str(e)}")
        
        # 场景1：当四个变量有一个数据非0时就记录四个变量的值，只改变sensor_status
        if any(status != 0 for status in data['sensor_status']):
            serial_data["sensor_status"] = data['sensor_status']
            serial_data["timestamp"] = data['timestamp']  # 更新时间戳
            need_save = True
        else:
            need_save = False
        
        # 场景2：total_weight是否记录和sensor_status无关，只有当stable_flag为1时才记录total_weight，只改变total_weight
        if data['stable_flag'] == 1:
            serial_data["total_weight"] = data['total_weight']
            serial_data["stable_flag"] = data['stable_flag']
            serial_data["timestamp"] = data['timestamp']  # 更新时间戳
            need_save = True
        
        # 如果有任何需要保存的数据，就写入文件
        if need_save:
            self.save_serial_data(serial_data)
    
    def save_serial_data(self, data):
        """保存MCU数据到serial_data.json文件"""
        try:
            # 确保data目录存在
            if not os.path.exists("data"):
                os.makedirs("data")
            
            # 写入数据到serial_data.json
            with open("data/serial_data.json", "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            logger.info(f"已保存MCU数据到serial_data.json：{data}")
        except Exception as e:
            logger.error(f"保存MCU数据到serial_data.json出错：{str(e)}")
    
    def update_ui_from_serial_data(self):
        """更新UI，设置position和weight，直接从serial_data.json文件读取"""
        try:
            # 检查serial_data.json是否存在
            serial_data_path = "data/serial_data.json"
            if not os.path.exists(serial_data_path):
                logger.warning(f"{serial_data_path} 文件不存在，无法更新UI")
                return
            
            # 直接从文件读取数据，不使用内存中的数据
            with open(serial_data_path, "r", encoding="utf-8") as f:
                serial_data = json.load(f)
            
            logger.info(f"从文件读取串口数据：{serial_data}")
            
            # 只有在确认界面可见时才更新UI
            if self.item_input.isVisible():
                # 计算position：sensor_status中哪个数据为1，position就为几
                position = 0
                for i, status in enumerate(serial_data["sensor_status"]):
                    if status == 1:
                        position = i + 1  # 位置从1开始
                        break  # 只取第一个为1的状态
                
                # 如果没有位置数据，默认使用1
                if position == 0:
                    position = 1
                
                # 更新position输入框
                if self.position_input.isVisible():
                    self.position_input.setText(str(position))
                    logger.info(f"更新位置：{position}")
                
                # 更新weight输入框，无论stable_flag是什么状态，都显示当前重量
                # 但在stable_flag为1时才记录到日志
                weight = round(serial_data["total_weight"], 1)
                if self.weight_input.isVisible():
                    self.weight_input.setText(str(weight))
                    if serial_data["stable_flag"] == 1:
                        logger.info(f"更新重量（稳定）：{weight}g")
                    else:
                        logger.info(f"更新重量（不稳定）：{weight}g")
        except Exception as e:
            logger.error(f"从serial_data.json更新UI出错：{str(e)}")
    
    def load_config(self):
        """加载配置文件"""
        try:
            with open("data/config.json", "r", encoding="utf-8") as f:
                config = json.load(f)
                logger.info("配置文件加载成功")
                # 添加默认的bing_search配置（如果不存在）
                if "bing_search" not in config:
                    config["bing_search"] = {
                        "api_key": "your_bing_api_key_here"
                    }
                    with open("data/config.json", "w", encoding="utf-8") as f:
                        json.dump(config, f, indent=4, ensure_ascii=False)
                    logger.info("已添加默认bing_search配置")
                return config
        except FileNotFoundError:
            # 如果配置文件不存在，创建默认配置
            logger.warning("配置文件不存在，创建默认配置")
            default_config = {
                "baidu_ai": {
                    "api_key": "your_api_key_here",
                    "secret_key": "your_secret_key_here"
                },
                "camera": {
                    "device_index": 0,
                    "frame_width": 640,
                    "frame_height": 480
                },
                "app": {
                    "window_width": 800,
                    "window_height": 600
                },
                "deepseek": {
                    "api_key": "your_deepseek_api_key_here"
                },
                "bing_search": {
                    "api_key": "your_bing_api_key_here"
                }
            }
            with open("data/config.json", "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=4, ensure_ascii=False)
            logger.info("默认配置文件创建成功")
            return default_config
    
    def init_ui(self):
        """初始化UI组件"""
        # 创建主部件和布局
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局改为水平布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧布局：摄像头区域 + 保质期预警列表
        left_layout = QVBoxLayout()
        
        # 顶部工具栏
        top_layout = QHBoxLayout()
        
        # Debug按钮
        self.debug_btn = QPushButton("Debug")
        self.debug_btn.setFixedSize(80, 30)
        self.debug_btn.clicked.connect(self.toggle_debug_mode)
        top_layout.addWidget(self.debug_btn)
        
        # 物品管理按钮
        self.item_manager_btn = QPushButton("物品管理")
        self.item_manager_btn.setFixedSize(100, 30)
        self.item_manager_btn.clicked.connect(self.open_item_manager)
        top_layout.addWidget(self.item_manager_btn)
        
        # 菜谱模式按钮
        self.recipe_mode_btn = QPushButton("菜谱模式")
        self.recipe_mode_btn.setFixedSize(100, 30)
        self.recipe_mode_btn.clicked.connect(self.open_recipe_mode)
        top_layout.addWidget(self.recipe_mode_btn)
        
        # 自定义菜谱按钮
        self.custom_recipe_btn = QPushButton("自定义菜谱")
        self.custom_recipe_btn.setFixedSize(100, 30)
        self.custom_recipe_btn.clicked.connect(self.open_custom_recipes)
        top_layout.addWidget(self.custom_recipe_btn)
        
        # 收藏列表按钮
        self.favorites_btn = QPushButton("收藏列表")
        self.favorites_btn.setFixedSize(100, 30)
        self.favorites_btn.clicked.connect(self.open_favorites_list)
        top_layout.addWidget(self.favorites_btn)
        
        # 历史菜谱按钮
        self.history_btn = QPushButton("历史菜谱")
        self.history_btn.setFixedSize(100, 30)
        self.history_btn.clicked.connect(self.open_recipe_history)
        top_layout.addWidget(self.history_btn)
        
        # 刷新摄像头按钮
        self.refresh_camera_btn = QPushButton("刷新摄像头")
        self.refresh_camera_btn.setFixedSize(100, 30)
        self.refresh_camera_btn.clicked.connect(self.update_camera)
        top_layout.addWidget(self.refresh_camera_btn)
        
        # 设置按钮
        self.settings_btn = QPushButton("设置")
        self.settings_btn.setFixedSize(80, 30)
        self.settings_btn.clicked.connect(self.open_settings)
        top_layout.addWidget(self.settings_btn)
        
        # 添加一些间距
        top_layout.addStretch()
        
        # 将顶部工具栏添加到左侧布局
        left_layout.addLayout(top_layout)
        
        # 摄像头画面显示
        self.image_label = QLabel("摄像头画面")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumSize(640, 300)  # 减小摄像头高度，为预警列表腾出空间
        left_layout.addWidget(self.image_label)
        
        # 拍照按钮
        self.capture_btn = QPushButton("拍照")
        self.capture_btn.setFixedSize(100, 40)
        self.capture_btn.clicked.connect(self.capture_image)
        left_layout.addWidget(self.capture_btn, 0, Qt.AlignCenter)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        left_layout.addWidget(self.progress_bar)
        
        # 保质期预警列表标题
        warning_title = QLabel("保质期预警列表")
        warning_title.setStyleSheet("font-size: 16px; font-weight: bold; margin-top: 10px; color: #ff0000;")
        left_layout.addWidget(warning_title)
        
        # 保质期预警列表
        self.warning_list = QTextEdit()
        self.warning_list.setReadOnly(True)
        self.warning_list.setMinimumHeight(200)
        self.warning_list.setStyleSheet("font-family: monospace; font-size: 12px;")
        self.warning_list.setAcceptRichText(True)  # 允许富文本
        left_layout.addWidget(self.warning_list, 1)
        
        # 将左侧布局添加到主布局
        main_layout.addLayout(left_layout)
        
        # 初始化保质期预警定时器，每隔10秒更新一次
        self.warning_timer = QTimer()
        self.warning_timer.setInterval(10000)  # 10秒
        self.warning_timer.timeout.connect(self.update_warning_list)
        self.warning_timer.start()
        
        # 初始计算一次预警列表
        self.update_warning_list()
        
        # 右侧信息栏布局
        right_layout = QVBoxLayout()
        
        # 信息栏标题
        info_title = QLabel("信息栏")
        info_title.setStyleSheet("font-size: 20px; font-weight: bold;")
        info_title.setAlignment(Qt.AlignCenter)
        right_layout.addWidget(info_title)
        
        # 识别结果显示
        self.result_label = QLabel("识别结果将显示在这里")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setStyleSheet("font-size: 16px; margin: 10px;")
        right_layout.addWidget(self.result_label)
        
        # 二维码显示模块
        qr_title = QLabel("扫码枪读取结果")
        qr_title.setStyleSheet("font-size: 16px; font-weight: bold; margin-top: 20px;")
        qr_title.setAlignment(Qt.AlignCenter)
        right_layout.addWidget(qr_title)
        
        # 二维码内容显示
        self.qr_content_label = QLabel("")
        self.qr_content_label.setAlignment(Qt.AlignCenter)
        self.qr_content_label.setStyleSheet("font-size: 14px; margin: 10px; padding: 10px; border: 1px solid #ccc; border-radius: 5px;")
        self.qr_content_label.setWordWrap(True)
        right_layout.addWidget(self.qr_content_label)
        
        # 确认识别结果的UI组件
        # 确认标签
        self.confirm_label = QLabel("请确认识别结果或输入正确物品名称：")
        self.confirm_label.setVisible(False)
        right_layout.addWidget(self.confirm_label)
        
        # 物品名称输入框
        self.item_input = QLineEdit()
        self.item_input.setVisible(False)
        right_layout.addWidget(self.item_input)
        
        # 连接物品名称输入框的textChanged信号，实现修改后重新查询保质期
        self.item_input.textChanged.connect(self.on_item_name_changed)
        
        # 初始化防抖定时器
        self.name_change_timer = QTimer()
        self.name_change_timer.setSingleShot(True)
        self.name_change_timer.setInterval(500)  # 500毫秒防抖
        self.name_change_timer.timeout.connect(self.on_name_change_debounced)
        
        # 生产日期标签
        self.production_date_label = QLabel("生产日期：")
        self.production_date_label.setVisible(False)
        right_layout.addWidget(self.production_date_label)
        
        # 生产日期输入框
        self.production_date_input = QLineEdit()
        self.production_date_input.setVisible(False)
        # 设置默认值为今天的日期，格式：YYYY-MM-DD
        self.production_date_input.setText(datetime.now().strftime("%Y-%m-%d"))
        right_layout.addWidget(self.production_date_input)
        
        # id_code标签和显示
        self.id_code_label = QLabel("id_code：")
        self.id_code_label.setVisible(False)
        right_layout.addWidget(self.id_code_label)
        
        self.id_code_display = QLineEdit()
        self.id_code_display.setVisible(False)
        self.id_code_display.setReadOnly(True)  # id_code只读，不可修改
        self.id_code_display.setPlaceholderText("无id_code")
        right_layout.addWidget(self.id_code_display)
        
        # 保质期标签
        self.shelf_life_label = QLabel("保质期：")
        self.shelf_life_label.setVisible(False)
        right_layout.addWidget(self.shelf_life_label)
        
        # 保质期输入框
        self.shelf_life_input = QLineEdit()
        self.shelf_life_input.setVisible(False)
        right_layout.addWidget(self.shelf_life_input)
        
        # 位置标签
        self.position_label = QLabel("位置：")
        self.position_label.setVisible(False)
        right_layout.addWidget(self.position_label)
        
        # 位置输入框
        self.position_input = QLineEdit()
        self.position_input.setVisible(False)
        right_layout.addWidget(self.position_input)
        
        # 重量标签
        self.weight_label = QLabel("重量(g)：")
        self.weight_label.setVisible(False)
        right_layout.addWidget(self.weight_label)
        
        # 重量输入框
        self.weight_input = QLineEdit()
        self.weight_input.setVisible(False)
        right_layout.addWidget(self.weight_input)
        
        # 确认按钮
        self.confirm_btn = QPushButton("确认")
        self.confirm_btn.setVisible(False)
        self.confirm_btn.clicked.connect(self.confirm_item)
        right_layout.addWidget(self.confirm_btn, 0, Qt.AlignCenter)
        
        # 返回按钮
        self.back_btn = QPushButton("返回")
        self.back_btn.setVisible(False)
        self.back_btn.clicked.connect(self.go_back)
        right_layout.addWidget(self.back_btn, 0, Qt.AlignCenter)
        
        # 调试信息显示（仅在调试模式下显示）
        self.debug_info = QTextEdit()
        self.debug_info.setStyleSheet("font-family: monospace; font-size: 12px; color: #333;")
        self.debug_info.setReadOnly(True)
        self.debug_info.setVisible(False)
        right_layout.addWidget(self.debug_info, 1)
        
        # 历史记录显示
        history_title = QLabel("历史记录")
        history_title.setStyleSheet("font-size: 16px; font-weight: bold; margin-top: 20px;")
        history_title.setAlignment(Qt.AlignCenter)
        right_layout.addWidget(history_title)
        
        self.history_list = QTextEdit()
        self.history_list.setReadOnly(True)
        self.history_list.setMaximumHeight(200)
        self.history_list.setStyleSheet("font-family: monospace; font-size: 12px; color: #666;")
        right_layout.addWidget(self.history_list)
        
        # 将右侧布局添加到主布局
        main_layout.addLayout(right_layout, 1)
    
    def open_item_manager(self):
        """打开物品管理对话框"""
        logger.info("打开物品管理对话框")
        
        # 首先重新计算所有物品的到期日期并保存到recognition_log.json
        logger.info("重新计算所有物品的到期日期")
        try:
            json_filename = "data/recognition_log.json"
            if os.path.exists(json_filename):
                with open(json_filename, "r", encoding="utf-8") as f:
                    items = json.load(f)
                
                updated_items = []
                for item in items:
                    timestamp = item["timestamp"]
                    
                    # 解析生产日期（优先使用production_date，否则使用timestamp）
                    try:
                        # 获取保存的生产日期
                        production_date_text = item.get("production_date")
                        if production_date_text:
                            # 解析用户输入的生产日期
                            production_date = self.parse_production_date(production_date_text)
                        else:
                            # 如果没有production_date，使用timestamp
                            dt_str = timestamp[:15]  # 取YYYYMMDD_HHMMSS部分
                            production_date = datetime.strptime(dt_str, "%Y%m%d_%H%M%S")
                        
                        # 获取shelf_life_days
                        shelf_life_days = item.get("shelf_life_days", 30)
                        
                        # 重新计算到期日期：生产日期 + 保质期天数 - 1 = 到期日期
                        expiry_dt = production_date + timedelta(days=shelf_life_days - 1)
                        expiry_date_str = expiry_dt.strftime("%Y-%m-%d")
                        
                        # 更新物品的到期日期
                        updated_item = item.copy()
                        updated_item["expiry_date"] = expiry_date_str
                        updated_items.append(updated_item)
                        logger.info(f"更新物品 {item['item_name']} 的到期日期为 {expiry_date_str}")
                    except Exception as e:
                        logger.error(f"重新计算物品 {item['item_name']} 的到期日期出错：{str(e)}")
                        updated_items.append(item)
                
                # 保存更新后的物品数据
                with open(json_filename, "w", encoding="utf-8") as f:
                    json.dump(updated_items, f, indent=4, ensure_ascii=False)
                logger.info("所有物品的到期日期已重新计算并保存")
            
            # 更新shelf_life_records.json，检查并补充缺失的物品信息
            self.update_shelf_life_records_from_log()
        except Exception as e:
            logger.error(f"重新计算到期日期出错：{str(e)}")
        
        # 加载所有物品数据
        items_data = self.load_items_data()
        # 打开物品管理对话框
        dialog = ItemManagerDialog(items_data, self)
        dialog.exec_()
    
    def load_items_data(self):
        """加载所有物品数据"""
        items_data = []
        
        try:
            json_filename = "data/recognition_log.json"
            if not os.path.exists(json_filename):
                logger.warning("识别日志文件不存在")
                return items_data
            
            with open(json_filename, "r", encoding="utf-8") as f:
                items = json.load(f)
                
            for item in items:
                timestamp = item["timestamp"]
                item_name = item["item_name"]
                item_number = item["item_number"]
                
                # 直接使用item中的shelf_life_days字段作为保质期
                shelf_life = str(item.get("shelf_life_days", 30))
                
                # 解析入库时间（从timestamp解析，不可修改）
                try:
                    # 时间戳格式：YYYYMMDD_HHMMSS_MS
                    # 提取日期时间部分：YYYYMMDD_HHMMSS
                    dt_str = timestamp[:15]  # 取YYYYMMDD_HHMMSS部分
                    dt = datetime.strptime(dt_str, "%Y%m%d_%H%M%S")
                    formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
                except ValueError:
                    formatted_time = timestamp
                    dt = None
                
                # 重新计算到期日期：使用保存的production_date + 保质期天数 - 1 = 到期日期
                formatted_expiry = item["expiry_date"]
                # 获取保存的生产日期（可由用户修改）
                production_date_text = item.get("production_date")
                if production_date_text:
                    try:
                        # 解析生产日期
                        production_date = self.parse_production_date(production_date_text)
                        shelf_life_days = int(shelf_life)
                        # 计算到期日期
                        expiry_dt = production_date + timedelta(days=shelf_life_days - 1)
                        formatted_expiry = expiry_dt.strftime("%Y-%m-%d")
                    except Exception as e:
                        logger.error(f"重新计算到期日期出错：{str(e)}")
                
                # 查找对应的图片文件
                image_dir = "captured_images"
                image_path = os.path.join(image_dir, f"{timestamp}.jpg")
                
                # 如果图片不存在，尝试查找相似文件名
                if not os.path.exists(image_path):
                    # 查找captured_images目录下是否有类似名称的图片
                    image_files = glob.glob(os.path.join(image_dir, f"{timestamp[:14]}*.jpg"))
                    if image_files:
                        image_path = image_files[0]
                    else:
                        # 使用默认图像
                        default_image_path = os.path.join(image_dir, "default.png")
                        if os.path.exists(default_image_path):
                            image_path = default_image_path
                        else:
                            # 如果默认图像也不存在，使用空路径
                            image_path = ""
                
                # 构建物品数据
                item_data = {
                    'timestamp': timestamp,
                    'name': item_name,
                    'number': item_number,
                    'time': formatted_time,  # 入库时间从timestamp解析，不可修改
                    'production_date': production_date_text,  # 生产日期，可由用户修改
                    'shelf_life': shelf_life,
                    'expiry_date': formatted_expiry,
                    'image_path': image_path,
                    'id_code': item.get('id_code'),  # 从识别日志中获取id_code
                    'position': item.get('position', 1),  # 从识别日志中获取位置，默认1
                    'weight': item.get('weight', 100.0)  # 从识别日志中获取重量，默认100g
                }
                
                items_data.append(item_data)
        
        except Exception as e:
            logger.error(f"加载物品数据出错：{str(e)}")
        
        # 按入库时间倒序排序
        items_data.sort(key=lambda x: x['time'], reverse=True)
        
        return items_data
    
    def capture_image(self):
        """拍照功能"""
        logger.info("开始拍照")
        
        # 获取当前摄像头画面
        pixmap = self.image_label.pixmap()
        if pixmap is None:
            logger.warning("无法获取摄像头画面")
            self.result_label.setText("无法获取摄像头画面")
            return
        
        # 画面定格
        self.frame_frozen = True
        logger.info("画面定格")
        
        # 保存拍照时的精确时间（精确到秒）
        self.capture_datetime = datetime.now()
        
        # 保存照片到临时文件
        timestamp = int(time.time())
        self.temp_image_path = f"capture_{timestamp}.jpg"
        pixmap.save(self.temp_image_path, "JPG")
        logger.info(f"临时照片保存成功：{self.temp_image_path}")
        
        # 显示进度条
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.result_label.setText("正在进行AI识别...")
        
        # 启动AI识别线程
        self.ai_thread = AIDetectionThread(self.temp_image_path, self.config)
        self.ai_thread.result_ready.connect(self.on_ai_result)
        self.ai_thread.error_occurred.connect(self.on_ai_error)
        
        # 模拟进度更新
        self.progress_timer = QTimer()
        self.progress_timer.timeout.connect(self.update_progress)
        self.progress_timer.start(100)
        
        # 启动线程
        self.ai_thread.start()
        logger.info("AI识别线程启动")
    
    def update_progress(self):
        """更新进度条"""
        current_value = self.progress_bar.value()
        if current_value < 90:  # 只更新到90%，剩下的10%在结果返回后更新
            self.progress_bar.setValue(current_value + 10)
    
    def on_ai_result(self, result_text):
        """处理AI识别结果"""
        logger.info(f"AI识别结果：{result_text}")
        
        # 停止进度条更新
        self.progress_timer.stop()
        self.progress_bar.setValue(100)
        self.progress_bar.setVisible(False)
        
        # 显示识别结果
        self.result_label.setText(result_text)
        
        # 提取物品名称，用于确认识别结果
        # 假设结果格式为："画面中央的物品是：物品名称 (置信度: xx.xx%)"
        try:
            import re
            match = re.search(r'画面中央的物品是：(.+?) \(置信度:', result_text)
            if match:
                self.confirmed_item = match.group(1)
            else:
                # 如果正则匹配失败，使用整个结果作为物品名称
                self.confirmed_item = result_text
        except Exception as e:
            logger.error(f"解析识别结果出错：{str(e)}")
            self.confirmed_item = result_text
        
        # 隐藏AI识别相关UI，显示确认识别结果的UI
        self.switch_to_confirmation_ui()
        
        # 调用Deepseek API查询保质期
        self.query_shelf_life()
    
    def query_shelf_life(self, ean_code=None):
        """调用Deepseek API查询物品保质期，支持EAN码查询"""
        logger.info(f"查询物品 '{self.confirmed_item}' 的保质期")
        
        # 检查是否有EAN码，如果有则优先使用EAN码查询
        if ean_code and ean_code in self.shelf_life_records:
            ean_record = self.shelf_life_records[ean_code]
            # 检查EAN码记录的类型
            if isinstance(ean_record, dict):
                # 这是一个包含商品名称和保质期的完整记录
                product_name = ean_record.get("product_name", self.confirmed_item)
                shelf_life_days = ean_record.get("shelf_life_days", 30)
                logger.info(f"使用EAN码保质期记录：{ean_code} -> {product_name}，保质期：{shelf_life_days}天")
                # 更新确认的物品名称
                self.confirmed_item = product_name
                self.item_input.setText(product_name)
            else:
                # 这是一个简单的保质期记录
                shelf_life_days = ean_record
                logger.info(f"使用EAN码保质期记录：{ean_code} -> {shelf_life_days}天")
            
            self.shelf_life_input.setText(str(shelf_life_days))
            return
        
        # 检查是否已有该物品的保质期记录
        if self.confirmed_item in self.shelf_life_records:
            logger.info(f"使用已有保质期记录：{self.confirmed_item} -> {self.shelf_life_records[self.confirmed_item]}天")
            self.shelf_life_input.setText(str(self.shelf_life_records[self.confirmed_item]))
            return
        
        # 启动Deepseek API线程查询保质期
        self.deepseek_thread = DeepseekThread(self.confirmed_item, self.config)
        self.deepseek_thread.result_ready.connect(lambda result: self.on_shelf_life_result(result, ean_code))
        self.deepseek_thread.error_occurred.connect(self.on_shelf_life_error)
        self.deepseek_thread.start()
        logger.info("Deepseek API查询线程启动")
    
    def on_shelf_life_result(self, shelf_life_days, ean_code=None):
        """处理保质期查询结果，支持保存EAN码"""
        logger.info(f"保质期查询结果：{shelf_life_days}天")
        
        # 显示保质期
        self.shelf_life_input.setText(shelf_life_days)
    
    def on_shelf_life_error(self, error_msg, ean_code=None):
        """处理保质期查询错误，支持保存EAN码"""
        logger.error(f"保质期查询失败：{error_msg}")
        # 使用默认值30天
        default_days = "30"
        self.shelf_life_input.setText(default_days)
    
    def on_item_name_changed(self):
        """物品名称输入变化时触发，实现防抖"""
        # 重启防抖定时器
        self.name_change_timer.start()
    
    def on_name_change_debounced(self):
        """防抖后执行的方法，重新查询保质期"""
        # 获取当前输入的物品名称
        new_item_name = self.item_input.text().strip()
        if not new_item_name:
            return
        
        # 更新确认的物品名称
        self.confirmed_item = new_item_name
        
        # 重新查询保质期
        logger.info(f"物品名称已修改为 '{new_item_name}'，重新查询保质期")
        self.query_shelf_life()  # 不使用EAN码，只使用物品名称查询
    
    def on_ai_error(self, error_msg):
        """处理AI识别错误"""
        self.progress_bar.setVisible(False)
        self.result_label.setText(f"识别失败: {error_msg}")
        
        # 停止进度条更新
        if hasattr(self, 'progress_timer'):
            self.progress_timer.stop()
        
        # 重置画面定格状态
        self.frame_frozen = False
        logger.info("AI识别失败，重置画面定格状态")
    
    def switch_to_confirmation_ui(self):
        """切换到确认识别结果的UI"""
        logger.info("切换到确认识别结果UI")
        
        # 隐藏AI识别相关UI
        self.capture_btn.setVisible(False)
        self.result_label.setAlignment(Qt.AlignCenter)
        
        # 显示确认识别结果的UI组件
        self.confirm_label.setVisible(True)
        self.item_input.setVisible(True)
        self.production_date_label.setVisible(True)
        self.production_date_input.setVisible(True)
        self.id_code_label.setVisible(True)
        self.id_code_display.setVisible(True)
        self.shelf_life_label.setVisible(True)
        self.shelf_life_input.setVisible(True)
        self.position_label.setVisible(True)
        self.position_input.setVisible(True)
        self.weight_label.setVisible(True)
        self.weight_input.setVisible(True)
        self.confirm_btn.setVisible(True)
        self.back_btn.setVisible(True)
        
        # 设置输入框默认值
        self.item_input.setText(self.confirmed_item)
        # 清空输入框选择，方便用户直接修改
        self.item_input.setSelection(0, len(self.confirmed_item))
        
        # 设置生产日期默认值为拍摄时间（精确到天），而不是当前时间
        if hasattr(self, 'capture_datetime'):
            self.production_date_input.setText(self.capture_datetime.strftime("%Y-%m-%d"))
        else:
            self.production_date_input.setText(datetime.now().strftime("%Y-%m-%d"))
        
        # 设置id_code显示
        if self.temp_id_code:
            self.id_code_display.setText(self.temp_id_code)
        else:
            self.id_code_display.setText("")
        
        # 设置位置和重量的默认值
        self.position_input.setText("1")
        self.weight_input.setText("100")
        
        # 立即从serial_data.json读取数据并更新UI
        self.update_ui_from_serial_data()
    
    def go_back(self):
        """返回拍摄界面"""
        logger.info("返回拍摄界面")
        
        # 重置画面定格状态
        self.frame_frozen = False
        
        # 隐藏确认识别结果的UI组件
        self.confirm_label.setVisible(False)
        self.item_input.setVisible(False)
        self.production_date_label.setVisible(False)
        self.production_date_input.setVisible(False)
        self.id_code_label.setVisible(False)
        self.id_code_display.setVisible(False)
        self.shelf_life_label.setVisible(False)
        self.shelf_life_input.setVisible(False)
        self.position_label.setVisible(False)
        self.position_input.setVisible(False)
        self.weight_label.setVisible(False)
        self.weight_input.setVisible(False)
        self.confirm_btn.setVisible(False)
        self.back_btn.setVisible(False)
        
        # 显示拍摄相关UI
        self.capture_btn.setVisible(True)
        self.result_label.setText("识别结果将显示在这里")
        
        # 删除临时文件
        if hasattr(self, 'temp_image_path') and os.path.exists(self.temp_image_path):
            os.remove(self.temp_image_path)
            logger.info(f"临时文件已删除：{self.temp_image_path}")
    
    def parse_shelf_life(self, shelf_life_text):
        """解析保质期文本，支持多种格式，如：x天，x年，x月，x个月，返回天数"""
        import re
        
        # 去除空格
        shelf_life_text = shelf_life_text.strip()
        
        # 匹配数字部分
        number_match = re.match(r'^(\d+)', shelf_life_text)
        if not number_match:
            return None
        
        number = int(number_match.group(1))
        
        # 匹配时间单位
        if re.search(r'天$', shelf_life_text):
            # x天
            return number
        elif re.search(r'年$', shelf_life_text):
            # x年，按365天计算
            return number * 365
        elif re.search(r'个月?$', shelf_life_text) or re.search(r'月$', shelf_life_text):
            # x月或x个月，按30天计算
            return number * 30
        else:
            # 默认按天计算
            return number
    
    def confirm_item(self):
        """确认物品信息，入库后保存保质期记录"""
        logger.info("确认识别结果")
        
        # 获取用户输入的物品名称
        item_name = self.item_input.text().strip()
        if not item_name:
            logger.warning("物品名称不能为空")
            self.result_label.setText("物品名称不能为空")
            return
        
        # 获取保质期
        shelf_life_text = self.shelf_life_input.text().strip()
        if not shelf_life_text:
            logger.warning("保质期不能为空")
            self.result_label.setText("保质期不能为空")
            return
        
        # 解析保质期
        shelf_life_days = self.parse_shelf_life(shelf_life_text)
        if shelf_life_days is None:
            logger.warning(f"无效的保质期格式：{shelf_life_text}")
            self.result_label.setText("保质期格式无效，请输入如：10天，1年，3个月等格式")
            return
        
        # 在获取位置和重量之前，先从serial_data.json读取最新的数据，确保使用最新的重量和位置
        self.update_ui_from_serial_data()
        
        # 获取位置
        position_text = self.position_input.text().strip()
        if not position_text:
            logger.warning("位置不能为空")
            self.result_label.setText("位置不能为空")
            return
        
        # 验证位置是否为整数
        try:
            position = int(position_text)
        except ValueError:
            logger.warning(f"无效的位置格式：{position_text}")
            self.result_label.setText("位置格式无效，请输入整数")
            return
        
        # 获取重量
        weight_text = self.weight_input.text().strip()
        if not weight_text:
            logger.warning("重量不能为空")
            self.result_label.setText("重量不能为空")
            return
        
        # 验证重量是否为数字
        try:
            weight = float(weight_text)
        except ValueError:
            logger.warning(f"无效的重量格式：{weight_text}")
            self.result_label.setText("重量格式无效，请输入数字")
            return
        
        # 更新确认的物品名称和临时商品信息，确保使用用户输入的正确名称
        self.confirmed_item = item_name
        if self.temp_product_info:
            self.temp_product_info["product_name"] = item_name
        
        logger.info(f"确认物品：{item_name}，保质期：{shelf_life_text} → {shelf_life_days}天，位置：{position}，重量：{weight}g")
        
        # 如果temp_id_code存在且已存在于recognition_log.json中，先移除旧物品
        if self.temp_id_code:
            if self.is_id_code_exists(self.temp_id_code):
                logger.info(f"id_code {self.temp_id_code} 已存在，准备移除旧物品")
                # 移除旧物品到回收站
                self.remove_item_by_id_code(self.temp_id_code)
        
        # 保存识别结果，此时物品成功入库
        self.save_recognition_data(item_name, shelf_life_days, self.production_date_input.text().strip(), position, weight)
        
        # 返回拍摄界面
        self.go_back()
    
    def save_recognition_data(self, item_name, shelf_life_days, production_date_text, position, weight):
        """保存识别数据（图片和名称），使用临时存储的EAN码和id_code"""
        try:
            # 创建存储目录
            image_dir = "captured_images"
            if not os.path.exists(image_dir):
                os.makedirs(image_dir)
                logger.info(f"创建图片存储目录：{image_dir}")
            
            # 解析用户输入的生产日期
            production_date = self.parse_production_date(production_date_text)
            
            # 使用当前时间作为入库时间，确保精确到秒
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]  # 包含毫秒
            
            # 构建文件名
            image_filename = f"{timestamp}.jpg"
            image_path = os.path.join(image_dir, image_filename)
            
            # 保存图片
            pixmap = self.image_label.pixmap()
            image_saved = False
            if pixmap:
                image_saved = pixmap.save(image_path, "JPG")
                if image_saved:
                    logger.info(f"图片保存成功：{image_path}")
                else:
                    logger.warning(f"图片保存失败：{image_path}")
            else:
                logger.warning("无法获取pixmap，图片未保存")
            
            # 生成物品编号 - 优先补缺少的编号
            # 读取所有历史记录，获取同名称物品的所有编号
            all_items = []
            try:
                json_filename = "data/recognition_log.json"
                if os.path.exists(json_filename):
                    with open(json_filename, "r", encoding="utf-8") as f:
                        items = json.load(f)
                    for item in items:
                        all_items.append({
                            'name': item['item_name'],
                            'number': item['item_number']
                        })
            except Exception as e:
                logger.error(f"读取历史记录出错：{str(e)}")
            
            # 提取同名称物品的所有编号
            current_numbers = []
            for item in all_items:
                if item['name'] == item_name:
                    # 直接使用item['number']，因为它已经是整数
                    current_numbers.append(item['number'])
            
            # 查找缺少的最小编号
            if current_numbers:
                current_numbers.sort()
                # 查找第一个缺失的编号
                item_number = 1
                for num in current_numbers:
                    if num == item_number:
                        item_number += 1
                    else:
                        break
            else:
                item_number = 1
            
            # 更新物品编号计数器
            self.item_counter[item_name] = item_number
            
            # 计算保质期到期日期：生产日期 + 保质期天数 - 1 = 到期日期
            # 例如：今天（0101）生产，保质期两天，到期日期为0102
            expiry_date = production_date + timedelta(days=shelf_life_days - 1)
            expiry_date_str = expiry_date.strftime("%Y-%m-%d")
            
            # 保存名称、编号和保质期到JSON文件
            json_filename = "data/recognition_log.json"
            items = []
            # 如果文件已存在且非空，读取现有数据
            if os.path.exists(json_filename):
                try:
                    with open(json_filename, "r", encoding="utf-8") as f:
                        content = f.read().strip()
                        if content:
                            items = json.loads(content)
                except json.JSONDecodeError:
                    logger.error("识别日志文件格式错误，将创建新文件")
                    items = []
                except Exception as e:
                    logger.error(f"读取识别日志文件出错：{str(e)}")
                    items = []
            
            # 添加新数据
            new_item = {
                "timestamp": timestamp,
                "item_name": item_name,
                "item_number": item_number,
                "shelf_life_days": shelf_life_days,
                "production_date": production_date_text,  # 保存用户输入的生产日期
                "expiry_date": expiry_date_str,
                "position": position,  # 添加位置信息
                "weight": weight  # 添加重量信息（单位：g）
            }
            
            # 获取临时存储的EAN码
            ean_code = self.temp_ean_code
            
            # 如果有EAN码，添加到识别记录中
            if ean_code:
                new_item["ean_code"] = ean_code
                logger.info(f"保存EAN码：{ean_code}")
            
            # 获取临时存储的id_code
            id_code = self.temp_id_code
            
            # 如果有id_code，添加到识别记录中
            if id_code:
                new_item["id_code"] = id_code
                logger.info(f"保存id_code：{id_code}")
            
            items.append(new_item)
            
            # 保存到文件
            with open(json_filename, "w", encoding="utf-8") as f:
                json.dump(items, f, indent=4, ensure_ascii=False)
            logger.info(f"识别记录保存成功：{item_name}, 编号: {item_number}, 保质期: {shelf_life_days}天, 位置: {position}, 重量: {weight}g")
            
            # 更新历史记录
            self.history.append({"timestamp": timestamp, "item_name": item_name})
            # 只保留最近的10条记录
            if len(self.history) > 10:
                self.history = self.history[-10:]
            # 更新历史记录显示
            self.update_history_display()
            
            logger.info(f"数据已保存 - 图片: {'已保存' if image_saved else '未保存'}, 识别结果: {item_name}, 编号: {item_number}, 保质期: {shelf_life_days}天, 到期日期: {expiry_date_str}, 位置: {position}, 重量: {weight}g")
            
            # 更新shelf_life_records.json，检查并补充缺失的物品信息
            self.update_shelf_life_records_from_log()
            
            # 清空临时存储的EAN码、id_code和商品信息
            self.temp_ean_code = None
            self.temp_id_code = None
            self.temp_product_info = None
        except Exception as e:
            error_msg = f"保存数据时出错：{str(e)}"
            logger.error(error_msg)
            self.result_label.setText(error_msg)
    
    def parse_production_date(self, date_str):
        """解析生产日期字符串"""
        # 支持多种日期格式
        formats = [
            "%Y-%m-%d",
            "%Y/%m/%d",
            "%Y.%m.%d",
            "%m-%d-%Y",
            "%m/%d/%Y",
            "%m.%d.%Y"
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_str, fmt)
            except ValueError:
                continue
        
        # 如果所有格式都失败，返回当前日期
        logger.warning(f"无法解析生产日期：{date_str}，使用当前日期")
        return datetime.now()
    
    def load_shelf_life_records(self):
        """加载保质期记录"""
        try:
            records_filename = "data/shelf_life_records.json"
            if os.path.exists(records_filename):
                with open(records_filename, "r", encoding="utf-8") as f:
                    self.shelf_life_records = json.load(f)
            else:
                self.shelf_life_records = {}
        except Exception as e:
            logger.error(f"加载保质期记录出错：{str(e)}")
            self.shelf_life_records = {}
    
    def update_shelf_life_records_from_log(self):
        """根据recognition_log.json更新shelf_life_records.json，把没有的信息补充进来"""
        try:
            logger.info("开始根据recognition_log.json更新shelf_life_records.json")
            
            # 读取data/recognition_log.json文件
            log_filename = "data/recognition_log.json"
            if not os.path.exists(log_filename):
                logger.warning("data/recognition_log.json文件不存在，无法更新shelf_life_records.json")
                return
            
            # 读取日志文件
            with open(log_filename, "r", encoding="utf-8") as f:
                log_data = json.load(f)
            
            # 遍历日志中的所有物品记录
            for item in log_data:
                item_name = item.get("item_name", "")
                shelf_life_days = item.get("shelf_life_days", 30)
                ean_code = item.get("ean_code")
                
                # 确保物品名称不为空
                if not item_name:
                    continue
                
                # 根据物品名称补充保质期记录
                if item_name not in self.shelf_life_records:
                    self.shelf_life_records[item_name] = shelf_life_days
                    logger.info(f"添加新的物品保质期记录：{item_name}={shelf_life_days}天")
                
                # 如果有EAN码，补充EAN码对应的保质期记录
                if ean_code:
                    # 检查EAN码是否已经存在于记录中
                    if ean_code not in self.shelf_life_records:
                        # 添加新的EAN码记录
                        self.shelf_life_records[ean_code] = {
                            "product_name": item_name,
                            "shelf_life_days": shelf_life_days
                        }
                        logger.info(f"添加新的EAN码保质期记录：{ean_code}={item_name}={shelf_life_days}天")
                    else:
                        # 检查现有EAN码记录是否为字典类型
                        existing_ean_record = self.shelf_life_records[ean_code]
                        if isinstance(existing_ean_record, dict):
                            # 确保现有记录中的product_name和shelf_life_days正确
                            if existing_ean_record.get("product_name") != item_name or existing_ean_record.get("shelf_life_days") != shelf_life_days:
                                # 更新现有EAN码记录
                                self.shelf_life_records[ean_code] = {
                                    "product_name": item_name,
                                    "shelf_life_days": shelf_life_days
                                }
                                logger.info(f"更新EAN码保质期记录：{ean_code}={item_name}={shelf_life_days}天")
                        else:
                            # 如果现有记录是简单的数字，转换为完整的字典记录
                            self.shelf_life_records[ean_code] = {
                                "product_name": item_name,
                                "shelf_life_days": existing_ean_record
                            }
                            logger.info(f"转换EAN码保质期记录格式：{ean_code}={item_name}={existing_ean_record}天")
            
            # 写入更新后的保质期记录到文件
            records_filename = "data/shelf_life_records.json"
            with open(records_filename, "w", encoding="utf-8") as f:
                json.dump(self.shelf_life_records, f, indent=4, ensure_ascii=False)
            
            logger.info("根据data/recognition_log.json更新data/shelf_life_records.json完成")
        except Exception as e:
            logger.error(f"更新保质期记录出错：{str(e)}")
    
    def load_history(self):
        """加载历史记录"""
        try:
            json_filename = "data/recognition_log.json"
            if os.path.exists(json_filename):
                with open(json_filename, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        for item in items:
                            timestamp = item["timestamp"]
                            item_name = item["item_name"]
                            self.history.append({"timestamp": timestamp, "item_name": item_name})
                        # 只保留最近的10条记录
                        if len(self.history) > 10:
                            self.history = self.history[-10:]
                        # 更新历史记录显示
                        self.update_history_display()
        except Exception as e:
            logger.error(f"加载历史记录出错：{str(e)}")
    
    def update_history(self):
        """更新历史记录，重新从recognition_log.json加载"""
        # 清空历史记录
        self.history.clear()
        # 重新加载历史记录
        self.load_history()
    
    def update_item_counter(self):
        """重新计算物品计数器"""
        # 清空物品计数器
        self.item_counter.clear()
        try:
            json_filename = "data/recognition_log.json"
            if os.path.exists(json_filename):
                with open(json_filename, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        # 收集所有物品名称
                        item_names = [item["item_name"] for item in items]
                        # 计算每个物品名称出现的次数
                        for item_name in item_names:
                            if item_name in self.item_counter:
                                self.item_counter[item_name] += 1
                            else:
                                self.item_counter[item_name] = 1
        except Exception as e:
            logger.error(f"更新物品计数器出错：{str(e)}")
    
    def update_history_display(self):
        """更新历史记录显示"""
        if not self.history:
            self.history_list.setText("历史记录为空")
            return
        
        history_text = ""
        for record in reversed(self.history):  # 倒序显示，最新的在最上面
            timestamp = record["timestamp"]
            item_name = record["item_name"]
            # 格式化时间戳，使其更易读
            formatted_time = f"{timestamp[:4]}-{timestamp[4:6]}-{timestamp[6:8]} {timestamp[9:11]}:{timestamp[11:13]}:{timestamp[13:15]}.{timestamp[16:]}"
            history_text += f"{formatted_time}: {item_name}\n"
        
        self.history_list.setText(history_text)
    
    def update_frame(self, q_image):
        """更新摄像头画面"""
        if not self.frame_frozen:
            scaled_image = q_image.scaled(self.image_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.image_label.setPixmap(QPixmap.fromImage(scaled_image))
    
    def open_recipe_mode(self):
        """打开菜谱模式对话框"""
        from dialogs import RecipeDialog
        dialog = RecipeDialog(self.config, parent=self)
        dialog.exec_()
    
    def open_favorites_list(self):
        """打开收藏列表对话框"""
        from dialogs import FavoritesDialog
        dialog = FavoritesDialog(parent=self)
        dialog.exec_()
    
    def open_recipe_history(self):
        """打开历史记录对话框"""
        from dialogs import RecipeHistoryDialog
        dialog = RecipeHistoryDialog(parent=self)
        dialog.exec_()
    
    def open_custom_recipes(self):
        """打开自定义菜谱对话框"""
        from dialogs import CustomRecipesDialog
        dialog = CustomRecipesDialog(parent=self)
        dialog.exec_()
    
    def toggle_debug_mode(self):
        """切换调试模式"""
        self.debug_mode = not self.debug_mode
        logger.info(f"调试模式已{'开启' if self.debug_mode else '关闭'}")
        self.debug_info.setVisible(self.debug_mode)
        if self.debug_mode:
            self.debug_btn.setStyleSheet("background-color: #ff9900;")
            self.debug_info.setText("调试模式已开启\n")
        else:
            self.debug_btn.setStyleSheet("")
            self.debug_info.setText("")
    
    def update_warning_list(self):
        """更新保质期预警列表"""
        import json
        import os
        from datetime import datetime
        
        try:
            # 读取配置文件中的预警天数
            warning_days = self.config.get("app", {}).get("warning_days", 3)  # 默认预警天数为3
            if warning_days <= 0:
                warning_days = 3  # 确保预警天数至少为1
            
            # 读取recognition_log.json中的物品数据
            json_filename = "data/recognition_log.json"
            items = []
            if os.path.exists(json_filename):
                with open(json_filename, "r", encoding="utf-8") as f:
                    items = json.load(f)
            
            # 获取当前日期
            current_date = datetime.now().date()
            
            # 生成预警列表HTML内容
            warning_html = "<div style='font-family: monospace; font-size: 12px;'>"
            
            # 统计预警物品数量
            warning_count = 0
            
            # 遍历所有物品，检查是否进入预警范围
            for item in items:
                # 获取物品的到期日期
                expiry_date_str = item.get("expiry_date", "")
                if not expiry_date_str:
                    continue
                
                # 解析到期日期
                try:
                    expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
                    
                    # 计算剩余天数（加1）
                    remaining_days = (expiry_date - current_date).days + 1
                    
                    # 检查是否在预警范围内
                    if remaining_days <= warning_days and remaining_days >= -1:
                        # 进入预警范围
                        warning_count += 1
                        
                        # 生成物品信息HTML
                        warning_html += f"<div style='margin-bottom: 10px; padding: 5px; border-bottom: 1px solid #eee;'>"
                        
                        # 物品名称
                        warning_html += f"<strong>物品名称：</strong>{item.get('item_name', '未知物品')}<br>"
                        
                        # 物品编号
                        warning_html += f"<strong>物品编号：</strong>{item.get('item_number', '0')}<br>"
                        
                        # 时间戳
                        warning_html += f"<strong>时间戳：</strong>{item.get('timestamp', '')}<br>"
                        
                        # 保质期天数
                        warning_html += f"<strong>保质期：</strong>{item.get('shelf_life_days', '0')}天<br>"
                        
                        # 生产日期
                        warning_html += f"<strong>生产日期：</strong>{item.get('production_date', '')}<br>"
                        
                        # 到期日期（标红）
                        warning_html += f"<strong>到期日期：</strong><span style='color: red;'>{expiry_date_str}</span><br>"
                        
                        # 剩余天数（标红）
                        warning_html += f"<strong>剩余天数：</strong><span style='color: red;'>{remaining_days}</span>天<br>"
                        
                        # 位置
                        warning_html += f"<strong>位置：</strong>{item.get('position', '1')}<br>"
                        
                        # 重量
                        warning_html += f"<strong>重量：</strong>{item.get('weight', '0.0')}g<br>"
                        
                        # id_code
                        warning_html += f"<strong>id_code：</strong>{item.get('id_code', '')}<br>"
                        
                        # 物品图片（如果存在）
                        image_dir = "captured_images"
                        image_path = os.path.join(image_dir, f"{item.get('timestamp', '')}.jpg")
                        if not os.path.exists(image_path):
                            # 查找相似文件名
                            import glob
                            image_files = glob.glob(os.path.join(image_dir, f"{item.get('timestamp', '')[:14]}*.jpg"))
                            if image_files:
                                image_path = image_files[0]
                        if not os.path.exists(image_path):
                            # 使用默认图片
                            image_path = os.path.join(image_dir, "default.png")
                        
                        if os.path.exists(image_path):
                            # 显示缩略图
                            warning_html += f"<div style='margin-top: 5px;'>"
                            warning_html += f"<img src='file://{os.path.abspath(image_path)}' width='80' height='80' style='border: 1px solid #ccc;'>"
                            warning_html += "</div>"
                        
                        warning_html += "</div>"
                except ValueError as e:
                    # 日期格式错误，跳过此物品
                    continue
            
            # 如果没有预警物品
            if warning_count == 0:
                warning_html += "<div style='color: green;'>当前没有进入保质期预警范围的物品</div>"
            else:
                warning_html += f"<div style='color: red; font-weight: bold; margin-top: 10px;'>共 {warning_count} 件物品进入保质期预警范围</div>"
            
            warning_html += "</div>"
            
            # 更新预警列表
            self.warning_list.setHtml(warning_html)
            
        except Exception as e:
            logger.error(f"更新保质期预警列表出错：{str(e)}")
            self.warning_list.setText(f"更新预警列表出错：{str(e)}")
    
    def update_camera(self):
        """更新摄像头设备"""
        logger.info("开始更新摄像头设备")
        
        # 停止当前摄像头线程
        if hasattr(self, 'camera_thread'):
            self.camera_thread.stop()
            logger.info("已停止当前摄像头线程")
        
        # 重新加载配置文件
        self.config = self.load_config()
        logger.info(f"配置文件重新加载完成，新摄像头索引：{self.config.get('camera', {}).get('device_index', 0)}")
        
        # 创建新的摄像头线程
        self.camera_thread = CameraThread(self.config.get("camera", {}))
        self.camera_thread.frame_ready.connect(self.update_frame)
        
        # 启动新的摄像头线程
        self.camera_thread.start()
        logger.info("新摄像头线程已启动")
    
    def open_settings(self):
        """打开设置对话框"""
        logger.info("打开设置对话框")
        dialog = SettingsDialog(self)
        
        # 保存当前摄像头索引
        current_camera = self.config.get('camera', {}).get('device_index', 0)
        
        # 执行设置对话框
        if dialog.exec_() == QDialog.Accepted:
            # 重新加载配置文件
            self.config = self.load_config()
            
            # 检查摄像头索引是否发生变化
            new_camera = self.config.get('camera', {}).get('device_index', 0)
            if new_camera != current_camera:
                logger.info(f"摄像头索引已从 {current_camera} 更改为 {new_camera}")
                # 更新摄像头
                self.update_camera()
    
    def keyPressEvent(self, event):
        """键盘事件处理，用于捕获扫码枪输入的二维码内容"""
        # 获取当前时间
        current_time = time.time()
        
        # 获取按下的键
        key = event.text()
        key_code = event.key()
        
        # 调试：记录所有键盘事件
        logger.debug(f"键盘事件：键码={key_code}, 键={repr(key)}, 可打印={key.isprintable()}")
        
        # 显示调试信息到调试窗口
        if self.debug_mode:
            self.debug_info.append(f"键盘事件：键码={key_code}, 键={repr(key)}, 可打印={key.isprintable()}")
            self.debug_info.ensureCursorVisible()
        
        # 处理回车键
        if key_code == Qt.Key_Return or key_code == Qt.Key_Enter:
            logger.debug(f"检测到回车键，缓冲区内容：{repr(self.qr_scan_buffer)}")
            self.process_scan_result()
        # 处理其他键
        elif key and key.isprintable():
            # 确保窗口获得焦点
            self.activateWindow()
            self.setFocus()
            
            # 调试：记录窗口焦点状态
            logger.debug(f"窗口焦点状态：{self.isActiveWindow()}, {self.hasFocus()}")
            
            # 如果缓冲区为空，或者与上一个键的时间间隔超过阈值，认为是新的扫码
            if not self.qr_scan_buffer or current_time - self.last_key_time > self.scan_timeout:
                logger.debug(f"开始新的扫码，清空缓冲区")
                self.qr_scan_buffer = ""  # 清空缓冲区
            
            # 添加字符到缓冲区
            self.qr_scan_buffer += key
            logger.debug(f"添加字符到缓冲区：{repr(key)}, 当前缓冲区：{repr(self.qr_scan_buffer)}")
            
            # 更新最后按键时间
            self.last_key_time = current_time
            
            # 重启扫码完成定时器
            self.restart_scan_timer()
        
        # 调用父类的keyPressEvent方法，确保其他键盘事件正常处理
        super().keyPressEvent(event)
    
    def restart_scan_timer(self):
        """重启扫码完成定时器"""
        # 如果定时器已存在，停止它
        if self.scan_timer is not None:
            self.scan_timer.stop()
        
        # 创建新的定时器，超时时间为scan_timeout的2倍
        self.scan_timer = QTimer()
        self.scan_timer.setSingleShot(True)
        self.scan_timer.timeout.connect(self.process_scan_result)
        self.scan_timer.start(int(self.scan_timeout * 2 * 1000))
        
        logger.debug(f"扫码定时器已启动，超时时间：{int(self.scan_timeout * 2 * 1000)}ms")
    
    def init_gm65_serial(self):
        """初始化GM65扫码枪串口通信"""
        logger.info("开始初始化GM65扫码枪串口通信")
        self.connect_gm65_serial()
        self.start_gm65_serial_timer()
        # 启动串口数据读取线程
        self.start_gm65_serial_thread()
    
    def connect_gm65_serial(self):
        """连接到GM65扫码枪的虚拟串口"""
        try:
            import serial
            from serial.tools import list_ports
            
            # 关闭已有的连接
            if self.serial_port is not None:
                if self.serial_port.is_open:
                    try:
                        self.serial_port.close()
                        logger.info(f"已关闭现有串行端口连接：{self.serial_port.port}")
                    except Exception as e:
                        logger.error(f"关闭现有串行端口连接出错：{str(e)}")
                self.serial_port = None
            
            # 获取所有可用的串行端口
            ports = list_ports.comports()
            logger.info(f"检测到 {len(ports)} 个串行端口")
            
            # 显示所有端口信息
            for port in ports:
                logger.debug(f"端口信息：设备={port.device}, 描述={port.description}, 制造商={port.manufacturer}, 产品ID={port.product}")
            
            # 查找GM65扫码枪的虚拟串口
            gm65_port = None
            for port in ports:
                # 检查端口描述是否包含虚拟串口相关信息
                description = port.description.lower() if port.description else ""
                device_name = port.device.lower()
                manufacturer = port.manufacturer.lower() if port.manufacturer else ""
                product = port.product.lower() if port.product else ""
                
                logger.info(f"检查端口：设备={port.device}, 描述={description}, 制造商={manufacturer}, 产品={product}")
                
                # 严格区分GM65和MCU串口：
                # 1. MCU使用usbserial-1310（必须保留）
                # 2. GM65使用usbmodem*（如usbsmodem2027300413411）
                
                # 跳过所有usbserial端口，这些是MCU的
                if 'usbserial' in device_name:
                    logger.info(f"跳过usbserial串口（保留给MCU）：{port.device}")
                    continue
                
                # 优先选择usbmodem端口用于GM65
                if 'usbmodem' in device_name:
                    gm65_port = port.device
                    logger.info(f"找到GM65扫码枪虚拟串口：{gm65_port}")
                    break
                
                # 其次查找带有GM65或扫码枪特征的端口
                elif any(keyword in description or keyword in manufacturer or keyword in product 
                         for keyword in ['gm65', 'usbkey', 'barcode', 'scanner']):
                    gm65_port = port.device
                    logger.info(f"找到GM65相关串口：{port.device}")
                    break
            
            if gm65_port:
                # 配置GM65扫码枪串口参数：9600波特率，8位数据位，1位停止位，无校验
                self.serial_port = serial.Serial(
                    port=gm65_port,
                    baudrate=9600,
                    bytesize=serial.EIGHTBITS,
                    parity=serial.PARITY_NONE,
                    stopbits=serial.STOPBITS_ONE,
                    timeout=0.1,
                    write_timeout=0.1
                )
                
                logger.info(f"成功连接到GM65扫码枪虚拟串口：{gm65_port} (9600波特率)")
                
                # 清空缓冲区
                self.serial_buffer = ""
            else:
                logger.warning("未找到GM65扫码枪虚拟串口")
        
        except ImportError:
            logger.error("PySerial库未安装，无法使用串行通信功能")
        except serial.SerialException as e:
            logger.error(f"连接GM65扫码枪串口出错：{str(e)}")
        except Exception as e:
            logger.error(f"初始化GM65扫码枪串口通信出错：{str(e)}")
    
    def start_gm65_read_timer(self):
        """启动GM65串口数据读取定时器"""
        # 使用现有的serial_read_timer变量
        if hasattr(self, 'serial_read_timer') and self.serial_read_timer is not None:
            self.serial_read_timer.stop()
        
        # 创建新的定时器，每50毫秒读取一次串口数据
        self.serial_read_timer = QTimer()
        self.serial_read_timer.setInterval(50)
        self.serial_read_timer.timeout.connect(self.read_gm65_serial)
        self.serial_read_timer.start()
        
        logger.info("GM65串口数据读取定时器已启动")
    
    def read_gm65_serial(self):
        """读取GM65串口数据"""
        try:
            if self.serial_port is None or not self.serial_port.is_open:
                logger.debug("GM65串口未连接，跳过读取")
                return
            
            # 直接读取数据，不进行测试
            try:
                # 读取所有可用数据
                raw_bytes = self.serial_port.read_all()
                if raw_bytes:
                    logger.info(f"GM65串口读取到 {len(raw_bytes)} 字节原始数据：{raw_bytes}")
                    
                    # 直接使用utf-8解码
                    data = raw_bytes.decode('utf-8', errors='replace')
                    logger.info(f"UTF-8解码结果：{repr(data)}")
                    
                    # 处理数据
                    if data:
                        self.handle_gm65_data(data)
                else:
                    # 每5秒记录一次串口状态
                    if hasattr(self, '_last_status_log'):
                        if time.time() - self._last_status_log > 5:
                            logger.info("GM65串口连接正常，但未检测到数据")
                            self._last_status_log = time.time()
                    else:
                        self._last_status_log = time.time()
            except serial.SerialException as e:
                logger.error(f"GM65串口读取出错：{str(e)}")
                # 关闭无效连接，等待定时器重连
                self.serial_port = None
            except Exception as e:
                logger.error(f"GM65串口读取过程中发生异常：{str(e)}")
        except Exception as e:
            logger.error(f"处理GM65串口数据时发生顶层异常：{str(e)}")
    
    def handle_gm65_data(self, data):
        """处理GM65串口接收到的数据"""
        logger.info(f"开始处理GM65串口数据：{repr(data)}")
        logger.info(f"当前缓冲区内容：{repr(self.serial_buffer)}")
        
        # 将新数据添加到缓冲区
        self.serial_buffer += data
        logger.info(f"更新后缓冲区内容：{repr(self.serial_buffer)}")
        
        # 检查是否包含完整的扫码数据（以回车或换行结束）
        if '\r' in self.serial_buffer or '\n' in self.serial_buffer:
            logger.info(f"检测到回车或换行符，开始处理完整扫码数据")
            
            # 先将\r替换为\n，确保所有换行符统一
            processed_buffer = self.serial_buffer.replace('\r', '\n')
            # 分割数据
            lines = processed_buffer.split('\n')
            logger.info(f"处理后的数据：{repr(processed_buffer)}")
            logger.info(f"分割后的行数据：{lines}")
            
            # 处理所有行，不忽略任何行
            for line in lines:
                line = line.strip()
                logger.info(f"处理单行数据：{repr(line)}")
                if line:
                    logger.info(f"GM65扫码枪读取到完整数据：{repr(line)}")
                    # 保存扫码结果
                    self.qr_scan_buffer = line
                    logger.info(f"设置qr_scan_buffer为：{repr(self.qr_scan_buffer)}")
                    # 使用QTimer.singleShot确保在主线程中处理扫码结果
                    QTimer.singleShot(0, self.process_scan_result)
            
            # 清空缓冲区
            self.serial_buffer = ""
            logger.info(f"处理完成，缓冲区已清空")
    
    def start_gm65_serial_timer(self):
        """启动GM65串口检测定时器，用于自动重连"""
        if self.serial_timer is not None:
            self.serial_timer.stop()
        
        # 每3秒检查一次串口连接状态
        self.serial_timer = QTimer()
        self.serial_timer.setInterval(3000)
        self.serial_timer.timeout.connect(self.check_gm65_serial_connection)
        self.serial_timer.start()
        
        logger.info("GM65串口检测定时器已启动")
    
    def check_gm65_serial_connection(self):
        """检查GM65串口连接状态，断开则重新连接"""
        try:
            if self.serial_port is None or not self.serial_port.is_open:
                logger.warning("GM65串口连接已断开，尝试重新连接")
                self.connect_gm65_serial()
        except Exception as e:
            logger.error(f"检查GM65串口连接状态出错：{str(e)}")
    
    def start_gm65_serial_thread(self):
        """启动GM65串口数据读取线程"""
        import threading
        
        # 停止已有的线程
        self.stop_gm65_serial_thread()
        
        # 设置运行标志
        self.running = True
        
        # 启动新的线程
        self.serial_thread = threading.Thread(target=self.read_gm65_serial_thread, daemon=True)
        self.serial_thread.start()
        logger.info("GM65串口数据读取线程已启动")
    
    def stop_gm65_serial_thread(self):
        """停止GM65串口数据读取线程"""
        self.running = False
        if hasattr(self, 'serial_thread') and self.serial_thread is not None:
            # 等待线程结束
            self.serial_thread.join(1)  # 等待1秒
            self.serial_thread = None
            logger.info("GM65串口数据读取线程已停止")
    
    def read_gm65_serial_thread(self):
        """GM65串口数据读取线程"""
        logger.info("GM65串口数据读取线程开始运行")
        import serial
        
        while self.running:
            try:
                if self.serial_port is None or not self.serial_port.is_open:
                    logger.debug("GM65串口未连接，等待连接...")
                    time.sleep(1)
                    continue
                
                try:
                    # 读取所有可用数据
                    raw_bytes = self.serial_port.read_all()
                    if raw_bytes:
                        logger.info(f"GM65串口读取到 {len(raw_bytes)} 字节原始数据：{raw_bytes}")
                        
                        # 直接使用utf-8解码
                        data = raw_bytes.decode('utf-8', errors='replace')
                        logger.info(f"UTF-8解码结果：{repr(data)}")
                        
                        # 处理数据
                        if data:
                            self.handle_gm65_data(data)
                    else:
                        # 短暂休眠，避免CPU占用过高
                        time.sleep(0.05)
                except Exception as e:
                    logger.error(f"GM65串口读取过程中发生异常：{str(e)}")
                    # 关闭无效连接，等待定时器重连
                    self.serial_port = None
                    time.sleep(1)
            except Exception as e:
                logger.error(f"GM65串口数据读取线程发生顶层异常：{str(e)}")
                time.sleep(1)
        
        logger.info("GM65串口数据读取线程结束运行")
    
    def is_id_code_exists(self, id_code):
        """检查id_code是否已存在于recognition_log.json中"""
        try:
            json_filename = "data/recognition_log.json"
            if os.path.exists(json_filename):
                with open(json_filename, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        for item in items:
                            if item.get("id_code") == id_code:
                                return True
        except Exception as e:
            logger.error(f"检查id_code是否存在出错：{str(e)}")
        return False
        
    def get_item_by_id_code(self, id_code):
        """根据id_code从recognition_log.json中获取物品信息"""
        try:
            json_filename = "data/recognition_log.json"
            if os.path.exists(json_filename):
                with open(json_filename, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        for item in items:
                            if item.get("id_code") == id_code:
                                return item
        except Exception as e:
            logger.error(f"根据id_code获取物品信息出错：{str(e)}")
        return None
        
    def remove_item_by_id_code(self, id_code):
        """根据id_code移除物品到回收站"""
        try:
            # 读取recognition_log.json
            json_filename = "data/recognition_log.json"
            if not os.path.exists(json_filename):
                logger.warning("识别日志文件不存在")
                return
            
            with open(json_filename, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    logger.warning("识别日志文件为空")
                    return
                items = json.loads(content)
            
            # 查找对应的id_code物品
            item_to_remove = None
            remaining_items = []
            for item in items:
                if item.get("id_code") == id_code:
                    item_to_remove = item
                else:
                    remaining_items.append(item)
            
            if item_to_remove:
                # 读取recycle_bin.json
                bin_filename = "data/recycle_bin.json"
                recycle_bin = []
                if os.path.exists(bin_filename):
                    try:
                        with open(bin_filename, "r", encoding="utf-8") as f:
                            bin_content = f.read().strip()
                            if bin_content:
                                recycle_bin = json.loads(bin_content)
                    except json.JSONDecodeError:
                        logger.error("回收站文件格式错误，将创建新文件")
                        recycle_bin = []
                
                # 确保物品有位置和重量信息，默认位置1，重量100g
                if "position" not in item_to_remove:
                    item_to_remove["position"] = 1
                if "weight" not in item_to_remove:
                    item_to_remove["weight"] = 100.0
                
                # 添加删除时间
                import datetime
                item_to_remove["deletion_time"] = datetime.datetime.now().isoformat()
                recycle_bin.append(item_to_remove)
                
                # 保存更新后的文件
                with open(json_filename, "w", encoding="utf-8") as f:
                    json.dump(remaining_items, f, indent=4, ensure_ascii=False)
                
                with open(bin_filename, "w", encoding="utf-8") as f:
                    json.dump(recycle_bin, f, indent=4, ensure_ascii=False)
                
                logger.info(f"已将id_code为 {id_code} 的物品移动到回收站")
                from PyQt5.QtWidgets import QMessageBox
                QMessageBox.information(self, "成功", f"已将id_code为 {id_code} 的物品移动到回收站")
                
                # 更新历史记录
                self.update_history()
                # 更新历史记录显示
                self.update_history_display()
                # 重新计算物品计数器
                self.update_item_counter()
            else:
                logger.warning(f"未找到id_code为 {id_code} 的物品")
        except Exception as e:
            logger.error(f"根据id_code移除物品出错：{str(e)}")
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.critical(self, "错误", f"移除物品时出错：{str(e)}")
            
    def capture_image_for_re入库(self, id_code):
        """直接拍照用于重新入库，不进行AI识别"""
        logger.info(f"开始为id_code {id_code} 拍照用于重新入库")
        
        # 获取当前摄像头画面
        pixmap = self.image_label.pixmap()
        if pixmap is None:
            logger.warning("无法获取摄像头画面")
            self.result_label.setText("无法获取摄像头画面")
            return
        
        # 保存拍照时的精确时间（精确到秒）
        capture_datetime = datetime.now()
        
        # 保存照片到临时文件
        timestamp = capture_datetime.strftime("%Y%m%d_%H%M%S_%f")[:-3]  # 包含毫秒
        temp_image_path = f"capture_{timestamp}.jpg"
        pixmap.save(temp_image_path, "JPG")
        logger.info(f"临时照片保存成功：{temp_image_path}")
        
        # 查找并更新id_code对应的物品信息
        self.update_item_with_new_image(id_code, timestamp, temp_image_path)
        
        # 删除临时文件
        if os.path.exists(temp_image_path):
            os.remove(temp_image_path)
            logger.info(f"临时文件已删除：{temp_image_path}")
            
        # 显示更新成功信息
        self.result_label.setText(f"id_code {id_code} 的物品已成功重新入库，更新了照片和入库时间")
        
    def update_item_with_new_image(self, id_code, timestamp, temp_image_path):
        """使用新照片和新时间更新id_code对应的物品信息"""
        try:
            # 读取recognition_log.json
            json_filename = "data/recognition_log.json"
            if not os.path.exists(json_filename):
                logger.warning("识别日志文件不存在")
                return
            
            with open(json_filename, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    logger.warning("识别日志文件为空")
                    return
                items = json.loads(content)
            
            # 读取最新的串口数据，获取当前重量和位置
            serial_data = {"sensor_status": [0, 0, 1, 0], "total_weight": 0.0, "stable_flag": 0}
            serial_data_path = "data/serial_data.json"
            if os.path.exists(serial_data_path):
                try:
                    with open(serial_data_path, "r", encoding="utf-8") as f:
                        serial_data = json.load(f)
                        logger.info(f"从serial_data.json读取最新数据：{serial_data}")
                except Exception as e:
                    logger.error(f"读取serial_data.json出错：{str(e)}")
            
            # 创建图片存储目录
            image_dir = "captured_images"
            if not os.path.exists(image_dir):
                os.makedirs(image_dir)
                logger.info(f"创建图片存储目录：{image_dir}")
            
            # 查找并更新对应的id_code物品
            updated_items = []
            for item in items:
                if item.get("id_code") == id_code:
                    # 更新物品的入库时间和照片
                    updated_item = item.copy()
                    updated_item["timestamp"] = timestamp
                    
                    # 保存新照片
                    image_path = os.path.join(image_dir, f"{timestamp}.jpg")
                    pixmap = self.image_label.pixmap()
                    pixmap.save(image_path, "JPG")
                    logger.info(f"图片保存成功：{image_path}")
                    
                    # 计算新的到期日期
                    try:
                        # 解析生产日期（优先使用production_date，否则使用timestamp）
                        production_date_text = updated_item.get("production_date")
                        if production_date_text:
                            # 解析用户输入的生产日期
                            production_date = self.parse_production_date(production_date_text)
                        else:
                            # 如果没有production_date，使用timestamp
                            dt_str = timestamp[:15]  # 取YYYYMMDD_HHMMSS部分
                            production_date = datetime.strptime(dt_str, "%Y%m%d_%H%M%S")
                        
                        # 获取shelf_life_days
                        shelf_life_days = updated_item.get("shelf_life_days", 30)
                        
                        # 重新计算到期日期：生产日期 + 保质期天数 - 1 = 到期日期
                        expiry_dt = production_date + timedelta(days=shelf_life_days - 1)
                        expiry_date_str = expiry_dt.strftime("%Y-%m-%d")
                        
                        # 更新物品的到期日期
                        updated_item["expiry_date"] = expiry_date_str
                        logger.info(f"更新物品 {updated_item['item_name']} 的到期日期为 {expiry_date_str}")
                    except Exception as e:
                        logger.error(f"重新计算物品 {updated_item['item_name']} 的到期日期出错：{str(e)}")
                    
                    # 从serial_data获取最新的位置和重量信息
                    # 计算position：sensor_status中哪个数据为1，position就为几
                    position = 0
                    sensor_status = serial_data.get("sensor_status", [0, 0, 0, 0])
                    for i, status in enumerate(sensor_status):
                        if status == 1:
                            position = i + 1  # 位置从1开始
                            break  # 只取第一个为1的状态
                    
                    # 如果没有位置数据，默认使用1
                    if position == 0:
                        position = 1
                    updated_item["position"] = position
                    logger.info(f"更新位置为：{position}")
                    
                    # 更新weight，只有当stable_flag为1且重量非零时才更新
                    if serial_data.get("stable_flag", 0) == 1 and serial_data.get("total_weight", 0) > 0:
                        weight = round(serial_data.get("total_weight", 100.0), 1)
                        updated_item["weight"] = weight
                        logger.info(f"更新重量为：{weight}g")
                    else:
                        # 如果重量不稳定或为0，使用现有重量或默认值
                        if "weight" not in updated_item:
                            updated_item["weight"] = 100.0
                            logger.info(f"使用默认重量：100.0g")
                    
                    updated_items.append(updated_item)
                    logger.info(f"已更新id_code {id_code} 的物品信息，新的入库时间：{timestamp}")
                else:
                    updated_items.append(item)
            
            # 保存更新后的物品数据
            with open(json_filename, "w", encoding="utf-8") as f:
                json.dump(updated_items, f, indent=4, ensure_ascii=False)
            logger.info(f"已保存更新后的物品数据，id_code {id_code} 的物品已重新入库")
            
        except Exception as e:
            logger.error(f"更新物品信息出错：{str(e)}")
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.critical(self, "错误", f"更新物品信息时出错：{str(e)}")
            
    def process_scan_result(self):
        """处理扫码结果"""
        logger.info(f"开始处理扫码结果，缓冲区内容：{repr(self.qr_scan_buffer)}")
        
        # 如果缓冲区不为空，处理扫码数据
        if self.qr_scan_buffer.strip():
            # 去除所有换行符和回车符，只保留有效字符
            raw_content = self.qr_scan_buffer.replace('\n', '').replace('\r', '')
            logger.info(f"去除换行符和回车符后的内容：{repr(raw_content)}")
            
            # 处理扫码数据，保留所有字符，只去除空白字符
            qr_content = raw_content.strip()
            logger.info(f"最终处理后的扫码内容：{repr(qr_content)}")
            
            if qr_content:
                logger.info(f"扫码枪读取到完整的二维码/条形码：{qr_content}")
                
                # 显示调试信息
                if self.debug_mode:
                    self.debug_info.append(f"扫码完成，内容：{qr_content}")
                    self.debug_info.ensureCursorVisible()
                
                # 更新上一个二维码内容
                self.last_qr_content = qr_content
                
                # 显示二维码内容到UI
                logger.info(f"将扫码结果显示到UI：{qr_content}")
                self.qr_content_label.setText(f"二维码/条形码内容：\n{qr_content}")
                self.qr_content_label.repaint()  # 强制刷新UI
                
                # 检查是否是13位EAN码（只检查数字部分）
                numeric_content = ''.join(filter(str.isdigit, qr_content))
                if numeric_content.isdigit() and len(numeric_content) == 13:
                    logger.info(f"检测到13位EAN码：{numeric_content}")
                    
                    # 先在本地JSON文件中查找对应的EAN码信息
                    if numeric_content in self.shelf_life_records:
                        logger.info(f"本地JSON文件中找到EAN码 {numeric_content} 的信息")
                        ean_record = self.shelf_life_records[numeric_content]
                        
                        # 检查EAN码记录的类型
                        if isinstance(ean_record, dict):
                            # 这是一个包含商品名称和保质期的完整记录
                            product_name = ean_record.get("product_name", "未知商品")
                            shelf_life_days = ean_record.get("shelf_life_days", 30)
                            logger.info(f"使用本地EAN码记录：{numeric_content} -> {product_name}，保质期：{shelf_life_days}天")
                            
                            # 显示商品信息
                            self.result_label.setText(f"EAN码识别：{numeric_content}\n商品名称：{product_name}\n保质期：{shelf_life_days}天")
                            
                            # 检查确认页面是否可见，如果可见则更新输入框
                            if self.item_input.isVisible():
                                # 立即替换用户输入框中的内容
                                self.item_input.setText(product_name)
                                # 更新确认的物品名称
                                self.confirmed_item = product_name
                                # 更新保质期输入框
                                self.shelf_life_input.setText(str(shelf_life_days))
                            
                            # 临时存储EAN码和商品信息
                            self.temp_ean_code = numeric_content
                            self.temp_product_info = {
                                "product_name": product_name,
                                "shelf_life_days": shelf_life_days
                            }
                            # 不要清空id_code，保留之前的id_code
                            # self.temp_id_code = None
                        else:
                            # 这是一个简单的保质期记录
                            shelf_life_days = ean_record
                            logger.info(f"使用本地EAN码保质期记录：{numeric_content} -> {shelf_life_days}天")
                            
                            # 显示商品信息
                            self.result_label.setText(f"EAN码识别：{numeric_content}\n保质期：{shelf_life_days}天")
                            # 检查确认页面是否可见，如果可见则更新输入框
                            if self.item_input.isVisible():
                                # 更新保质期输入框
                                self.shelf_life_input.setText(str(shelf_life_days))
                            # 临时存储EAN码
                            self.temp_ean_code = numeric_content
                            # 不要清空id_code，保留之前的id_code
                            # self.temp_id_code = None
                    else:
                        # 本地JSON文件中没有对应的EAN码信息，调用API获取
                        logger.info(f"本地JSON文件中未找到EAN码 {numeric_content} 的信息，调用Deepseek API获取商品信息")
                        # 调用Deepseek API获取商品名称和保质期
                        self.query_product_info_by_ean(numeric_content)
                        # 临时存储EAN码
                        self.temp_ean_code = numeric_content
                        # 不要清空id_code，保留之前的id_code
                        # self.temp_id_code = None
                else:
                    # 非13位EAN码，作为id_code处理
                    logger.info(f"检测到非EAN码：{qr_content}，作为id_code处理")
                    
                    # 实现3秒防抖机制，无论id_code是否存在
                    current_time = time.time()
                    if current_time - self.last_id_code_time < 3 and self.last_qr_content == qr_content:
                        logger.info(f"距离上次处理相同id_code不足3秒，忽略当前扫描")
                        # 清空缓冲区，停止定时器
                        self.qr_scan_buffer = ""
                        if self.scan_timer is not None:
                            self.scan_timer.stop()
                            self.scan_timer = None
                        return
                    
                    # 记录当前处理时间和内容
                    self.last_id_code_time = current_time
                    self.last_qr_content = qr_content
                    
                    # 检查id_code是否已存在
                    if self.is_id_code_exists(qr_content):
                        # 如果id_code已存在，弹出提示
                        logger.info(f"id_code {qr_content} 已存在")
                        # 统一处理：创建自定义弹窗
                        from PyQt5.QtWidgets import QMessageBox
                        
                        # 创建消息框
                        msg_box = QMessageBox(self)
                        msg_box.setWindowTitle("提示")
                        msg_box.setText("该id_code已存在，请选择你的操作")
                        
                        # 设置自定义按钮
                        出库_button = msg_box.addButton("出库", QMessageBox.ActionRole)
                        重新入库_button = msg_box.addButton("重新入库", QMessageBox.ActionRole)
                        取消_button = msg_box.addButton("取消", QMessageBox.ActionRole)
                        
                        # 移除关闭按钮
                        msg_box.setWindowFlags(msg_box.windowFlags() & ~Qt.WindowCloseButtonHint)
                        
                        # 显示消息框
                        msg_box.exec_()
                        
                        # 获取用户点击的按钮
                        clicked_button = msg_box.clickedButton()
                        
                        if clicked_button == 取消_button:
                            # 取消：关闭弹窗，无事发生
                            logger.info(f"用户取消了对id_code {qr_content} 的操作")
                        elif clicked_button == 出库_button:
                            # 出库：将物品移到回收站
                            logger.info(f"用户选择将id_code {qr_content} 的物品出库")
                            self.remove_item_by_id_code(qr_content)
                        elif clicked_button == 重新入库_button:
                            # 重新入库：根据当前界面状态执行不同操作
                            logger.info(f"用户选择将id_code {qr_content} 的物品重新入库")
                            # 1. 临时存储id_code，用于新物品
                            self.temp_id_code = qr_content
                            # 2. 不要清空EAN码，保留之前的EAN码（如果有的话）
                            # self.temp_ean_code = None
                            # 3. 获取旧物品信息
                            old_item = self.get_item_by_id_code(qr_content)
                            
                            # 无论当前界面状态如何，都先拍照
                            logger.info(f"开始为id_code {qr_content} 拍照")
                            
                            # 画面定格
                            self.frame_frozen = True
                            logger.info("画面定格")
                            
                            # 保存拍照时的精确时间
                            self.capture_datetime = datetime.now()
                            
                            # 保存照片到临时文件
                            temp_image_path = f"capture_{int(time.time())}.jpg"
                            pixmap = self.image_label.pixmap()
                            pixmap.save(temp_image_path, "JPG")
                            logger.info(f"临时照片保存成功：{temp_image_path}")
                            
                            # 4. 切换到确认界面，显示旧物品信息
                            logger.info(f"切换到确认界面，显示id_code {qr_content} 的物品信息")
                            
                            # 设置确认的物品名称
                            if old_item:
                                self.confirmed_item = old_item.get('item_name', '未知物品')
                            else:
                                self.confirmed_item = '未知物品'
                            
                            # 切换到确认识别结果的UI
                            self.switch_to_confirmation_ui()
                            
                            # 1. 如果有旧物品信息，显示在用户界面上
                            if old_item:
                                # 更新物品名称
                                self.item_input.setText(old_item.get('item_name', ''))
                                # 更新确认的物品名称
                                self.confirmed_item = old_item.get('item_name', '')
                                # 更新保质期输入框
                                self.shelf_life_input.setText(str(old_item.get('shelf_life_days', 30)))
                                # 更新生产日期输入框
                                self.production_date_input.setText(old_item.get('production_date', ''))
                                # 设置id_code显示
                                self.id_code_display.setText(qr_content)
                                # 临时存储id_code，用于用户确认后更新
                                self.temp_id_code = qr_content
                            # 2. 显示id_code到用户界面上
                            self.id_code_display.setText(qr_content)
                            # 3. 临时存储id_code，用于用户确认后更新
                            self.temp_id_code = qr_content
                            
                            # 4. 显示提示信息
                            self.result_label.setText(f"已加载id_code {qr_content} 的物品信息，点击确认更新入库时间、照片、重量和位置")
                            
                            # 5. 在确认界面中，用户点击确认后会调用confirm_item方法，该方法会处理重新入库逻辑
                            # 不再自动移除旧物品，等用户确认后再处理
                            # 不再自动保存，等用户确认后再处理
                        
                        # 清空缓冲区，停止定时器
                        self.qr_scan_buffer = ""
                        if self.scan_timer is not None:
                            self.scan_timer.stop()
                            self.scan_timer = None
                        return
                    
                    # 记录当前处理时间
                    self.last_id_code_time = current_time
                    self.last_qr_content = qr_content
                    
                    # 检查是否已经拍照，处于确认识别结果状态
                    if self.item_input.isVisible():
                        # 先拍照后扫id_code的情况
                        logger.info(f"先拍照后扫id_code，保存id_code {qr_content} 到新物体")
                        self.temp_id_code = qr_content
                        # 更新id_code显示
                        self.id_code_display.setText(qr_content)
                        self.result_label.setText(f"已保存id_code：{qr_content} 到当前物品")
                    else:
                        # 先扫id_code再拍照的情况
                        # 临时存储id_code
                        self.temp_id_code = qr_content
                        # 清空EAN码，因为这是非EAN码
                        self.temp_ean_code = None
                        # 自动调用拍照功能进行AI识别
                        self.capture_image()
                        # 显示信息
                        self.result_label.setText(f"检测到id_code：{qr_content}，正在自动拍照识别...")
            else:
                logger.warning(f"无法从扫码数据中提取有效内容：{repr(self.qr_scan_buffer)}")
            
            # 清空缓冲区
            self.qr_scan_buffer = ""
        
        # 停止定时器
        if self.scan_timer is not None:
            self.scan_timer.stop()
            self.scan_timer = None
    
    def query_product_info_by_ean(self, ean_code):
        """根据EAN码调用Deepseek API查询商品信息"""
        try:
            logger.info(f"准备查询EAN码：{ean_code}")
            
            # 启动EAN查询线程查询商品信息
            self.ean_query_thread = EANQueryThread(ean_code, self.config)
            self.ean_query_thread.result_ready.connect(lambda result: self.on_product_info_result(result, ean_code))
            self.ean_query_thread.error_occurred.connect(self.on_product_info_error)
            self.ean_query_thread.start()
            logger.info("EAN查询线程启动")
        except Exception as e:
            logger.error(f"查询商品信息出错：{str(e)}")
    
    def on_product_info_result(self, result, ean_code):
        """处理商品信息查询结果，立即替换用户输入框，临时存储EAN码和商品信息"""
        logger.info(f"商品信息查询结果：{result}")
        
        try:
            # 解析JSON结果
            import json
            product_info = json.loads(result)
            product_name = product_info.get("product_name", "未知商品")
            shelf_life_days = product_info.get("shelf_life_days", 30)
            
            logger.info(f"解析到商品信息：名称={product_name}，保质期={shelf_life_days}天")
            
            # 显示商品信息
            self.result_label.setText(f"EAN码识别：{ean_code}\n商品名称：{product_name}\n保质期：{shelf_life_days}天")
            
            # 临时存储EAN码
            self.temp_ean_code = ean_code
            
            # 如果商品名称不是"未知EAN码"，则更新输入框和保质期
            if product_name != "未知EAN码":
                # 立即替换用户输入框中的内容
                self.item_input.setText(product_name)
                
                # 更新确认的物品名称
                self.confirmed_item = product_name
                
                # 更新保质期输入框
                self.shelf_life_input.setText(str(shelf_life_days))
                
                # 临时存储商品信息
                self.temp_product_info = {
                    "product_name": product_name,
                    "shelf_life_days": shelf_life_days
                }
                
                logger.info(f"已临时存储商品信息：{product_name}，保质期：{shelf_life_days}天，EAN码：{ean_code}")
            else:
                # 如果是未知EAN码，不要更新输入框和保质期
                logger.info(f"检测到未知EAN码 {ean_code}，不更新输入框和保质期")
                # 清空临时商品信息
                self.temp_product_info = None
        except Exception as e:
            logger.error(f"解析商品信息出错：{str(e)}")
            self.result_label.setText(f"解析商品信息出错：{str(e)}")
    
    def on_product_info_error(self, error_msg):
        """处理商品信息查询错误"""
        logger.error(f"商品信息查询失败：{error_msg}")
        self.result_label.setText(f"商品信息查询失败：{error_msg}")
    
    def closeEvent(self, event):
        """关闭窗口时的事件处理"""
        logger.info("关闭应用程序")
        
        # 停止摄像头线程
        if hasattr(self, 'camera_thread'):
            self.camera_thread.stop()
            logger.info("摄像头线程已停止")

        # 停止GM65串口数据读取线程
        if hasattr(self, 'stop_gm65_serial_thread'):
            self.stop_gm65_serial_thread()

        # 关闭GM65扫码枪串口连接
        if hasattr(self, 'serial_port') and self.serial_port is not None:
            if self.serial_port.is_open:
                try:
                    self.serial_port.close()
                    logger.info("GM65扫码枪串口已关闭")
                except Exception as e:
                    logger.error(f"关闭GM65扫码枪串口出错：{str(e)}")

        # 停止GM65串口检测定时器
        if hasattr(self, 'serial_timer') and self.serial_timer is not None:
            self.serial_timer.stop()
            logger.info("GM65串口检测定时器已停止")

        # 停止GM65串口数据读取定时器（兼容旧代码）
        if hasattr(self, 'serial_read_timer') and self.serial_read_timer is not None:
            self.serial_read_timer.stop()
            logger.info("GM65串口数据读取定时器已停止")

        # 停止扫码完成定时器
        if hasattr(self, 'scan_timer') and self.scan_timer is not None:
            self.scan_timer.stop()
            logger.info("扫码完成定时器已停止")
        
        # 删除临时文件
        if hasattr(self, 'temp_image_path') and os.path.exists(self.temp_image_path):
            os.remove(self.temp_image_path)
            logger.info(f"临时文件已删除：{self.temp_image_path}")
        
        event.accept()
