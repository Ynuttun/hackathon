#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
单片机串口通信程序包
负责读取单片机发送的数据，包括传感器状态、重量等
波特率：115200
数据格式：自定义二进制协议
"""

import serial
from serial.tools import list_ports
import threading
import time
import logging
import struct
import os

# 配置日志系统
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# 创建单独的日志器
logger = logging.getLogger("mcu_serial")
logger.setLevel(logging.INFO)

# 创建文件处理器，记录所有日志
file_handler = logging.FileHandler(os.path.join(log_dir, "serial.log"), encoding="utf-8")
file_handler.setLevel(logging.INFO)

# 创建控制台处理器，只显示INFO及以上级别
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# 设置日志格式
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# 添加处理器到日志器
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# 数据帧结构定义
FRAME_HEADER = b'\xAA\x55'  # 帧头
FRAME_FOOTER = b'\x0D\x0A'  # 帧尾
FRAME_LENGTH = 14  # 完整帧长度：header[2] + sensor_status[4] + total_weight[4] + stable_flag[1] + checksum[1] + footer[2] = 14字节

class MCUSerial:
    """单片机串口通信类"""
    
    def __init__(self, port=""):
        """初始化单片机串口通信"""
        self.serial_port = port  # 从外部传入的串口设置
        self.running = False
        self.serial_thread = None
        self.sensor_data = {
            "sensor_status": [0, 0, 0, 0],  # 4个格子的状态
            "total_weight": 0.0,  # 总重量
            "stable_flag": 0,  # 稳定标志
            "timestamp": None  # 数据时间戳
        }
        self.data_callback = None  # 数据回调函数
        
    def find_mcu_port(self):
        """查找单片机串口，优先选择usbserial开头的串口，特别是usbserial-1310"""
        try:
            ports = list_ports.comports()
            logger.info(f"检测到 {len(ports)} 个串行端口")
            
            # 1. 优先查找特定的usbserial-1310端口
            for port in ports:
                device = port.device
                if device == 'usbserial-1310':
                    logger.info(f"找到指定的单片机串口：{device}")
                    # 尝试连接，波特率115200
                    try:
                        logger.info(f"尝试连接单片机串口：{device}")
                        test_port = serial.Serial(
                            port=device,
                            baudrate=115200,
                            bytesize=serial.EIGHTBITS,
                            parity=serial.PARITY_NONE,
                            stopbits=serial.STOPBITS_ONE,
                            timeout=0.1
                        )
                        test_port.close()
                        logger.info(f"成功连接到单片机串口：{device}")
                        return device
                    except Exception as e:
                        logger.error(f"连接usbserial-1310串口失败：{str(e)}")
                        continue
            
            # 2. 查找其他usbserial端口
            for port in ports:
                device = port.device
                logger.info(f"检测到串行端口：{device}")
                description = port.description.lower() if port.description else ""
                manufacturer = port.manufacturer.lower() if port.manufacturer else ""
                product = port.product.lower() if port.product else ""
                
                logger.info(f"端口信息：设备={device}, 描述={description}, 制造商={manufacturer}, 产品={product}")
                
                # 排除usbmodem串口，这些是GM65扫码枪的
                if 'usbmodem' in device:
                    logger.info(f"排除usbmodem串口（保留给GM65）：{device}")
                    continue
                
                # 优先选择usbserial开头的串口
                if 'usbserial' in device:
                    logger.info(f"优先选择usbserial串口：{device}")
                    # 尝试连接，波特率115200
                    try:
                        logger.info(f"尝试连接单片机串口：{device}")
                        test_port = serial.Serial(
                            port=device,
                            baudrate=115200,
                            bytesize=serial.EIGHTBITS,
                            parity=serial.PARITY_NONE,
                            stopbits=serial.STOPBITS_ONE,
                            timeout=0.1
                        )
                        test_port.close()
                        logger.info(f"成功连接到单片机串口：{device}")
                        return device
                    except Exception as e:
                        logger.error(f"连接usbserial串口 {device} 失败：{str(e)}")
                        continue
            
            logger.warning("未找到可用的单片机串口")
            return None
        except Exception as e:
            logger.error(f"查找单片机串口出错：{str(e)}")
            return None
    
    def connect(self):
        """连接到单片机串口"""
        try:
            port_name = None
            
            # 检查self.serial_port的类型和状态
            if isinstance(self.serial_port, serial.Serial):
                # 已经是serial.Serial对象，检查是否打开
                if self.serial_port.is_open:
                    logger.info("串口已连接")
                    return True
                else:
                    # 关闭已有的连接
                    self.serial_port.close()
                    # 使用该对象的端口名
                    port_name = self.serial_port.port
            elif isinstance(self.serial_port, str):
                # 是字符串，直接使用
                if self.serial_port:
                    port_name = self.serial_port
                else:
                    # 空字符串，查找可用串口
                    port_name = self.find_mcu_port()
            else:
                # 不是字符串也不是serial.Serial对象，查找可用串口
                port_name = self.find_mcu_port()
            
            if not port_name:
                return False
            
            # 配置串口参数
            self.serial_port = serial.Serial(
                port=port_name,
                baudrate=115200,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.1
            )
            
            logger.info(f"成功连接到单片机串口：{port_name} (115200波特率)")
            return True
        except Exception as e:
            logger.error(f"连接单片机串口出错：{str(e)}")
            return False
    
    def start(self):
        """启动串口数据读取线程"""
        try:
            # 检查串口是否已连接（字符串类型表示未连接，Serial对象表示已连接）
            if isinstance(self.serial_port, str) or not self.serial_port.is_open:
                if not self.connect():
                    logger.error("无法连接到单片机串口，启动失败")
                    return False
        
            self.running = True
            self.serial_thread = threading.Thread(target=self.read_serial_data, daemon=True)
            self.serial_thread.start()
            logger.info("单片机串口数据读取线程已启动")
            return True
        except Exception as e:
            logger.error(f"启动单片机串口线程出错：{str(e)}")
            return False
    
    def stop(self):
        """停止串口数据读取线程"""
        self.running = False
        if self.serial_thread and self.serial_thread.is_alive():
            self.serial_thread.join(1)
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
        logger.info("单片机串口数据读取线程已停止")
    
    def calculate_checksum(self, data):
        """计算校验和（不包括校验位和帧尾）"""
        checksum = 0
        for byte in data:
            checksum += byte
        return checksum & 0xFF
    
    def save_data_to_json(self, data):
        """将传感器数据保存到JSON文件"""
        try:
            import json
            
            # 确保data目录存在
            data_dir = "data"
            if not os.path.exists(data_dir):
                os.makedirs(data_dir)
            
            # 读取现有数据或初始化
            serial_data = {
                "sensor_status": [0, 0, 0, 0],
                "total_weight": 0.0,
                "stable_flag": 0,
                "timestamp": 0
            }
            
            # 检查serial_data.json是否存在，存在则读取
            json_path = os.path.join(data_dir, "serial_data.json")
            if os.path.exists(json_path):
                try:
                    with open(json_path, "r", encoding="utf-8") as f:
                        serial_data = json.load(f)
                except Exception as e:
                    logger.error(f"读取serial_data.json出错：{str(e)}")
            
            need_save = False
            
            # 场景1：当四个变量有一个数据非0时就记录四个变量的值，只改变sensor_status
            if any(status != 0 for status in data['sensor_status']):
                serial_data["sensor_status"] = data["sensor_status"]
                serial_data["timestamp"] = data["timestamp"]
                logger.info(f"更新sensor_status：{data['sensor_status']}")
                need_save = True
            
            # 场景2：total_weight是否记录和sensor_status无关，只有当stable_flag为1时才记录total_weight，只改变total_weight
            if data["stable_flag"] == 1:
                serial_data["total_weight"] = data["total_weight"]
                serial_data["stable_flag"] = data["stable_flag"]
                serial_data["timestamp"] = data["timestamp"]
                logger.info(f"更新total_weight：{data['total_weight']} (stable_flag=1)")
                need_save = True
            
            # 只有当需要保存时才写入文件
            if need_save:
                with open(json_path, "w", encoding="utf-8") as f:
                    json.dump(serial_data, f, indent=4, ensure_ascii=False)
                logger.info(f"已保存数据到 {json_path}")
        except Exception as e:
            logger.error(f"保存数据到JSON文件出错：{str(e)}")
    
    def parse_data(self, raw_data):
        """解析单片机发送的数据"""
        try:
            # 检查数据长度
            if len(raw_data) != FRAME_LENGTH:
                logger.warning(f"数据长度错误，期望 {FRAME_LENGTH} 字节，实际 {len(raw_data)} 字节")
                return None
            
            # 检查帧头
            if raw_data[:2] != FRAME_HEADER:
                logger.warning(f"帧头错误：{raw_data[:2].hex()}")
                return None
            
            # 检查帧尾
            if raw_data[-2:] != FRAME_FOOTER:
                logger.warning(f"帧尾错误：{raw_data[-2:].hex()}")
                return None
            
            # 提取数据部分和校验位
            # 数据结构：帧头(2) + sensor_status(4) + total_weight(4) + stable_flag(1) + checksum(1) + 帧尾(2)
            frame_header = raw_data[0:2]            # 帧头（2字节）
            sensor_status_bytes = raw_data[2:6]      # 传感器状态（4字节）
            total_weight_bytes = raw_data[6:10]      # 总重量（4字节）
            stable_flag = raw_data[10]               # 稳定标志（1字节）
            received_checksum = raw_data[11]         # 接收到的校验位（1字节）
            
            # 计算校验和的数据部分：帧头 + sensor_status + total_weight + stable_flag
            # 校验和是没加上校验位和帧尾的
            data_for_checksum = raw_data[0:11]  # 包括帧头，不包括校验位和帧尾
            
            # 计算校验和
            calculated_checksum = self.calculate_checksum(data_for_checksum)
            
            # 验证校验和
            if received_checksum == calculated_checksum:
                logger.debug(f"校验和正确：{calculated_checksum}")
            else:
                logger.warning(f"校验和错误：期望 {calculated_checksum}，实际 {received_checksum}")
                # 校验和错误时继续解析数据，方便调试
            
            # 解析数据
            sensor_status = list(sensor_status_bytes)  # 传感器状态
            
            # 尝试使用不同字节序解析重量，选择更合理的值
            try:
                # 大端序
                weight_big = struct.unpack('>f', total_weight_bytes)[0]
                # 小端序
                weight_little = struct.unpack('<f', total_weight_bytes)[0]
                # 选择更合理的重量值（绝对值较小的那个）
                total_weight = weight_little if abs(weight_little) < abs(weight_big) else weight_big
            except Exception as e:
                logger.error(f"解析重量出错：{str(e)}")
                total_weight = 0.0
            
            # 构造解析后的数据
            parsed_data = {
                "sensor_status": sensor_status,
                "total_weight": round(total_weight, 2),
                "stable_flag": stable_flag,
                "timestamp": time.time()
            }
            
            logger.info(f"解析后的数据：{parsed_data}")
            return parsed_data
        except Exception as e:
            logger.error(f"解析数据出错：{str(e)}")
            return None
    
    def read_serial_data(self):
        """串口数据读取线程"""
        logger.info("单片机串口数据读取线程开始运行")
        buffer = b''
        retry_count = 0
        max_retries = 5
        
        while self.running:
            try:
                if not self.serial_port or not self.serial_port.is_open:
                    logger.warning("单片机串口未连接，尝试重新连接")
                    # 关闭当前可能无效的串口
                    if self.serial_port:
                        try:
                            self.serial_port.close()
                            logger.info("已关闭无效的串口连接")
                        except Exception as close_e:
                            logger.error(f"关闭串口时出错：{str(close_e)}")
                    # 将serial_port设置为None，确保重新连接
                    self.serial_port = None
                    
                    # 尝试重新连接
                    if self.connect():
                        retry_count = 0  # 重置重试计数
                        logger.info("成功重新连接到串口")
                    else:
                        retry_count += 1
                        logger.warning(f"重新连接失败，重试次数：{retry_count}/{max_retries}")
                        if retry_count >= max_retries:
                            logger.error("达到最大重试次数，将继续尝试但降低频率")
                            time.sleep(5)  # 降低重试频率
                        else:
                            time.sleep(1)
                        continue
                
                # 读取所有可用数据
                try:
                    raw_bytes = self.serial_port.read_all()
                    if raw_bytes:
                        logger.info(f"读取到 {len(raw_bytes)} 字节原始数据：{raw_bytes.hex()}")
                        buffer += raw_bytes
                        
                        # 查找完整的帧
                        while len(buffer) >= FRAME_LENGTH:
                            # 查找帧头
                            header_pos = buffer.find(FRAME_HEADER)
                            if header_pos == -1:
                                # 没有找到帧头，清空缓冲区
                                buffer = b''
                                break
                            
                            # 调整缓冲区，从帧头开始
                            buffer = buffer[header_pos:]
                            
                            # 检查是否有完整的帧
                            if len(buffer) < FRAME_LENGTH:
                                break
                            
                            # 提取完整的帧
                            frame = buffer[:FRAME_LENGTH]
                            # 记录完整的帧数据
                            logger.info(f"提取完整帧数据：{frame.hex()}")
                            # 解析帧
                            parsed_data = self.parse_data(frame)
                            if parsed_data:
                                # 更新传感器数据
                                self.sensor_data = parsed_data
                                # 调用回调函数
                                if self.data_callback:
                                    self.data_callback(parsed_data)
                                
                                # 总是保存数据，因为save_data_to_json方法内部会判断是否需要更新
                                self.save_data_to_json(parsed_data)
                            
                            # 移除已处理的帧
                            buffer = buffer[FRAME_LENGTH:]
                    else:
                        # 短暂休眠，避免CPU占用过高
                        time.sleep(0.05)
                except Exception as read_e:
                    # 读取数据时出错，可能是设备断开
                    logger.error(f"读取串口数据时出错：{str(read_e)}")
                    # 关闭当前串口，下次循环会重新连接
                    try:
                        self.serial_port.close()
                        self.serial_port = None
                        logger.info("已关闭出错的串口连接")
                    except Exception as close_e:
                        logger.error(f"关闭串口时出错：{str(close_e)}")
                    time.sleep(1)
            except Exception as e:
                logger.error(f"串口读取过程中发生异常：{str(e)}")
                # 关闭当前串口，下次循环会重新连接
                try:
                    if self.serial_port:
                        self.serial_port.close()
                        self.serial_port = None
                        logger.info("已关闭出错的串口连接")
                except Exception as close_e:
                    logger.error(f"关闭串口时出错：{str(close_e)}")
                time.sleep(1)
        
        logger.info("单片机串口数据读取线程结束运行")
    
    def set_data_callback(self, callback):
        """设置数据回调函数"""
        self.data_callback = callback
    
    def get_sensor_data(self):
        """获取当前传感器数据"""
        return self.sensor_data.copy()

# 测试代码
if __name__ == "__main__":
    def test_callback(data):
        """测试数据回调函数"""
        print(f"回调函数收到数据：{data}")
        
        import json
        import os
        
        # 读取现有数据或初始化
        serial_data = {
            "sensor_status": [0, 0, 0, 0],
            "total_weight": 0.0,
            "stable_flag": 0,
            "timestamp": 0
        }
        
        # 检查serial_data.json是否存在，存在则读取
        serial_data_path = os.path.join("data", "serial_data.json")
        if os.path.exists(serial_data_path):
            try:
                with open(serial_data_path, "r", encoding="utf-8") as f:
                    serial_data = json.load(f)
            except Exception as e:
                print(f"读取serial_data.json出错：{str(e)}")
        
        need_save = False
        
        # 场景1：当四个变量有一个数据非0时就记录四个变量的值，只改变sensor_status
        if any(status != 0 for status in data['sensor_status']):
            serial_data["sensor_status"] = data["sensor_status"]
            serial_data["timestamp"] = data["timestamp"]
            print(f"更新sensor_status：{data['sensor_status']}")
            need_save = True
        
        # 场景2：total_weight是否记录和sensor_status无关，只有当stable_flag为1时才记录total_weight，只改变total_weight
        if data["stable_flag"] == 1:
            serial_data["total_weight"] = data["total_weight"]
            serial_data["stable_flag"] = data["stable_flag"]
            serial_data["timestamp"] = data["timestamp"]
            print(f"更新total_weight：{data['total_weight']} (stable_flag=1)")
            need_save = True
        
        if need_save:
            try:
                # 确保data目录存在
                if not os.path.exists("data"):
                    os.makedirs("data")
                
                # 保存更新后的数据
                with open(serial_data_path, "w", encoding="utf-8") as f:
                    json.dump(serial_data, f, indent=4, ensure_ascii=False)
                print(f"已保存数据到 {serial_data_path}")
            except Exception as e:
                print(f"保存数据到JSON文件出错：{str(e)}")
    
    mcu_serial = MCUSerial()
    mcu_serial.set_data_callback(test_callback)
    if mcu_serial.start():
        try:
            print("单片机串口通信已启动，按Ctrl+C退出")
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n退出程序")
            mcu_serial.stop()
    else:
        print("启动失败")