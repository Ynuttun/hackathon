#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
USB摄像头AI识别应用 - 线程类
"""

import cv2
import requests
import base64
import json
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QMessageBox

from utils import logger

class CameraThread(QThread):
    """摄像头采集线程"""
    frame_ready = pyqtSignal(QImage)  # 帧准备好信号
    
    def __init__(self, camera_config=None):
        super().__init__()
        self.cap = None
        self.running = False
        self.camera_config = camera_config or {}
        
    def run(self):
        """运行摄像头采集"""
        device_index = self.camera_config.get("device_index", 0)
        self.cap = cv2.VideoCapture(device_index)
        
        # 设置摄像头参数以提高性能
        if "frame_width" in self.camera_config:
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.camera_config["frame_width"])
        if "frame_height" in self.camera_config:
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.camera_config["frame_height"])
        
        # 设置缓冲区大小为1，减少延迟
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        
        if not self.cap.isOpened():
            QMessageBox.critical(None, "错误", "无法打开摄像头！")
            return
        
        self.running = True
        while self.running:
            ret, frame = self.cap.read()
            if ret:
                # 转换为RGB格式
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                # 转换为QImage
                h, w, ch = rgb_frame.shape
                bytes_per_line = ch * w
                q_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
                self.frame_ready.emit(q_image)
        
        # 释放资源
        if self.cap:
            self.cap.release()
    
    def stop(self):
        """停止摄像头采集"""
        self.running = False
        self.wait()

class AIDetectionThread(QThread):
    """AI识别线程"""
    result_ready = pyqtSignal(str)  # 识别结果信号
    error_occurred = pyqtSignal(str)  # 错误信号
    
    def __init__(self, image_path, config):
        super().__init__()
        self.image_path = image_path
        self.config = config
    
    def run(self):
        """运行AI识别"""
        try:
            # 从配置中获取API密钥
            api_config = self.config.get("baidu_ai", {})
            api_key = api_config.get("api_key", "your_api_key_here")
            secret_key = api_config.get("secret_key", "your_secret_key_here")
            
            # 检查是否使用默认值
            if api_key == "your_api_key_here" or secret_key == "your_secret_key_here":
                self.error_occurred.emit("请在config.json中配置正确的API Key和Secret Key")
                return
            
            # 读取图片并进行Base64编码
            with open(self.image_path, 'rb') as f:
                image_data = f.read()
            encoded_image = base64.b64encode(image_data).decode('utf-8')
            
            # 获取百度AI的access token
            token_url = f"https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={api_key}&client_secret={secret_key}"
            token_response = requests.post(token_url)
            token_json = token_response.json()
            access_token = token_json.get("access_token")
            
            if not access_token:
                error_msg = token_json.get("error_description", "未知错误")
                self.error_occurred.emit(f"获取AI服务授权失败: {error_msg}，请检查API Key和Secret Key")
                return
            
            # 调用图像识别API
            detection_url = f"https://aip.baidubce.com/rest/2.0/image-classify/v2/advanced_general?access_token={access_token}"
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            data = {'image': encoded_image}
            
            response = requests.post(detection_url, headers=headers, data=data)
            result = response.json()
            
            if "error_code" in result:
                self.error_occurred.emit(f"AI识别失败：{result.get('error_msg', '未知错误')}")
                return
            
            # 处理识别结果
            if "result" in result and result["result"]:
                # 获取置信度最高的结果
                top_results = sorted(result["result"], key=lambda x: x["score"], reverse=True)
                top_result = top_results[0]
                item_name = top_result["keyword"]
                confidence = round(top_result["score"] * 100, 2)
                self.result_ready.emit(f"画面中央的物品是：{item_name} (置信度: {confidence}%)")
            else:
                self.result_ready.emit("未识别到明确的物品")
                
        except Exception as e:
            self.error_occurred.emit(f"识别过程出错：{str(e)}")

class DeepseekThread(QThread):
    """Deepseek API调用线程，用于查询物品保质期"""
    result_ready = pyqtSignal(str)  # 保质期查询结果信号
    error_occurred = pyqtSignal(str)  # 错误信号
    
    def __init__(self, item_name, config):
        super().__init__()
        self.item_name = item_name
        self.config = config
    
    def run(self):
        """运行Deepseek API查询"""
        try:
            # 从配置中获取Deepseek API密钥
            deepseek_config = self.config.get("deepseek", {})
            api_key = deepseek_config.get("api_key", "your_deepseek_api_key_here")
            
            # 检查是否使用默认值
            if api_key == "your_deepseek_api_key_here":
                # 如果没有配置API密钥，返回默认保质期
                self.result_ready.emit("30")
                return
            
            # 调用Deepseek API
            url = "https://api.deepseek.com/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            # 构建请求数据
            messages = [
                {
                    "role": "system",
                    "content": "你是一个物品保质期专家，请根据以下规则回答问题：\n1. 基于你的知识回答该物品在冰箱(4°C左右)保存中的推荐保质期天数\n2. 请根据物品类型返回准确的保质期：\n   - 新鲜水果(如苹果、香蕉、橙子)：通常7-14天\n   - 新鲜蔬菜(如菠菜、生菜、胡萝卜)：通常3-7天\n   - 奶制品(如牛奶、酸奶、奶酪)：通常7-14天\n   - 肉类(如鸡肉、猪肉、牛肉)：通常1-3天\n   - 鱼类(如三文鱼、鳕鱼、虾)：通常1-2天\n   - 加工食品(如罐头、饼干、方便面)：通常180-365天\n   - 饮料(如可乐、果汁、茶)：通常90-180天\n3. 只需要返回数字，不需要单位\n4. 请根据具体物品返回准确的保质期，不要对所有物品都返回相同值\n5. 如果无法确定，请回答30"
                },
                {
                    "role": "user",
                    "content": f"{self.item_name}在冰箱保存中的推荐保质期是多少天？"
                }
            ]
            
            data = {
                "model": "deepseek-chat",
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 50
            }
            
            try:
                response = requests.post(url, headers=headers, json=data, timeout=15)
                logger.debug(f"Deepseek API响应状态码：{response.status_code}")
                logger.debug(f"Deepseek API响应头：{dict(response.headers)}")
                
                # 尝试解析响应内容
                try:
                    response_content = response.text
                    logger.debug(f"Deepseek API响应内容：{response_content}")
                    result = response.json()
                except ValueError:
                    # 响应不是有效的JSON
                    logger.error(f"Deepseek API返回非JSON响应：{response_content}")
                    self.error_occurred.emit(f"Deepseek API返回无效响应：{response_content}")
                    return
                
                if not response.ok:
                    # 处理HTTP错误
                    error_msg = result.get('error', {}).get('message', str(result))
                    logger.error(f"Deepseek API请求失败：{response.status_code} {response.reason} - {error_msg}")
                    self.error_occurred.emit(f"Deepseek API请求失败：{response.status_code} {response.reason} - {error_msg}")
                    return
                
                if "error" in result:
                    # 处理API返回的错误
                    error_msg = result.get('error', {}).get('message', '未知错误')
                    logger.error(f"Deepseek查询失败：{error_msg}")
                    self.error_occurred.emit(f"Deepseek查询失败：{error_msg}")
                    return
            except requests.exceptions.RequestException as e:
                logger.error(f"Deepseek API请求异常：{str(e)}")
                self.error_occurred.emit(f"Deepseek API请求异常：{str(e)}")
                return
            
            # 获取模型响应
            message = result.get("choices", [])[0].get("message", {})
            full_response = message.get("content", "30").strip()
            
            # 只保留数字部分作为保质期
            shelf_life = ''.join([c for c in full_response if c.isdigit()])
            if not shelf_life:
                shelf_life = "30"
            
            logger.info(f"Deepseek查询成功，完整回答：'{full_response}'，提取保质期：{shelf_life}天")
            self.result_ready.emit(shelf_life)
            
        except Exception as e:
            logger.error(f"Deepseek查询异常：{str(e)}")
            # 如果API调用失败，返回默认保质期30天
            self.result_ready.emit("30")

class EANQueryThread(QThread):
    """EAN码查询线程，先通过Open Food Facts获取商品名称，再通过Deepseek获取保质期；如果Open Food Facts返回未知EAN码，则直接将EAN码发给Deepseek"""
    result_ready = pyqtSignal(str)  # 商品信息查询结果信号（完整JSON字符串）
    error_occurred = pyqtSignal(str)  # 错误信号
    
    def __init__(self, ean_code, config):
        super().__init__()
        self.ean_code = ean_code
        self.config = config
    
    def run(self):
        """运行EAN码查询：先通过Open Food Facts获取商品名称，再通过Deepseek获取保质期；如果Open Food Facts返回未知EAN码，则直接将EAN码发给Deepseek"""
        try:
            # 步骤1：通过Open Food Facts API获取商品名称
            product_name = self.get_product_name_from_open_food_facts()
            logger.info(f"从Open Food Facts获取到商品名称：{product_name}")
            
            # 步骤2：根据商品名称是否已知，选择不同的Deepseek查询方式
            if product_name != "未知EAN码":
                # 如果商品名称已知，只查询保质期
                shelf_life_days = self.get_shelf_life_from_deepseek(product_name)
                logger.info(f"从Deepseek获取到保质期：{shelf_life_days}天")
                
                # 构建最终结果
                result = {
                    "product_name": product_name,
                    "shelf_life_days": shelf_life_days
                }
            else:
                # 如果商品名称未知，将EAN码发给Deepseek查询名称和保质期
                logger.info(f"Open Food Facts无法识别EAN码 {self.ean_code}，直接发送给Deepseek查询")
                result = self.get_product_info_from_deepseek()
                logger.info(f"从Deepseek获取到完整商品信息：{result}")
            
            # 发送结果
            self.result_ready.emit(json.dumps(result, ensure_ascii=False))
            
        except Exception as e:
            logger.error(f"EAN码查询异常：{str(e)}")
            # 如果查询失败，返回默认结果
            default_result = '{"product_name": "未知EAN码", "shelf_life_days": 30}'
            self.result_ready.emit(default_result)
    
    def get_product_name_from_open_food_facts(self):
        """通过Open Food Facts API获取EAN码对应的中文商品名称"""
        try:
            # Open Food Facts API URL
            url = f"https://world.openfoodfacts.org/api/v0/product/{self.ean_code}.json"
            logger.debug(f"调用Open Food Facts API：{url}")
            
            # 发送请求
            response = requests.get(url, timeout=10)
            logger.debug(f"Open Food Facts API响应状态码：{response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                logger.debug(f"Open Food Facts API响应结果：{result}")
                
                # 检查产品是否存在
                if result.get("status") == 1 and "product" in result:
                    product = result["product"]
                    
                    # 尝试获取中文商品名称
                    product_name = product.get("product_name_zh", "")
                    
                    # 如果没有中文名称，尝试获取英文名称或通用名称
                    if not product_name:
                        product_name = product.get("product_name_en", "")
                    if not product_name:
                        product_name = product.get("product_name", "")
                    if not product_name:
                        product_name = product.get("generic_name_zh", "")
                    if not product_name:
                        product_name = product.get("generic_name_en", "")
                    if not product_name:
                        product_name = product.get("generic_name", "")
                    
                    # 如果还是没有获取到名称，返回默认值
                    if product_name:
                        return product_name.strip()
            
            # 如果API调用失败或产品不存在，返回默认值
            logger.warning(f"无法从Open Food Facts获取EAN码 {self.ean_code} 的商品名称")
            return "未知EAN码"
            
        except Exception as e:
            logger.error(f"调用Open Food Facts API出错：{str(e)}")
            return "未知EAN码"
    
    def get_shelf_life_from_deepseek(self, product_name):
        """通过Deepseek API获取商品保质期"""
        try:
            # 从配置中获取Deepseek API密钥
            deepseek_config = self.config.get("deepseek", {})
            api_key = deepseek_config.get("api_key", "your_deepseek_api_key_here")
            
            # 如果没有配置API密钥，返回默认保质期
            if api_key == "your_deepseek_api_key_here":
                logger.warning("未配置Deepseek API密钥，使用默认保质期")
                return 30
            
            # 调用Deepseek API
            url = "https://api.deepseek.com/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            # 构建请求数据
            messages = [
                {
                    "role": "system",
                    "content": "你是一个物品保质期专家，请根据以下规则回答问题：\n1. 基于你的知识回答该物品在冰箱保存中的推荐保质期天数\n2. 只需要返回数字，不需要单位\n3. 如果无法确定，请回答30"
                },
                {
                    "role": "user",
                    "content": f"{product_name}在冰箱保存中的推荐保质期是多少天？"
                }
            ]
            
            data = {
                "model": "deepseek-chat",
                "messages": messages,
                "temperature": 0.3,
                "max_tokens": 50
            }
            
            # 发送请求
            response = requests.post(url, headers=headers, json=data, timeout=15)
            logger.debug(f"Deepseek API响应状态码：{response.status_code}")
            
            # 解析响应
            result = response.json()
            
            if "choices" in result and result["choices"]:
                message = result["choices"][0]["message"]
                full_response = message["content"].strip()
                
                # 只保留数字部分作为保质期
                shelf_life = ''.join([c for c in full_response if c.isdigit()])
                if shelf_life:
                    return int(shelf_life)
            
            # 如果API调用失败或解析失败，返回默认值
            logger.warning(f"无法从Deepseek获取 {product_name} 的保质期，使用默认值")
            return 30
            
        except Exception as e:
            logger.error(f"调用Deepseek API出错：{str(e)}")
            return 30
    
    def get_product_info_from_deepseek(self):
        """通过Deepseek API获取EAN码对应的商品名称和保质期"""
        try:
            # 从配置中获取Deepseek API密钥
            deepseek_config = self.config.get("deepseek", {})
            api_key = deepseek_config.get("api_key", "your_deepseek_api_key_here")
            
            # 如果没有配置API密钥，返回默认结果
            if api_key == "your_deepseek_api_key_here":
                logger.warning("未配置Deepseek API密钥，使用默认结果")
                return {"product_name": "未知EAN码", "shelf_life_days": 30}
            
            # 调用Deepseek API
            url = "https://api.deepseek.com/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            # 构建请求数据
            messages = [
                {
                    "role": "system",
                    "content": "你是一个商品信息专家，请根据以下规则回答问题：\n1. 基于你的知识回答EAN码对应的商品名称和保质期（以天为单位）\n2. 请以JSON格式返回，键名为'product_name'和'shelf_life_days'\n3. 例如：{\"product_name\": \"商品名称\", \"shelf_life_days\": 365}\n4. 如果找不到该EAN码的信息，请返回{\"product_name\": \"未知EAN码\", \"shelf_life_days\": 30}"
                },
                {
                    "role": "user",
                    "content": f"请告诉我EAN码为{self.ean_code}的商品名称和保质期（以天为单位）"
                }
            ]
            
            data = {
                "model": "deepseek-chat",
                "messages": messages,
                "temperature": 0.3,
                "max_tokens": 100
            }
            
            # 发送请求
            response = requests.post(url, headers=headers, json=data, timeout=15)
            logger.debug(f"Deepseek API响应状态码：{response.status_code}")
            logger.debug(f"Deepseek API响应头：{dict(response.headers)}")
            
            # 尝试解析响应内容
            try:
                response_content = response.text
                logger.debug(f"Deepseek API响应内容：{response_content}")
                result = response.json()
            except ValueError:
                # 响应不是有效的JSON
                logger.error(f"Deepseek API返回非JSON响应：{response_content}")
                return {"product_name": "未知EAN码", "shelf_life_days": 30}
            
            if not response.ok:
                # 处理HTTP错误
                error_msg = result.get('error', {}).get('message', str(result))
                logger.error(f"Deepseek API请求失败：{response.status_code} {response.reason} - {error_msg}")
                return {"product_name": "未知EAN码", "shelf_life_days": 30}
            
            if "error" in result:
                # 处理API返回的错误
                error_msg = result.get('error', {}).get('message', '未知错误')
                logger.error(f"Deepseek查询失败：{error_msg}")
                return {"product_name": "未知EAN码", "shelf_life_days": 30}
            
            # 获取模型响应
            message = result.get("choices", [])[0].get("message", {})
            full_response = message.get("content", '{"product_name": "未知EAN码", "shelf_life_days": 30}').strip()
            
            logger.info(f"Deepseek查询成功，完整回答：'{full_response}'")
            
            # 解析JSON结果
            try:
                product_info = json.loads(full_response)
                return {
                    "product_name": product_info.get("product_name", "未知EAN码"),
                    "shelf_life_days": product_info.get("shelf_life_days", 30)
                }
            except json.JSONDecodeError:
                logger.error(f"无法解析Deepseek返回的JSON：{full_response}")
                return {"product_name": "未知EAN码", "shelf_life_days": 30}
            
        except Exception as e:
            logger.error(f"调用Deepseek API出错：{str(e)}")
            return {"product_name": "未知EAN码", "shelf_life_days": 30}


class DeepseekRecipeThread(QThread):
    """调用Deepseek API生成菜谱的线程"""
    # 信号定义
    result_ready = pyqtSignal(list)  # 返回生成的菜谱列表
    error_occurred = pyqtSignal(str)  # 返回错误信息
    
    def __init__(self, inventory, warning_items, config, spice_level="默认", taste_preference="默认", servings=1, health="", parent=None):
        super().__init__(parent)
        self.inventory = inventory
        self.warning_items = warning_items
        self.config = config
        self.spice_level = spice_level
        self.taste_preference = taste_preference
        self.servings = servings
        self.health = health
    
    def run(self):
        """线程运行函数，调用Deepseek API生成菜谱"""
        import requests
        import json
        from utils import logger
        
        try:
            # 检查配置
            deepseek_config = self.config.get("deepseek", {})
            api_key = deepseek_config.get("api_key", "")
            
            if not api_key:
                logger.error("Deepseek API密钥未配置")
                self.error_occurred.emit("Deepseek API密钥未配置")
                return
            
            # 构建请求URL和头部
            url = "https://api.deepseek.com/v1/chat/completions"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}"
            }
            
            # 构建库存信息字符串
            inventory_str = "\n".join([f"- {item['item_name']}: {item['weight']}g" for item in self.inventory])
            
            # 构建预警食材字符串
            warning_str = "\n".join([f"- {item['item_name']}: {item['weight']}g (剩余{str(item['remaining_days'])}天)" for item in self.warning_items])
            
            # 构建系统提示
            system_prompt = "你是一个智能菜谱生成助手，请根据用户提供的库存信息和预警食材，生成3个实用的菜谱。每次生成时请确保菜谱的多样性，避免重复之前生成过的菜谱结构和内容。使用不同的烹饪方法、配料组合和菜品类型。必须严格使用用户提供的库存食材，不得添加任何额外食材。"
            
            # 构建用户提示
            user_prompt = f"请根据以下信息生成3个推荐菜谱：\n\n" \
                       f"用餐人数：{self.servings}人\n\n" \
                       f"库存食材：\n{inventory_str}\n\n" \
                       f"保质期预警食材（**请优先使用，尽量用完**）：\n{warning_str}\n\n" \
                       f"个人健康情况：{self.health if self.health else '无特殊情况'}\n\n" \
                       f"要求：\n" \
                       f"1. 每个菜谱包含：名字、制作方式、需要的配料、需要的食材重量、制作时间、health_advice\n" \
                       f"2. **绝对优先使用临期的预警食材**，每个菜谱尽量包含至少一种预警食材\n" \
                       f"3. **必须严格使用库存中的食材，不得添加任何额外食材**\n" \
                       f"4. 食材用量要适合{self.servings}人食用，合理调整分量\n" \
                       f"5. 尽量充分利用库存食材，减少浪费\n" \
                       f"6. 生成的菜谱要实用、常见\n" \
                       f"7. health_advice部分需包含：适合做什么菜、补充什么营养、可以购买什么食材、健康建议\n" \
                       f"8. 请以JSON格式返回，包含3个菜谱对象的数组\n" \
                       f"9. JSON格式示例：\n" \
                       f"[{{\"name\": \"菜谱名称\", \"ingredients\": [\"食材1 100g\", \"食材2 50g\"], \"seasonings\": [\"配料1 5g\", \"配料2 3g\"], \"instructions\": \"制作步骤\", \"cooking_time\": \"30分钟\", \"health_advice\": \"健康建议内容\"}}]\n" \
                       f"10. 请确保JSON格式正确，不要包含任何其他内容" \
                       f"11. 请确保每次生成的菜谱都不同，多样性要强\n" \
                       f"12. 请确保返回的JSON格式严格符合要求，不要包含任何额外的解释或文本" \
                       f"13. 所有菜谱必须使用库存中的食材，不要添加任何额外食材" \
                       f"14. 请确保每个菜谱都明确指定所需的食材重量\n" \
                       f"15. 制作步骤要详细，易于理解" \
                       f"16. 生成的菜谱要符合中国家庭口味" \
                       f"17. health_advice要根据用户提供的健康情况给出针对性的建议"
            
            # 添加辣度和口味偏好到用户提示
            final_prompt = user_prompt
            if self.spice_level != "默认":
                final_prompt += f"\n\n额外要求：\n1. 辣度要求：{self.spice_level}\n"
            
            if self.taste_preference != "默认":
                if self.spice_level == "默认":
                    final_prompt += f"\n\n额外要求：\n1. 口味要求：{self.taste_preference}\n"
                else:
                    final_prompt += f"2. 口味要求：{self.taste_preference}\n"
            
            # 构建请求数据
            messages = [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": final_prompt
                }
            ]
            
            import random
            # 使用较高的temperature值增加随机性，每次调用使用不同的随机值
            random_temperature = round(random.uniform(0.7, 1.0), 2)
            
            data = {
                "model": "deepseek-chat",
                "messages": messages,
                "temperature": random_temperature,
                "max_tokens": 2000
            }
            
            import time
            max_retries = 3
            base_retry_delay = 5  # 基础重试延迟（秒）
            timeout = 120  # 增加超时时间到120秒
            
            for retry in range(max_retries):
                try:
                    # 实现指数退避策略，每次重试延迟时间翻倍
                    retry_delay = base_retry_delay * (2 ** retry)
                    logger.debug(f"第 {retry+1}/{max_retries} 次调用Deepseek API，超时时间：{timeout}秒")
                    
                    # 发送请求，使用较长的超时时间
                    response = requests.post(url, headers=headers, json=data, timeout=timeout)
                    logger.debug(f"Deepseek API响应状态码：{response.status_code}")
                    
                    # 尝试解析响应内容
                    response_content = response.text
                    logger.debug(f"Deepseek API响应内容：{response_content}")
                    result = response.json()
                    
                    if not response.ok:
                        # 处理HTTP错误
                        error_msg = result.get('error', {}).get('message', str(result))
                        logger.error(f"Deepseek API请求失败：{response.status_code} {response.reason} - {error_msg}")
                        self.error_occurred.emit(f"API请求失败：{error_msg}")
                        return
                    
                    if "error" in result:
                        # 处理API返回的错误
                        error_msg = result.get('error', {}).get('message', '未知错误')
                        logger.error(f"Deepseek查询失败：{error_msg}")
                        self.error_occurred.emit(f"API查询失败：{error_msg}")
                        return
                    
                    # 请求成功，跳出循环
                    break
                except requests.exceptions.Timeout:
                    # 处理超时错误
                    logger.error(f"Deepseek API请求超时，正在重试 ({retry+1}/{max_retries})，下次重试延迟 {retry_delay} 秒...")
                    if retry < max_retries - 1:
                        time.sleep(retry_delay)
                    else:
                        logger.error(f"Deepseek API请求超时，已重试{max_retries}次，放弃请求")
                        self.error_occurred.emit("请求超时，请稍后重试")
                        return
                except requests.exceptions.ConnectionError as e:
                    # 单独处理连接错误，提供更友好的错误信息
                    logger.error(f"Deepseek API连接错误：{str(e)}")
                    if retry < max_retries - 1:
                        time.sleep(retry_delay)
                    else:
                        self.error_occurred.emit("网络连接错误，请检查网络设置")
                        return
                except ValueError:
                    # 响应不是有效的JSON
                    logger.error(f"Deepseek API返回非JSON响应：{response_content if 'response_content' in locals() else '无响应内容'}")
                    self.error_occurred.emit("Deepseek API返回非JSON响应")
                    return
                except Exception as e:
                    # 处理其他异常
                    logger.error(f"调用Deepseek API出错：{str(e)}")
                    self.error_occurred.emit(str(e))
                    return
            
            # 获取模型响应
            message = result.get("choices", [])[0].get("message", {})
            full_response = message.get("content", '[]').strip()
            
            logger.info(f"Deepseek查询成功，完整回答：'{full_response}'")
            
            # 解析JSON结果
            try:
                # 1. 首先尝试直接解析
                recipes = json.loads(full_response)
                
                if isinstance(recipes, list) and len(recipes) > 0:
                    # 确保返回3个菜谱
                    if len(recipes) < 3:
                        logger.warning(f"Deepseek只返回了{len(recipes)}个菜谱，期望3个")
                    
                    self.result_ready.emit(recipes)
                    return
                else:
                    logger.error(f"Deepseek返回的不是有效的菜谱列表：{full_response}")
            except json.JSONDecodeError:
                logger.error(f"无法直接解析Deepseek返回的JSON：{full_response}")
                
            # 2. 尝试清理和重新解析
            try:
                # 去除可能的前后缀，如```json和```
                cleaned_response = full_response
                if cleaned_response.startswith('```json'):
                    cleaned_response = cleaned_response[7:]
                if cleaned_response.endswith('```'):
                    cleaned_response = cleaned_response[:-3]
                cleaned_response = cleaned_response.strip()
                
                recipes = json.loads(cleaned_response)
                if isinstance(recipes, list) and len(recipes) > 0:
                    logger.info(f"成功解析清理后的JSON，提取了{len(recipes)}个菜谱")
                    self.result_ready.emit(recipes)
                    return
                else:
                    logger.error(f"清理后仍不是有效的菜谱列表：{cleaned_response}")
            except json.JSONDecodeError:
                logger.error(f"清理后仍无法解析JSON：{cleaned_response}")
            
            # 3. 尝试使用正则表达式提取可能的JSON内容
            try:
                import re
                # 查找可能的JSON数组
                json_match = re.search(r'\[\s*\{[\s\S]*?\}\s*\]', full_response, re.DOTALL)
                if json_match:
                    partial_json = json_match.group(0)
                    recipes = json.loads(partial_json)
                    if isinstance(recipes, list) and len(recipes) > 0:
                        logger.info(f"成功解析正则提取的JSON，提取了{len(recipes)}个菜谱")
                        self.result_ready.emit(recipes)
                        return
                    else:
                        logger.error(f"正则提取的不是有效的菜谱列表：{partial_json}")
            except Exception as e:
                logger.error(f"正则提取JSON失败：{str(e)}")
            
            # 4. 尝试最宽松的JSON提取方法
            try:
                import re
                # 查找JSON开始和结束位置
                json_start = full_response.find('[')
                json_end = full_response.rfind(']')
                if json_start != -1 and json_end != -1 and json_end > json_start:
                    loose_json = full_response[json_start:json_end+1]
                    recipes = json.loads(loose_json)
                    if isinstance(recipes, list) and len(recipes) > 0:
                        logger.info(f"成功解析宽松提取的JSON，提取了{len(recipes)}个菜谱")
                        self.result_ready.emit(recipes)
                        return
                    else:
                        logger.error(f"宽松提取的不是有效的菜谱列表：{loose_json}")
            except Exception as e:
                logger.error(f"宽松提取JSON失败：{str(e)}")
            
            # 5. 如果所有方法都失败，尝试模拟一个简单的菜谱
            try:
                # 从库存中随机选择一些食材生成简单菜谱
                import random
                
                # 确保有足够的食材
                if len(self.inventory) >= 2:
                    # 生成3个简单菜谱
                    mock_recipes = []
                    for i in range(min(3, len(self.inventory))):
                        # 随机选择2-3种食材
                        selected_items = random.sample(self.inventory, min(3, len(self.inventory)))
                        ingredients = [f"{item['item_name']} 100g" for item in selected_items]
                        
                        mock_recipe = {
                            "name": f"简单菜品{i+1}",
                            "ingredients": ingredients,
                            "seasonings": ["盐 5g", "酱油 10ml"],
                            "instructions": "1. 准备食材\n2. 烹饪\n3. 完成",
                            "cooking_time": "30分钟",
                            "health_advice": "这是一个简单的菜品，适合日常食用"
                        }
                        mock_recipes.append(mock_recipe)
                    
                    logger.warning("无法解析API返回的JSON，使用模拟菜谱")
                    self.result_ready.emit(mock_recipes)
                    return
            except Exception as e:
                logger.error(f"生成模拟菜谱失败：{str(e)}")
            
            # 如果所有方法都失败，发送错误
            self.error_occurred.emit("无法解析返回的JSON格式，请稍后重试")
            return
            
        except Exception as e:
            logger.error(f"调用Deepseek API生成菜谱出错：{str(e)}")
            self.error_occurred.emit(str(e))
            return
