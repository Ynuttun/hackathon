#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
USB摄像头AI识别应用 - 对话框类
"""

from PyQt5.QtWidgets import (QDialog, QLabel, QLineEdit, QPushButton, 
                            QVBoxLayout, QHBoxLayout, QDialogButtonBox, 
                            QMessageBox, QSpinBox, QComboBox, QListWidget,
                            QScrollArea, QGroupBox, QTextEdit, QWidget, QProgressBar)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from datetime import datetime, timedelta
import cv2

from utils import logger

class ConfirmationDialog(QDialog):
    """确认识别结果的对话框"""
    
    def __init__(self, recognized_text, parent=None):
        super().__init__(parent)
        self.setWindowTitle("确认识别结果")
        self.setModal(True)
        self.resize(400, 150)
        
        layout = QVBoxLayout()
        
        # 显示识别结果
        label = QLabel(f"识别到的物品：{recognized_text}\n请确认识别结果是否正确，或输入正确的物品名称：")
        label.setWordWrap(True)
        layout.addWidget(label)
        
        # 输入框
        self.input_field = QLineEdit()
        self.input_field.setText(recognized_text)
        layout.addWidget(self.input_field)
        
        # 按钮
        button_layout = QHBoxLayout()
        self.button_box = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        button_layout.addWidget(self.button_box)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
    
    def get_text(self):
        """获取用户输入的文本"""
        return self.input_field.text()

class ItemEditDialog(QDialog):
    """物品信息修改对话框"""
    
    def __init__(self, item_data, parent=None):
        super().__init__(parent)
        self.setWindowTitle("修改物品信息")
        self.setModal(True)
        self.resize(400, 300)
        
        self.item_data = item_data.copy()
        self.init_ui()
    
    def on_confirm(self):
        """确认修改"""
        # 获取输入值
        name = self.name_edit.text().strip()
        shelf_life_text = self.shelf_life_edit.text().strip()
        production_date = self.production_date_edit.text().strip()
        position_text = self.position_edit.text().strip()
        weight_text = self.weight_edit.text().strip()
        
        # 验证输入
        if not name:
            QMessageBox.warning(self, "警告", "物品名称不能为空")
            return
        
        if not shelf_life_text.isdigit():
            QMessageBox.warning(self, "警告", "保质期必须是数字")
            return
        
        if not position_text.isdigit():
            QMessageBox.warning(self, "警告", "位置必须是数字")
            return
        
        if not weight_text.replace('.', '', 1).isdigit():
            QMessageBox.warning(self, "警告", "重量必须是数字")
            return
        
        # 更新物品数据
        self.item_data['name'] = name
        self.item_data['shelf_life'] = int(shelf_life_text)
        self.item_data['production_date'] = production_date  # 保存修改后的生产日期
        self.item_data['position'] = int(position_text)  # 保存修改后的位置
        self.item_data['weight'] = float(weight_text)  # 保存修改后的重量
        
        # 计算新的到期日期 - 使用正确的逻辑：生产日期 + 保质期天数 - 1 = 到期日期
        try:
            # 解析修改后的生产日期
            dt = datetime.strptime(production_date, "%Y-%m-%d")
            # 计算到期日期：生产日期 + 保质期天数 - 1 = 到期日期
            # 例如：今天（0101）生产，保质期两天，到期日期为0102
            expiry_dt = dt + timedelta(days=int(shelf_life_text) - 1)
            self.item_data['expiry_date'] = expiry_dt.strftime("%Y-%m-%d")
        except ValueError as e:
            logger.error(f"更新物品日期出错：{str(e)}")
        
        self.accept()
    
    def init_ui(self):
        """初始化UI组件"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 物品名称输入
        self.name_label = QLabel("物品名称：")
        layout.addWidget(self.name_label)
        self.name_edit = QLineEdit(self.item_data['name'])
        layout.addWidget(self.name_edit)
        
        # 物品编号（只读）
        self.number_label = QLabel(f"物品编号：{self.item_data['number']}")
        layout.addWidget(self.number_label)
        
        # 生产日期输入
        self.production_date_label = QLabel("生产日期：")
        layout.addWidget(self.production_date_label)
        # 从item_data中获取production_date，如果没有则使用今天的日期
        production_date = self.item_data.get('production_date', datetime.now().strftime("%Y-%m-%d"))
        self.production_date_edit = QLineEdit(production_date)
        layout.addWidget(self.production_date_edit)
        
        # 保质期输入
        self.shelf_life_label = QLabel("保质期：")
        layout.addWidget(self.shelf_life_label)
        self.shelf_life_edit = QLineEdit(str(self.item_data['shelf_life']))
        layout.addWidget(self.shelf_life_edit)
        
        # 位置输入
        self.position_label = QLabel("位置：")
        layout.addWidget(self.position_label)
        self.position_edit = QLineEdit(str(self.item_data.get('position', 1)))
        layout.addWidget(self.position_edit)
        
        # 重量输入
        self.weight_label = QLabel("重量(g)：")
        layout.addWidget(self.weight_label)
        self.weight_edit = QLineEdit(str(self.item_data.get('weight', 100.0)))
        layout.addWidget(self.weight_edit)
        
        # 按钮布局
        button_layout = QHBoxLayout()
        
        # 取消按钮
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)
        
        # 确认按钮
        self.confirm_btn = QPushButton("确认")
        self.confirm_btn.clicked.connect(self.on_confirm)
        button_layout.addWidget(self.confirm_btn)
        
        layout.addLayout(button_layout)
    
    def get_updated_data(self):
        """获取更新后的物品数据"""
        return self.item_data

class CameraDetectionThread(QThread):
    """摄像头检测线程，用于在后台检测可用摄像头"""
    # 信号：检测完成，返回可用摄像头列表
    detection_finished = pyqtSignal(list)
    
    def run(self):
        """运行摄像头检测"""
        cameras = []
        # 使用更高效的方式检测摄像头
        
        # 导入必要的模块
        import os
        import subprocess
        import re
        import sys
        
        # 不同操作系统的摄像头检测命令
        is_mac = sys.platform.startswith('darwin')
        is_linux = sys.platform.startswith('linux')
        is_windows = sys.platform.startswith('win')
        
        detected_cameras = set()
        
        try:
            if is_mac:
                # macOS系统：使用system_profiler命令检测摄像头
                cmd = ['system_profiler', 'SPCameraDataType']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=1)
                
                if result.returncode == 0:
                    # 解析输出，查找摄像头设备
                    lines = result.stdout.split('\n')
                    camera_count = 0
                    for line in lines:
                        if 'Model ID:' in line:
                            detected_cameras.add(camera_count)
                            camera_count += 1
                            if camera_count >= 3:  # 最多检测3个摄像头
                                break
            
            elif is_linux:
                # Linux系统：使用v4l2-ctl命令检测摄像头
                cmd = ['v4l2-ctl', '--list-devices']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=1)
                
                if result.returncode == 0:
                    # 解析输出，查找视频设备
                    for line in result.stdout.split('\n'):
                        if '/dev/video' in line:
                            match = re.search(r'/dev/video(\d+)', line)
                            if match:
                                camera_id = int(match.group(1))
                                detected_cameras.add(camera_id)
                                if len(detected_cameras) >= 3:  # 最多检测3个摄像头
                                    break
            
            elif is_windows:
                # Windows系统：使用wmic命令检测摄像头
                cmd = ['wmic', 'path', 'win32_pnpentity', 'get', 'caption']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=1)
                
                if result.returncode == 0:
                    # 解析输出，查找摄像头
                    camera_count = 0
                    for line in result.stdout.split('\n'):
                        if 'Camera' in line or 'Webcam' in line or '摄像头' in line:
                            detected_cameras.add(camera_count)
                            camera_count += 1
                            if camera_count >= 3:  # 最多检测3个摄像头
                                break
        except Exception as e:
            # 如果命令行检测失败，回退到OpenCV检测，但减少检测数量
            pass
        
        # 回退到OpenCV检测（如果命令行检测失败或在不支持的平台上）
        if not detected_cameras:
            # 只检测前3个摄像头设备
            for i in range(3):
                try:
                    # 重定向OpenCV错误输出
                    import os
                    import sys
                    # 保存原始stderr
                    original_stderr = os.dup(sys.stderr.fileno())
                    # 重定向stderr到/dev/null
                    devnull = os.open(os.devnull, os.O_WRONLY)
                    os.dup2(devnull, sys.stderr.fileno())
                    
                    # 快速检测摄像头
                    cap = cv2.VideoCapture(i, cv2.CAP_DSHOW if is_windows else cv2.CAP_ANY)
                    
                    if cap.isOpened():
                        # 获取摄像头分辨率
                        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        cameras.append((i, f"摄像头 {i} ({width}x{height})"))
                        cap.release()
                    
                    # 恢复原始stderr
                    os.dup2(original_stderr, sys.stderr.fileno())
                    os.close(devnull)
                    os.close(original_stderr)
                except Exception as e:
                    # 忽略任何异常
                    try:
                        # 确保资源被释放
                        cap.release()
                    except:
                        pass
                    continue
        else:
            # 使用命令行检测到的摄像头ID，获取详细信息
            for camera_id in sorted(detected_cameras):
                try:
                    # 重定向OpenCV错误输出
                    import os
                    import sys
                    original_stderr = os.dup(sys.stderr.fileno())
                    devnull = os.open(os.devnull, os.O_WRONLY)
                    os.dup2(devnull, sys.stderr.fileno())
                    
                    cap = cv2.VideoCapture(camera_id)
                    if cap.isOpened():
                        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        cameras.append((camera_id, f"摄像头 {camera_id} ({width}x{height})"))
                        cap.release()
                    
                    # 恢复原始stderr
                    os.dup2(original_stderr, sys.stderr.fileno())
                    os.close(devnull)
                    os.close(original_stderr)
                except Exception as e:
                    # 忽略任何异常
                    try:
                        cap.release()
                    except:
                        pass
                    continue
        
        # 发送检测完成信号
        self.detection_finished.emit(cameras)

class ScannerDetectionThread(QThread):
    """扫码枪检测线程，用于在后台检测可用扫码枪"""
    # 信号：检测完成，返回可用扫码枪列表
    detection_finished = pyqtSignal(list)
    
    def run(self):
        """运行扫码枪检测"""
        scanners = []
        # 导入必要的模块
        import os
        import subprocess
        import re
        import sys
        
        # 不同操作系统的扫码枪检测命令
        is_mac = sys.platform.startswith('darwin')
        is_linux = sys.platform.startswith('linux')
        is_windows = sys.platform.startswith('win')
        
        try:
            if is_mac:
                # macOS系统：使用ioreg命令检测USB设备
                cmd = ['ioreg', '-p', 'IOUSB', '-l', '-w', '0']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
                
                if result.returncode == 0:
                    # 获取所有USB设备的完整信息
                    all_usb_info = result.stdout
                    
                    # 解析输出，查找扫码枪设备
                    lines = all_usb_info.split('\n')
                    
                    # 正则表达式模式，用于匹配设备信息
                    device_pattern = re.compile(r'\+-o\s+(.+?)@\w+\s+<class\s+IOUSBHostDevice')
                    
                    # 遍历所有行，查找设备
                    for i, line in enumerate(lines):
                        # 查找设备名称
                        match = device_pattern.search(line)
                        if match:
                            device_name = match.group(1)
                            
                            # 提取设备详细信息
                            vendor_name = ""
                            product_name = ""
                            vendor_id = ""
                            product_id = ""
                            
                            # 查找后续行中的设备信息
                            for j in range(i+1, min(i+20, len(lines))):
                                next_line = lines[j]
                                
                                # 停止条件：遇到新设备或结束当前设备
                                if device_pattern.search(next_line) or next_line.strip() == '| }':
                                    break
                                
                                # 提取USB Product Name
                                if 'USB Product Name' in next_line:
                                    product_name = next_line.split('"USB Product Name" = ')[1].strip('"')
                                # 提取USB Vendor Name
                                elif 'USB Vendor Name' in next_line:
                                    vendor_name = next_line.split('"USB Vendor Name" = ')[1].strip('"')
                                # 提取idVendor - 兼容带引号的键名和十进制值
                                elif 'idVendor' in next_line:
                                    # 提取带引号的键名和十进制值
                                    match = re.search(r'"idVendor"\s*=\s*(\d+)', next_line)
                                    if match:
                                        vendor_id = match.group(1)
                                # 提取idProduct - 兼容带引号的键名和十进制值
                                elif 'idProduct' in next_line:
                                    # 提取带引号的键名和十进制值
                                    match = re.search(r'"idProduct"\s*=\s*(\d+)', next_line)
                                    if match:
                                        product_id = match.group(1)
                            
                            # 检查是否为扫码枪设备
                            product_name_lower = product_name.lower()
                            vendor_name_lower = vendor_name.lower()
                            
                            # 调试：打印设备信息
                            print(f"检测到USB设备：{product_name} ({vendor_name})")
                            
                            # 使用更宽松的条件检测扫码枪
                            if any(keyword in product_name_lower or keyword in vendor_name_lower for keyword in ['scanner', 'barcode', 'scan', '扫码', '条码', 'gm65', 'usbkey', 'usbkey module']):
                                # 调试：打印匹配的设备
                                print(f"匹配到扫码枪：{product_name} ({vendor_name})")
                                # 构建设备ID
                                device_id = f"{vendor_id}:{product_id}"
                                scanners.append((device_id, f"{product_name} ({vendor_name})"))
                    
                    # 调试：如果没有检测到设备，添加所有USB设备信息到日志
                    if not scanners:
                        # 将所有USB设备信息写入日志文件，用于调试
                        try:
                            with open('logs/usb_devices.log', 'w') as f:
                                f.write(all_usb_info)
                        except:
                            pass
            
            elif is_linux:
                # Linux系统：使用lsusb命令检测USB设备
                cmd = ['lsusb']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
                
                if result.returncode == 0:
                    # 解析输出，查找扫码枪设备
                    for line in result.stdout.split('\n'):
                        line_lower = line.lower()
                        if 'scanner' in line_lower or 'barcode' in line_lower or 'gm65' in line_lower:
                            # 提取设备信息
                            match = re.search(r'Bus (\d+) Device (\d+): ID ([0-9a-fA-F:]+) (.+)', line)
                            if match:
                                bus = match.group(1)
                                device = match.group(2)
                                device_id = match.group(3)
                                device_name = match.group(4)
                                scanners.append((f"{bus}:{device}", f"扫码枪 {device_name} (Bus {bus}, Device {device})"))
            
            elif is_windows:
                # Windows系统：使用wmic命令检测USB设备
                cmd = ['wmic', 'path', 'win32_pnpentity', 'get', 'caption']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
                
                if result.returncode == 0:
                    # 解析输出，查找扫码枪
                    scanner_count = 0
                    for line in result.stdout.split('\n'):
                        line_lower = line.lower()
                        if 'scanner' in line_lower or 'barcode' in line_lower or 'scan' in line_lower or 'gm65' in line_lower or '扫码' in line_lower or '条码' in line_lower:
                            scanners.append((scanner_count, f"扫码枪 {scanner_count}: {line.strip()}"))
                            scanner_count += 1
                            if scanner_count >= 3:  # 最多检测3个扫码枪
                                break
        except Exception as e:
            # 记录异常信息到日志文件，用于调试
            try:
                with open('scanner_detection_error.log', 'w') as f:
                    f.write(str(e))
            except:
                pass
        
        # 发送检测完成信号
        self.detection_finished.emit(scanners)

class MCUSerialDetectionThread(QThread):
    """MCU串口检测线程，用于在后台检测可用MCU串口"""
    # 信号：检测完成，返回可用MCU串口列表
    detection_finished = pyqtSignal(list)
    
    def run(self):
        """运行MCU串口检测"""
        serial_ports = []
        # 导入必要的模块
        import os
        import subprocess
        import re
        import sys
        
        # 不同操作系统的串口检测命令
        is_mac = sys.platform.startswith('darwin')
        is_linux = sys.platform.startswith('linux')
        is_windows = sys.platform.startswith('win')
        
        try:
            if is_mac or is_linux:
                # macOS和Linux系统：使用ls命令检测串口设备
                cmd = ['ls', '-la', '/dev/']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
                
                if result.returncode == 0:
                    # 解析输出，查找串口设备
                    for line in result.stdout.split('\n'):
                        line_lower = line.lower()
                        # 查找串口设备，排除GM65扫码枪（usbmodem, acm），优先usbserial
                        if any(keyword in line_lower for keyword in ['usbserial', 'ttyusb', 'ttyacm', 'usbmodem']):
                            # 提取设备路径，支持包含点号和连字符的设备名称，设备名可以在行尾
                            match = re.search(r'\s+(tty[\w.-]+|cu[\w.-]+)\s*$', line)
                            if match:
                                port_name = match.group(1)
                                full_path = f"/dev/{port_name}"
                                # 排除GM65扫码枪（usbmodem）
                                if 'usbmodem' in port_name.lower():
                                    continue
                                # 添加到列表
                                serial_ports.append(full_path)
            
            elif is_windows:
                # Windows系统：使用wmic命令检测串口设备
                cmd = ['wmic', 'path', 'win32_pnpentity', 'get', 'caption']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
                
                if result.returncode == 0:
                    # 解析输出，查找串口
                    for line in result.stdout.split('\n'):
                        if 'COM' in line:
                            # 提取COM端口号
                            match = re.search(r'(COM\d+)', line)
                            if match:
                                serial_ports.append(match.group(1))
        except Exception as e:
            # 记录异常信息到日志文件，用于调试
            try:
                with open('mcu_serial_detection_error.log', 'w') as f:
                    f.write(str(e))
            except:
                pass
        
        # 对串口进行排序：usbserial开头的排在前面
        usbserial_ports = [port for port in serial_ports if 'usbserial' in port.lower()]
        other_ports = [port for port in serial_ports if 'usbserial' not in port.lower()]
        sorted_ports = usbserial_ports + other_ports
        
        # 转换为元组格式，方便在下拉框中显示
        result_ports = [(port, port) for port in sorted_ports]
        
        # 发送检测完成信号
        self.detection_finished.emit(result_ports)

class RecipeDialog(QDialog):
    """菜谱模式对话框"""
    
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.setWindowTitle("菜谱模式")
        self.setModal(True)
        self.resize(800, 600)
        
        self.config = config
        self.recipes = []
        self.recipe_thread = None
        
        # 初始化UI
        self.init_ui()
    
    def init_ui(self):
        """初始化UI组件"""
        main_layout = QVBoxLayout(self)
        
        # 顶部标题
        title_label = QLabel("智能菜谱推荐")
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; text-align: center;")
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # 辣度、口味和用餐人数选择布局
        preference_layout = QHBoxLayout()
        
        # 辣度选择
        spice_layout = QVBoxLayout()
        spice_label = QLabel("辣度：")
        spice_layout.addWidget(spice_label)
        
        self.spice_combo = QComboBox()
        self.spice_combo.addItems(["默认", "不辣", "微辣", "巨辣"])
        spice_layout.addWidget(self.spice_combo)
        preference_layout.addLayout(spice_layout)
        
        # 口味选择
        taste_layout = QVBoxLayout()
        taste_label = QLabel("口味：")
        taste_layout.addWidget(taste_label)
        
        self.taste_combo = QComboBox()
        self.taste_combo.addItems(["默认", "咸", "甜", "淡"])
        taste_layout.addWidget(self.taste_combo)
        preference_layout.addLayout(taste_layout)
        
        # 用餐人数选择
        servings_layout = QVBoxLayout()
        servings_label = QLabel("用餐人数：")
        servings_layout.addWidget(servings_label)
        
        self.servings_input = QSpinBox()
        self.servings_input.setRange(1, 10)
        self.servings_input.setSingleStep(1)
        self.servings_input.setValue(1)
        # 加载保存的用餐人数，默认1人
        self.load_servings_preference()
        servings_layout.addWidget(self.servings_input)
        preference_layout.addLayout(servings_layout)
        
        main_layout.addLayout(preference_layout)
        
        # 个人健康情况填写区域
        health_layout = QVBoxLayout()
        health_label = QLabel("个人健康情况：")
        health_label.setStyleSheet("font-weight: bold;")
        health_layout.addWidget(health_label)
        
        self.health_text = QTextEdit()
        self.health_text.setPlaceholderText("请填写您的健康情况，例如：高血压、糖尿病、过敏史等")
        self.health_text.setMinimumHeight(100)
        health_layout.addWidget(self.health_text)
        
        main_layout.addLayout(health_layout)
        
        # 加载保存的健康情况
        self.load_health_preference()
        
        # 增加窗口高度以容纳新的健康情况区域
        self.resize(800, 700)
        
        # 菜谱列表和详情区域的分割布局
        content_layout = QHBoxLayout()
        
        # 左侧菜谱列表
        list_layout = QVBoxLayout()
        
        self.recipe_list = QListWidget()
        self.recipe_list.itemClicked.connect(self.show_recipe_details)
        list_layout.addWidget(self.recipe_list)
        
        # 生成菜谱按钮
        self.generate_btn = QPushButton("生成菜谱")
        self.generate_btn.setFixedSize(120, 40)
        self.generate_btn.clicked.connect(self.generate_recipes)
        list_layout.addWidget(self.generate_btn, 0, Qt.AlignCenter)
        
        content_layout.addLayout(list_layout, 1)
        
        # 右侧菜谱详情
        details_layout = QVBoxLayout()
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)  # 不确定进度模式
        self.progress_bar.setVisible(False)  # 初始隐藏
        details_layout.addWidget(self.progress_bar)
        
        # 详情滚动区域
        self.details_scroll = QScrollArea()
        self.details_scroll.setWidgetResizable(True)
        
        self.details_widget = QWidget()
        self.details_content = QVBoxLayout(self.details_widget)
        
        # 初始详情内容
        self.initial_details = QLabel("点击左侧菜谱查看详情")
        self.initial_details.setAlignment(Qt.AlignCenter)
        self.initial_details.setStyleSheet("font-size: 18px; color: #666;")
        self.details_content.addWidget(self.initial_details)
        
        self.details_scroll.setWidget(self.details_widget)
        details_layout.addWidget(self.details_scroll, 1)
        
        content_layout.addLayout(details_layout, 2)
        
        main_layout.addLayout(content_layout, 1)
    
    def load_servings_preference(self):
        """加载保存的用餐人数偏好"""
        import json
        import os
        
        try:
            # 读取配置文件
            config_path = "data/config.json"
            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                # 获取用餐人数，默认1人
                servings = config.get("app", {}).get("servings", 1)
                # 设置到输入框
                self.servings_input.setValue(servings)
        except Exception as e:
            from utils import logger
            logger.error(f"加载用餐人数偏好出错：{str(e)}")
    
    def save_servings_preference(self, servings):
        """保存用餐人数偏好"""
        import json
        import os
        
        try:
            # 读取配置文件
            config_path = "data/config.json"
            config = {}
            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
            
            # 更新用餐人数
            if "app" not in config:
                config["app"] = {}
            config["app"]["servings"] = servings
            
            # 保存配置文件
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            from utils import logger
            logger.error(f"保存用餐人数偏好出错：{str(e)}")
    
    def load_health_preference(self):
        """加载保存的健康情况"""
        import json
        import os
        
        try:
            # 读取健康情况文件
            health_path = "data/personal_health.json"
            if os.path.exists(health_path):
                with open(health_path, "r", encoding="utf-8") as f:
                    health_data = json.load(f)
                # 获取健康情况，默认空字符串
                health = health_data.get("health", "")
                # 设置到健康情况输入框
                self.health_text.setPlainText(health)
        except Exception as e:
            from utils import logger
            logger.error(f"加载健康情况出错：{str(e)}")
    
    def save_health_preference(self, health):
        """保存健康情况"""
        import json
        import os
        from datetime import datetime
        
        try:
            # 确保data目录存在
            os.makedirs("data", exist_ok=True)
            
            # 保存健康情况到单独的JSON文件
            health_path = "data/personal_health.json"
            health_data = {
                "health": health,
                "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            # 保存配置文件
            with open(health_path, "w", encoding="utf-8") as f:
                json.dump(health_data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            from utils import logger
            logger.error(f"保存健康情况出错：{str(e)}")
    
    def generate_recipes(self):
        """生成推荐菜谱"""
        from threads import DeepseekRecipeThread
        
        # 禁用生成按钮，防止重复点击
        self.generate_btn.setEnabled(False)
        self.generate_btn.setText("生成中...")
        
        # 显示进度条
        self.progress_bar.setVisible(True)
        
        # 清空之前的菜谱列表
        self.recipe_list.clear()
        self.recipes = []
        
        # 更新详情区域为正在生成
        self.clear_details()
        generating_label = QLabel("正在生成菜谱，请稍候...")
        generating_label.setAlignment(Qt.AlignCenter)
        generating_label.setStyleSheet("font-size: 18px; color: #666;")
        self.details_content.addWidget(generating_label)
        
        # 获取用户选择的辣度、口味和用餐人数
        spice_level = self.spice_combo.currentText()
        taste_preference = self.taste_combo.currentText()
        servings = self.servings_input.value()
        # 获取用户填写的健康情况
        health = self.health_text.toPlainText().strip()
        
        # 保存用餐人数偏好
        self.save_servings_preference(servings)
        # 保存健康情况偏好
        self.save_health_preference(health)
        
        # 从recognition_log.json获取库存信息
        inventory = self.get_inventory()
        
        # 获取预警食材
        warning_items = self.get_warning_items()
        
        # 启动Deepseek线程生成菜谱，传递辣度、口味偏好、用餐人数和健康情况
        self.recipe_thread = DeepseekRecipeThread(inventory, warning_items, self.config, spice_level, taste_preference, servings, health)
        self.recipe_thread.result_ready.connect(self.on_recipes_generated)
        self.recipe_thread.error_occurred.connect(self.on_recipe_error)
        self.recipe_thread.start()
    
    def get_inventory(self):
        """从recognition_log.json获取库存信息"""
        import json
        import os
        
        inventory = []
        try:
            log_path = "data/recognition_log.json"
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        for item in items:
                            inventory.append({
                                "item_name": item["item_name"],
                                "weight": item.get("weight", 0.0)
                            })
        except Exception as e:
            from utils import logger
            logger.error(f"获取库存信息出错：{str(e)}")
        
        return inventory
    
    def get_warning_items(self):
        """获取进入保质期预警的食材"""
        import json
        import os
        from datetime import datetime
        
        warning_items = []
        try:
            # 读取配置文件中的预警天数
            config_path = "data/config.json"
            warning_days = 3  # 默认3天
            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                    warning_days = config.get("app", {}).get("warning_days", 3)
            
            # 读取库存信息
            log_path = "data/recognition_log.json"
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        
                        current_date = datetime.now().date()
                        for item in items:
                            expiry_date_str = item["expiry_date"]
                            expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
                            
                            remaining_days = (expiry_date - current_date).days + 1
                            if remaining_days <= warning_days:
                                warning_items.append({
                                    "item_name": item["item_name"],
                                    "weight": item.get("weight", 0.0),
                                    "remaining_days": remaining_days
                                })
        except Exception as e:
            from utils import logger
            logger.error(f"获取预警食材出错：{str(e)}")
        
        return warning_items
    
    def on_recipes_generated(self, recipes):
        """处理生成的菜谱"""
        self.recipes = recipes
        
        # 隐藏进度条
        self.progress_bar.setVisible(False)
        
        # 清空详情区域
        self.clear_details()
        
        # 更新菜谱列表
        for i, recipe in enumerate(recipes):
            self.recipe_list.addItem(f"{i+1}. {recipe['name']}")
        
        # 保存到历史记录
        self.save_to_history(recipes)
        
        # 重新启用生成按钮，并更改为"重新生成"
        self.generate_btn.setEnabled(True)
        self.generate_btn.setText("重新生成")
    
    def on_recipe_error(self, error_msg):
        """处理菜谱生成错误"""
        # 隐藏进度条
        self.progress_bar.setVisible(False)
        
        self.clear_details()
        error_label = QLabel(f"生成菜谱失败：{error_msg}")
        error_label.setStyleSheet("color: red; font-size: 16px;")
        error_label.setWordWrap(True)
        self.details_content.addWidget(error_label)
        
        # 重新启用生成按钮，并更改为"重新生成"
        self.generate_btn.setEnabled(True)
        self.generate_btn.setText("重新生成")
    
    def get_inventory_info(self):
        """读取并解析库存信息"""
        import json
        import os
        from datetime import datetime
        
        inventory = {}
        try:
            log_path = "data/recognition_log.json"
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        
                        # 获取当前日期
                        current_date = datetime.now().date()
                        
                        for item in items:
                            item_name = item.get("item_name", "").strip()
                            if not item_name:
                                continue
                            
                            # 解析重量
                            weight = float(item.get("weight", 0.0))
                            
                            # 解析到期日期和剩余天数
                            expiry_date_str = item.get("expiry_date")
                            remaining_days = "未知"
                            if expiry_date_str:
                                try:
                                    expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
                                    remaining_days = (expiry_date - current_date).days
                                except:
                                    remaining_days = "未知"
                            
                            # 解析位置
                            position = item.get("position", 1)
                            
                            # 解析ID码
                            id_code = item.get("id_code", "")
                            
                            # 保存库存信息
                            if item_name in inventory:
                                # 如果有相同名称的食材，累加重量
                                inventory[item_name]["weight"] += weight
                                # 添加ID码到列表，确保唯一
                                if id_code not in inventory[item_name]["id_codes"]:
                                    inventory[item_name]["id_codes"].append(id_code)
                            else:
                                inventory[item_name] = {
                                    "weight": weight,
                                    "position": position,
                                    "remaining_days": remaining_days,
                                    "id_codes": [id_code]
                                }
        except Exception as e:
            from utils import logger
            logger.error(f"获取库存信息出错：{str(e)}")
        
        return inventory
    
    def parse_ingredient_quantity(self, ingredient_str):
        """解析食材字符串，提取名称和需要的克数"""
        import re
        
        # 移除可能的前缀
        ingredient_str = ingredient_str.strip()
        if ingredient_str.startswith("-"):
            ingredient_str = ingredient_str[1:].strip()
        
        # 正则匹配：名称 + 数量 + 单位
        pattern = r'^(.*?)\s*(\d+)\s*g$'
        match = re.match(pattern, ingredient_str)
        if match:
            name = match.group(1).strip()
            quantity = int(match.group(2))
            return name, quantity
        else:
            # 如果无法解析，返回原始名称和0
            return ingredient_str, 0
    
    def show_recipe_details(self, item):
        """显示选中菜谱的详情"""
        recipe_index = self.recipe_list.row(item)
        if 0 <= recipe_index < len(self.recipes):
            recipe = self.recipes[recipe_index]
            
            # 清空详情区域
            self.clear_details()
            
            # 创建左右两栏布局
            main_details_layout = QHBoxLayout()
            
            # 左侧：菜谱详情
            left_layout = QVBoxLayout()
            
            # 显示菜谱详情
            name = recipe.get('name', '未命名菜谱')
            name_label = QLabel(name)
            name_label.setStyleSheet("font-size: 20px; font-weight: bold;")
            left_layout.addWidget(name_label)
            
            # 制作时间
            cooking_time = recipe.get('cooking_time', '未知')
            time_label = QLabel(f"制作时间：{cooking_time}")
            time_label.setStyleSheet("margin-top: 10px; font-size: 16px;")
            left_layout.addWidget(time_label)
            
            # 需要的食材
            ingredients = recipe.get('ingredients', [])
            ingredients_label = QLabel("需要的食材：")
            ingredients_label.setStyleSheet("margin-top: 15px; font-size: 16px; font-weight: bold;")
            left_layout.addWidget(ingredients_label)
            
            # 读取库存信息
            inventory = self.get_inventory_info()
            
            # 构建包含库存信息的食材列表
            ingredients_with_inventory = []
            for ing in ingredients:
                ing_name, required_g = self.parse_ingredient_quantity(ing)
                
                if ing_name in inventory:
                    stock_info = inventory[ing_name]
                    stock_g = stock_info["weight"]
                    position = stock_info["position"]
                    remaining_days = stock_info["remaining_days"]
                    id_codes = stock_info["id_codes"]
                    id_codes_str = ", ".join([code for code in id_codes if code]) if id_codes else "无"
                    
                    if stock_g >= required_g:
                        # 库存足够
                        status = f"（位置：{position}，剩余天数：{remaining_days}，ID码：{id_codes_str}，库存：{stock_g}g，需要：{required_g}g）"
                    else:
                        # 库存不足
                        needed = required_g - stock_g
                        status = f"（位置：{position}，剩余天数：{remaining_days}，ID码：{id_codes_str}，库存：{stock_g}g，需要：{required_g}g，还需要：{needed}g）"
                else:
                    # 缺少食材
                    status = "（库存中缺少该食材）"
                
                ingredients_with_inventory.append(f"{ing} {status}")
            
            ingredients_text = QTextEdit()
            ingredients_text.setReadOnly(True)
            ingredients_text.setStyleSheet("font-family: SimSun; font-size: 14px;")
            ingredients_text.setPlainText("\n".join(ingredients_with_inventory) if ingredients_with_inventory else "无")
            left_layout.addWidget(ingredients_text)
            
            # 需要的配料
            seasonings = recipe.get('seasonings', [])
            seasonings_label = QLabel("需要的配料：")
            seasonings_label.setStyleSheet("margin-top: 15px; font-size: 16px; font-weight: bold;")
            left_layout.addWidget(seasonings_label)
            
            seasonings_text = QTextEdit()
            seasonings_text.setReadOnly(True)
            seasonings_text.setStyleSheet("font-family: SimSun; font-size: 14px;")
            seasonings_text.setPlainText("\n".join(seasonings) if seasonings else "无")
            left_layout.addWidget(seasonings_text)
            
            # 制作方式
            instructions = recipe.get('instructions', '暂无制作方式')
            instructions_label = QLabel("制作方式：")
            instructions_label.setStyleSheet("margin-top: 15px; font-size: 16px; font-weight: bold;")
            left_layout.addWidget(instructions_label)
            
            instructions_text = QTextEdit()
            instructions_text.setReadOnly(True)
            instructions_text.setStyleSheet("font-family: SimSun; font-size: 14px;")
            instructions_text.setPlainText(instructions)
            left_layout.addWidget(instructions_text)
            
            # 收藏按钮
            favorite_btn = QPushButton("收藏")
            favorite_btn.setFixedSize(100, 35)
            favorite_btn.clicked.connect(lambda checked, r=recipe: self.favorite_recipe(r))
            left_layout.addWidget(favorite_btn, 0, Qt.AlignRight)
            
            # 右侧：健康建议
            right_layout = QVBoxLayout()
            health_advice_label = QLabel("健康建议：")
            health_advice_label.setStyleSheet("font-size: 18px; font-weight: bold; margin-bottom: 10px;")
            right_layout.addWidget(health_advice_label)
            
            # 健康建议内容
            health_advice = recipe.get('health_advice', '暂无健康建议')
            health_advice_text = QTextEdit()
            health_advice_text.setReadOnly(True)
            health_advice_text.setStyleSheet("font-family: SimSun; font-size: 14px; background-color: #f5f5f5;")
            health_advice_text.setPlainText(health_advice)
            right_layout.addWidget(health_advice_text, 1)
            
            # 设置最小宽度
            left_layout_widget = QWidget()
            left_layout_widget.setLayout(left_layout)
            left_layout_widget.setMinimumWidth(300)
            
            right_layout_widget = QWidget()
            right_layout_widget.setLayout(right_layout)
            right_layout_widget.setMinimumWidth(300)
            
            # 将左右两栏添加到主布局
            main_details_layout.addWidget(left_layout_widget, 2)
            main_details_layout.addWidget(right_layout_widget, 1)
            main_details_layout.setSpacing(20)
            
            # 将主布局添加到详情内容中
            self.details_content.addLayout(main_details_layout)
    
    def clear_details(self):
        """清空详情区域"""
        for i in reversed(range(self.details_content.count())):
            widget = self.details_content.itemAt(i).widget()
            if widget:
                widget.deleteLater()
    
    def favorite_recipe(self, recipe):
        """收藏菜谱"""
        import json
        import os
        
        try:
            # 读取现有收藏
            cookbook_path = "data/cookbook.json"
            favorites = []
            if os.path.exists(cookbook_path):
                with open(cookbook_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        favorites = json.loads(content)
            
            # 检查是否已收藏
            for fav in favorites:
                if fav['name'] == recipe['name']:
                    QMessageBox.information(self, "提示", "该菜谱已在收藏列表中")
                    return
            
            # 添加到收藏
            favorites.append(recipe)
            
            # 保存到文件
            with open(cookbook_path, "w", encoding="utf-8") as f:
                json.dump(favorites, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "成功", "菜谱已添加到收藏列表")
        except Exception as e:
            from utils import logger
            logger.error(f"收藏菜谱出错：{str(e)}")
            QMessageBox.critical(self, "错误", "收藏菜谱失败")
    
    def save_to_history(self, recipes):
        """保存菜谱到历史记录"""
        import json
        import os
        from datetime import datetime
        
        try:
            # 读取现有历史记录
            history_path = "data/history_cookbook.json"
            history = []
            if os.path.exists(history_path):
                with open(history_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        history = json.loads(content)
            
            # 创建历史记录条目
            history_entry = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "recipes": recipes
            }
            
            # 添加到历史记录开头
            history.insert(0, history_entry)
            
            # 限制历史记录数量
            if len(history) > 20:
                history = history[:20]
            
            # 保存到文件
            with open(history_path, "w", encoding="utf-8") as f:
                json.dump(history, f, indent=4, ensure_ascii=False)
        except Exception as e:
            from utils import logger
            logger.error(f"保存菜谱历史记录出错：{str(e)}")


class FavoritesDialog(QDialog):
    """收藏列表对话框"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("收藏列表")
        self.setModal(True)
        self.resize(800, 600)
        
        self.favorites = []
        self.inventory = {}
        
        # 初始化UI
        self.init_ui()
        self.load_inventory()
        self.load_favorites()
        self.update_recipe_counts()
    
    def load_inventory(self):
        """加载库存信息"""
        import json
        import os
        
        self.inventory = {}
        try:
            log_path = "data/recognition_log.json"
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        for item in items:
                            item_name = item.get("item_name", "").strip()
                            if not item_name:
                                continue
                            
                            weight = float(item.get("weight", 0.0))
                            if item_name in self.inventory:
                                self.inventory[item_name] += weight
                            else:
                                self.inventory[item_name] = weight
        except Exception as e:
            from utils import logger
            logger.error(f"加载库存信息出错：{str(e)}")
    
    def calculate_recipe_counts(self):
        """计算库存足够制作的菜谱数量"""
        counts = {}
        
        for recipe in self.favorites:
            can_make = True
            min_count = float("inf")
            
            # 解析食材列表，计算每个食材需要的克数
            for ing_str in recipe.get("ingredients", []):
                ing_name, required_g = self.parse_ingredient_quantity(ing_str)
                if required_g == 0:
                    continue
                    
                available = self.inventory.get(ing_name, 0)
                
                if available < required_g:
                    can_make = False
                    break
                
                # 计算可以制作的次数
                count = available // required_g
                if count < min_count:
                    min_count = count
            
            if can_make:
                counts[recipe["name"]] = min_count
            else:
                counts[recipe["name"]] = 0
        
        return counts
    
    def update_recipe_counts(self):
        """更新收藏列表显示，添加可制作次数"""
        counts = self.calculate_recipe_counts()
        
        # 更新收藏列表
        self.favorite_list.clear()
        for i, recipe in enumerate(self.favorites):
            count = counts.get(recipe["name"], 0)
            self.favorite_list.addItem(f"{i+1}. {recipe['name']} - 可制作 {count} 次")
    
    def init_ui(self):
        """初始化UI组件"""
        main_layout = QVBoxLayout(self)
        
        # 顶部标题
        title_label = QLabel("我的收藏菜谱")
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; text-align: center;")
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # 收藏列表和详情区域的分割布局
        content_layout = QHBoxLayout()
        
        # 左侧收藏列表
        list_layout = QVBoxLayout()
        
        self.favorite_list = QListWidget()
        self.favorite_list.itemClicked.connect(self.show_favorite_details)
        list_layout.addWidget(self.favorite_list)
        
        content_layout.addLayout(list_layout, 1)
        
        # 右侧收藏详情
        details_layout = QVBoxLayout()
        
        # 详情滚动区域
        self.details_scroll = QScrollArea()
        self.details_scroll.setWidgetResizable(True)
        
        self.details_widget = QWidget()
        self.details_content = QVBoxLayout(self.details_widget)
        
        # 初始详情内容
        self.initial_details = QLabel("点击左侧收藏查看详情")
        self.initial_details.setAlignment(Qt.AlignCenter)
        self.initial_details.setStyleSheet("font-size: 18px; color: #666;")
        self.details_content.addWidget(self.initial_details)
        
        self.details_scroll.setWidget(self.details_widget)
        details_layout.addWidget(self.details_scroll, 1)
        
        content_layout.addLayout(details_layout, 2)
        
        main_layout.addLayout(content_layout, 1)
    
    def load_favorites(self):
        """加载收藏列表"""
        import json
        import os
        
        try:
            cookbook_path = "data/cookbook.json"
            if os.path.exists(cookbook_path):
                with open(cookbook_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        self.favorites = json.loads(content)
        except Exception as e:
            from utils import logger
            logger.error(f"加载收藏列表出错：{str(e)}")
            self.favorites = []
    
    def get_inventory_info(self):
        """读取并解析库存信息"""
        import json
        import os
        from datetime import datetime
        
        inventory = {}
        try:
            log_path = "data/recognition_log.json"
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        
                        # 获取当前日期
                        current_date = datetime.now().date()
                        
                        for item in items:
                            item_name = item.get("item_name", "").strip()
                            if not item_name:
                                continue
                            
                            # 解析重量
                            weight = float(item.get("weight", 0.0))
                            
                            # 解析到期日期和剩余天数
                            expiry_date_str = item.get("expiry_date")
                            remaining_days = "未知"
                            if expiry_date_str:
                                try:
                                    expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
                                    remaining_days = (expiry_date - current_date).days
                                except:
                                    remaining_days = "未知"
                            
                            # 解析位置
                            position = item.get("position", 1)
                            
                            # 解析ID码
            id_code = item.get("id_code", "")
            
            # 保存库存信息
            if item_name in inventory:
                # 如果有相同名称的食材，累加重量
                inventory[item_name]["weight"] += weight
                # 添加ID码到列表，确保唯一
                if id_code not in inventory[item_name]["id_codes"]:
                    inventory[item_name]["id_codes"].append(id_code)
            else:
                inventory[item_name] = {
                    "weight": weight,
                    "position": position,
                    "remaining_days": remaining_days,
                    "id_codes": [id_code]
                }
        except Exception as e:
            from utils import logger
            logger.error(f"获取库存信息出错：{str(e)}")
        
        return inventory
    
    def parse_ingredient_quantity(self, ingredient_str):
        """解析食材字符串，提取名称和需要的克数"""
        import re
        
        # 移除可能的前缀
        ingredient_str = ingredient_str.strip()
        if ingredient_str.startswith("-"):
            ingredient_str = ingredient_str[1:].strip()
        
        # 正则匹配：名称 + 数量 + 单位
        pattern = r'^(.*?)\s*(\d+)\s*g$'
        match = re.match(pattern, ingredient_str)
        if match:
            name = match.group(1).strip()
            quantity = int(match.group(2))
            return name, quantity
        else:
            # 如果无法解析，返回原始名称和0
            return ingredient_str, 0
    
    def show_favorite_details(self, item):
        """显示选中收藏的详情"""
        favorite_index = self.favorite_list.row(item)
        if 0 <= favorite_index < len(self.favorites):
            recipe = self.favorites[favorite_index]
            
            # 清空详情区域
            self.clear_details()
            
            # 创建左右两栏布局
            main_details_layout = QHBoxLayout()
            
            # 左侧：菜谱详情
            left_layout = QVBoxLayout()
            
            # 显示菜谱详情
            name_label = QLabel(recipe['name'])
            name_label.setStyleSheet("font-size: 20px; font-weight: bold;")
            left_layout.addWidget(name_label)
            
            # 制作时间
            time_label = QLabel(f"制作时间：{recipe.get('cooking_time', '未知')}")
            time_label.setStyleSheet("margin-top: 10px; font-size: 16px;")
            left_layout.addWidget(time_label)
            
            # 需要的食材
            ingredients_label = QLabel("需要的食材：")
            ingredients_label.setStyleSheet("margin-top: 15px; font-size: 16px; font-weight: bold;")
            left_layout.addWidget(ingredients_label)
            
            # 读取库存信息
            inventory = self.get_inventory_info()
            
            # 构建包含库存信息的食材列表
            ingredients_with_inventory = []
            for ing in recipe.get('ingredients', []):
                ing_name, required_g = self.parse_ingredient_quantity(ing)
                
                if ing_name in inventory:
                    stock_info = inventory[ing_name]
                    stock_g = stock_info["weight"]
                    position = stock_info["position"]
                    remaining_days = stock_info["remaining_days"]
                    id_codes = stock_info["id_codes"]
                    id_codes_str = ", ".join([code for code in id_codes if code]) if id_codes else "无"
                    
                    if stock_g >= required_g:
                        # 库存足够
                        status = f"（位置：{position}，剩余天数：{remaining_days}，ID码：{id_codes_str}，库存：{stock_g}g，需要：{required_g}g）"
                    else:
                        # 库存不足
                        needed = required_g - stock_g
                        status = f"（位置：{position}，剩余天数：{remaining_days}，ID码：{id_codes_str}，库存：{stock_g}g，需要：{required_g}g，还需要：{needed}g）"
                else:
                    # 缺少食材
                    status = "（库存中缺少该食材）"
                
                ingredients_with_inventory.append(f"{ing} {status}")
            
            ingredients_text = QTextEdit()
            ingredients_text.setReadOnly(True)
            ingredients_text.setStyleSheet("font-family: SimSun; font-size: 14px;")
            ingredients_text.setPlainText("\n".join(ingredients_with_inventory) if ingredients_with_inventory else "无")
            left_layout.addWidget(ingredients_text)
            
            # 需要的配料
            seasonings_label = QLabel("需要的配料：")
            seasonings_label.setStyleSheet("margin-top: 15px; font-size: 16px; font-weight: bold;")
            left_layout.addWidget(seasonings_label)
            
            seasonings_text = QTextEdit()
            seasonings_text.setReadOnly(True)
            seasonings_text.setStyleSheet("font-family: SimSun; font-size: 14px;")
            seasonings_text.setPlainText("\n".join(recipe.get('seasonings', [])) if recipe.get('seasonings', []) else "无")
            left_layout.addWidget(seasonings_text)
            
            # 制作方式
            instructions_label = QLabel("制作方式：")
            instructions_label.setStyleSheet("margin-top: 15px; font-size: 16px; font-weight: bold;")
            left_layout.addWidget(instructions_label)
            
            instructions_text = QTextEdit()
            instructions_text.setReadOnly(True)
            instructions_text.setStyleSheet("font-family: SimSun; font-size: 14px;")
            instructions_text.setPlainText(recipe.get('instructions', '暂无制作方式'))
            left_layout.addWidget(instructions_text)
            
            # 右侧：健康建议
            right_layout = QVBoxLayout()
            health_advice_label = QLabel("健康建议：")
            health_advice_label.setStyleSheet("font-size: 18px; font-weight: bold; margin-bottom: 10px;")
            right_layout.addWidget(health_advice_label)
            
            # 健康建议内容
            health_advice = recipe.get('health_advice', '暂无健康建议')
            health_advice_text = QTextEdit()
            health_advice_text.setReadOnly(True)
            health_advice_text.setStyleSheet("font-family: SimSun; font-size: 14px; background-color: #f5f5f5;")
            health_advice_text.setPlainText(health_advice)
            right_layout.addWidget(health_advice_text, 1)
            
            # 设置最小宽度
            left_layout_widget = QWidget()
            left_layout_widget.setLayout(left_layout)
            left_layout_widget.setMinimumWidth(300)
            
            right_layout_widget = QWidget()
            right_layout_widget.setLayout(right_layout)
            right_layout_widget.setMinimumWidth(300)
            
            # 将左右两栏添加到主布局
            main_details_layout.addWidget(left_layout_widget, 2)
            main_details_layout.addWidget(right_layout_widget, 1)
            main_details_layout.setSpacing(20)
            
            # 将主布局添加到详情内容中
            self.details_content.addLayout(main_details_layout)
    
    def clear_details(self):
        """清空详情区域"""
        for i in reversed(range(self.details_content.count())):
            widget = self.details_content.itemAt(i).widget()
            if widget:
                widget.deleteLater()


class CustomRecipeEditDialog(QDialog):
    """自定义菜谱编辑对话框"""
    
    def __init__(self, recipe=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("编辑自定义菜谱")
        self.setModal(True)
        self.resize(500, 400)  # 增大窗口，容纳下拉选择框
        
        self.recipe = recipe.copy() if recipe else {}
        self.inventory_items = []  # 库存食材列表
        self.init_ui()
    
    def load_inventory_items(self):
        """加载库存食材列表"""
        import json
        import os
        
        self.inventory_items = []
        try:
            log_path = "data/recognition_log.json"
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        # 提取所有不重复的食材名称
                        item_names = set()
                        for item in items:
                            item_name = item.get("item_name", "").strip()
                            if item_name:
                                item_names.add(item_name)
                        # 转换为列表并排序
                        self.inventory_items = sorted(list(item_names))
        except Exception as e:
            from utils import logger
            logger.error(f"加载库存食材出错：{str(e)}")
            self.inventory_items = []
    
    def init_ui(self):
        """初始化UI组件"""
        layout = QVBoxLayout(self)
        
        # 菜名输入
        name_layout = QHBoxLayout()
        name_label = QLabel("菜名：")
        self.name_input = QLineEdit(self.recipe.get("name", ""))
        name_layout.addWidget(name_label)
        name_layout.addWidget(self.name_input)
        layout.addLayout(name_layout)
        
        # 食材列表
        ingredients_label = QLabel("食材列表：")
        layout.addWidget(ingredients_label)
        
        # 食材输入区域
        self.ingredients_layout = QVBoxLayout()
        self.ingredients = self.recipe.get("ingredients", [])
        
        # 初始食材输入框
        if not self.ingredients:
            self.ingredients = [{"name": "", "weight": ""}]
        
        for i, ing in enumerate(self.ingredients):
            self.add_ingredient_row(ing["name"], ing["weight"])
        
        layout.addLayout(self.ingredients_layout)
        
        # 添加食材按钮
        add_ing_btn = QPushButton("添加食材")
        add_ing_btn.clicked.connect(self.add_ingredient_row)
        layout.addWidget(add_ing_btn, 0, Qt.AlignRight)
        
        # 按钮布局
        btn_layout = QHBoxLayout()
        
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)
        
        save_btn = QPushButton("保存")
        save_btn.clicked.connect(self.save_recipe)
        btn_layout.addWidget(save_btn)
        
        layout.addLayout(btn_layout)
    
    def add_ingredient_row(self, name="", weight=""):
        """添加一行食材输入"""
        row_layout = QHBoxLayout()
        
        # 确保name和weight是字符串类型
        name_str = str(name) if name is not None else ""
        weight_str = str(weight) if weight is not None else ""
        
        # 食材名称选择：下拉选择 + 输入框
        self.load_inventory_items()
        
        # 创建下拉选择框
        ingredient_combo = QComboBox()
        ingredient_combo.setEditable(True)
        # 添加库存食材和空选项
        ingredient_combo.addItem("")
        for item in self.inventory_items:
            ingredient_combo.addItem(item)
        # 设置当前文本
        ingredient_combo.setCurrentText(name_str)
        row_layout.addWidget(ingredient_combo, 2)
        
        weight_input = QLineEdit(weight_str)
        weight_input.setPlaceholderText("用量（g）")
        row_layout.addWidget(weight_input, 1)
        
        remove_btn = QPushButton("删除")
        remove_btn.setFixedSize(60, 25)
        remove_btn.clicked.connect(lambda: self.remove_ingredient_row(row_layout))
        row_layout.addWidget(remove_btn)
        
        self.ingredients_layout.addLayout(row_layout)
    
    def remove_ingredient_row(self, row_layout):
        """移除一行食材输入"""
        for i in reversed(range(row_layout.count())):
            widget = row_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()
        row_layout.deleteLater()
    
    def save_recipe(self):
        """保存菜谱"""
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "警告", "菜名不能为空")
            return
        
        ingredients = []
        for i in range(self.ingredients_layout.count()):
            row_layout = self.ingredients_layout.itemAt(i).layout()
            if row_layout:
                name_input = row_layout.itemAt(0).widget()
                weight_input = row_layout.itemAt(1).widget()
                # 使用currentText()方法获取QComboBox的文本
                ing_name = name_input.currentText().strip()
                ing_weight = weight_input.text().strip()
                
                if ing_name and ing_weight:
                    ingredients.append({"name": ing_name, "weight": float(ing_weight)})
        
        if not ingredients:
            QMessageBox.warning(self, "警告", "至少需要添加一种食材")
            return
        
        self.recipe = {
            "name": name,
            "ingredients": ingredients
        }
        
        self.accept()
    
    def get_recipe(self):
        """获取保存的菜谱"""
        return self.recipe


class CustomRecipesDialog(QDialog):
    """自定义菜谱对话框"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("自定义菜谱")
        self.setModal(True)
        self.resize(800, 600)
        
        self.recipes = []
        self.inventory = {}
        
        # 初始化UI
        self.init_ui()
        self.load_recipes()
        self.load_inventory()
        self.update_recipe_counts()
    
    def init_ui(self):
        """初始化UI组件"""
        layout = QVBoxLayout(self)
        
        # 顶部标题
        title_label = QLabel("我的自定义菜谱")
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; text-align: center;")
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)
        
        # 按钮布局
        btn_layout = QHBoxLayout()
        
        # 创建菜谱按钮
        create_btn = QPushButton("创建菜谱")
        create_btn.setFixedSize(120, 35)
        create_btn.clicked.connect(self.create_recipe)
        btn_layout.addWidget(create_btn)
        
        # 删除菜谱按钮
        self.delete_btn = QPushButton("删除选中")
        self.delete_btn.setFixedSize(120, 35)
        self.delete_btn.clicked.connect(self.delete_recipe)
        self.delete_btn.setEnabled(False)
        btn_layout.addWidget(self.delete_btn)
        
        # 刷新库存按钮
        refresh_btn = QPushButton("刷新库存")
        refresh_btn.setFixedSize(120, 35)
        refresh_btn.clicked.connect(self.refresh_inventory)
        btn_layout.addWidget(refresh_btn)
        
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
        
        # 菜谱列表
        self.recipe_list = QListWidget()
        self.recipe_list.itemSelectionChanged.connect(self.on_selection_changed)
        layout.addWidget(self.recipe_list, 1)
        
        # 库存计算结果
        self.counts_label = QLabel("库存足够制作的菜谱数量：")
        self.counts_label.setStyleSheet("font-size: 16px; font-weight: bold;")
        layout.addWidget(self.counts_label)
    
    def load_recipes(self):
        """加载自定义菜谱"""
        import json
        import os
        
        try:
            cookbook_path = "data/self_cookbook.json"
            if os.path.exists(cookbook_path):
                with open(cookbook_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        self.recipes = json.loads(content)
                    else:
                        self.recipes = []
            else:
                self.recipes = []
            
            # 更新列表显示
            self.recipe_list.clear()
            for recipe in self.recipes:
                self.recipe_list.addItem(recipe["name"])
        except Exception as e:
            from utils import logger
            logger.error(f"加载自定义菜谱出错：{str(e)}")
            self.recipes = []
    
    def save_recipes(self):
        """保存自定义菜谱"""
        import json
        import os
        
        try:
            cookbook_path = "data/self_cookbook.json"
            # 确保data目录存在
            os.makedirs("data", exist_ok=True)
            with open(cookbook_path, "w", encoding="utf-8") as f:
                json.dump(self.recipes, f, indent=4, ensure_ascii=False)
        except Exception as e:
            from utils import logger
            logger.error(f"保存自定义菜谱出错：{str(e)}")
    
    def load_inventory(self):
        """加载库存信息"""
        import json
        import os
        
        self.inventory = {}
        try:
            log_path = "data/recognition_log.json"
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        for item in items:
                            item_name = item.get("item_name", "").strip()
                            if not item_name:
                                continue
                            
                            weight = float(item.get("weight", 0.0))
                            if item_name in self.inventory:
                                self.inventory[item_name] += weight
                            else:
                                self.inventory[item_name] = weight
        except Exception as e:
            from utils import logger
            logger.error(f"加载库存信息出错：{str(e)}")
    
    def calculate_recipe_counts(self):
        """计算库存足够制作的菜谱数量"""
        counts = {}
        
        for recipe in self.recipes:
            can_make = True
            min_count = float("inf")
            
            for ing in recipe["ingredients"]:
                ing_name = ing["name"]
                required = ing["weight"]
                available = self.inventory.get(ing_name, 0)
                
                if available < required:
                    can_make = False
                    break
                
                # 计算可以制作的次数
                count = available // required
                if count < min_count:
                    min_count = count
            
            if can_make:
                counts[recipe["name"]] = min_count
            else:
                counts[recipe["name"]] = 0
        
        return counts
    
    def update_recipe_counts(self):
        """更新菜谱数量显示"""
        counts = self.calculate_recipe_counts()
        
        # 更新列表显示
        self.recipe_list.clear()
        for recipe in self.recipes:
            count = counts[recipe["name"]]
            self.recipe_list.addItem(f"{recipe['name']} - 可制作 {count} 次")
        
        # 更新总数量显示
        total = sum(counts.values())
        self.counts_label.setText(f"库存足够制作的菜谱数量：{total} 次")
    
    def create_recipe(self):
        """创建新菜谱"""
        dialog = CustomRecipeEditDialog(parent=self)
        if dialog.exec_():
            recipe = dialog.get_recipe()
            self.recipes.append(recipe)
            self.save_recipes()
            self.refresh_inventory()
    
    def edit_recipe(self):
        """编辑选中的菜谱"""
        selected_items = self.recipe_list.selectedItems()
        if not selected_items:
            return
        
        selected_index = self.recipe_list.row(selected_items[0])
        recipe = self.recipes[selected_index]
        
        dialog = CustomRecipeEditDialog(recipe, parent=self)
        if dialog.exec_():
            updated_recipe = dialog.get_recipe()
            self.recipes[selected_index] = updated_recipe
            self.save_recipes()
            self.refresh_inventory()
    
    def delete_recipe(self):
        """删除选中的菜谱"""
        selected_items = self.recipe_list.selectedItems()
        if not selected_items:
            return
        
        selected_index = self.recipe_list.row(selected_items[0])
        
        reply = QMessageBox.question(self, "确认删除", "确定要删除这个菜谱吗？", 
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            del self.recipes[selected_index]
            self.save_recipes()
            self.refresh_inventory()
    
    def on_selection_changed(self):
        """选择变化时更新按钮状态"""
        self.delete_btn.setEnabled(len(self.recipe_list.selectedItems()) > 0)
    
    def refresh_inventory(self):
        """刷新库存并重新计算"""
        self.load_inventory()
        self.update_recipe_counts()


class RecipeHistoryDialog(QDialog):
    """菜谱历史记录对话框"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("菜谱历史")
        self.setModal(True)
        self.resize(800, 600)
        
        self.history = []
        
        # 初始化UI
        self.init_ui()
        self.load_history()
    
    def init_ui(self):
        """初始化UI组件"""
        main_layout = QVBoxLayout(self)
        
        # 顶部标题
        title_label = QLabel("菜谱历史记录")
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; text-align: center;")
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # 历史列表
        self.history_list = QListWidget()
        self.history_list.itemClicked.connect(self.show_history_details)
        main_layout.addWidget(self.history_list, 1)
    
    def load_history(self):
        """加载历史记录"""
        import json
        import os
        
        try:
            history_path = "data/history_cookbook.json"
            if os.path.exists(history_path):
                with open(history_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        self.history = json.loads(content)
                        
                        # 更新历史列表
                        for i, entry in enumerate(self.history):
                            timestamp = entry['timestamp']
                            recipes_count = len(entry['recipes'])
                            self.history_list.addItem(f"{i+1}. {timestamp} ({recipes_count}个菜谱)")
        except Exception as e:
            from utils import logger
            logger.error(f"加载菜谱历史记录出错：{str(e)}")
    
    def get_inventory_info(self):
        """读取并解析库存信息"""
        import json
        import os
        from datetime import datetime
        
        inventory = {}
        try:
            log_path = "data/recognition_log.json"
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        items = json.loads(content)
                        
                        # 获取当前日期
                        current_date = datetime.now().date()
                        
                        for item in items:
                            item_name = item.get("item_name", "").strip()
                            if not item_name:
                                continue
                            
                            # 解析重量
                            weight = float(item.get("weight", 0.0))
                            
                            # 解析到期日期和剩余天数
                            expiry_date_str = item.get("expiry_date")
                            remaining_days = "未知"
                            if expiry_date_str:
                                try:
                                    expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
                                    remaining_days = (expiry_date - current_date).days
                                except:
                                    remaining_days = "未知"
                            
                            # 解析位置
                            position = item.get("position", 1)
                            
                            # 解析ID码
            id_code = item.get("id_code", "")
            
            # 保存库存信息
            if item_name in inventory:
                # 如果有相同名称的食材，累加重量
                inventory[item_name]["weight"] += weight
                # 添加ID码到列表，确保唯一
                if id_code not in inventory[item_name]["id_codes"]:
                    inventory[item_name]["id_codes"].append(id_code)
            else:
                inventory[item_name] = {
                    "weight": weight,
                    "position": position,
                    "remaining_days": remaining_days,
                    "id_codes": [id_code]
                }
        except Exception as e:
            from utils import logger
            logger.error(f"获取库存信息出错：{str(e)}")
        
        return inventory
    
    def parse_ingredient_quantity(self, ingredient_str):
        """解析食材字符串，提取名称和需要的克数"""
        import re
        
        # 移除可能的前缀
        ingredient_str = ingredient_str.strip()
        if ingredient_str.startswith("-"):
            ingredient_str = ingredient_str[1:].strip()
        
        # 正则匹配：名称 + 数量 + 单位
        pattern = r'^(.*?)\s*(\d+)\s*g$'
        match = re.match(pattern, ingredient_str)
        if match:
            name = match.group(1).strip()
            quantity = int(match.group(2))
            return name, quantity
        else:
            # 如果无法解析，返回原始名称和0
            return ingredient_str, 0
    
    def show_history_details(self, item):
        """显示历史记录详情"""
        history_index = self.history_list.row(item)
        if 0 <= history_index < len(self.history):
            entry = self.history[history_index]
            
            # 读取库存信息
            inventory = self.get_inventory_info()
            
            # 创建详情对话框
            detail_dialog = QDialog(self)
            detail_dialog.setWindowTitle(f"历史记录 - {entry['timestamp']}")
            detail_dialog.resize(800, 600)  # 增大窗口，显示更多信息
            
            detail_layout = QVBoxLayout(detail_dialog)
            
            # 详情滚动区域
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            
            scroll_widget = QWidget()
            scroll_layout = QVBoxLayout(scroll_widget)
            
            # 显示每个菜谱
            for i, recipe in enumerate(entry['recipes']):
                # 获取菜谱名称，确保存在
                recipe_name = recipe.get('name', '未命名菜谱')
                recipe_group = QGroupBox(f"菜谱 {i+1}: {recipe_name}")
                recipe_group.setStyleSheet("font-weight: bold;")
                group_layout = QVBoxLayout(recipe_group)
                
                # 制作时间，添加默认值
                cooking_time = recipe.get('cooking_time', '未知')
                time_label = QLabel(f"制作时间：{cooking_time}")
                group_layout.addWidget(time_label)
                
                # 需要的食材，添加默认值
                ingredients = recipe.get('ingredients', [])
                ingredients_label = QLabel("需要的食材：")
                ingredients_label.setStyleSheet("font-weight: bold;")
                group_layout.addWidget(ingredients_label)
                
                # 构建包含库存信息的食材列表
                ingredients_with_inventory = []
                for ing in ingredients:
                    ing_name, required_g = self.parse_ingredient_quantity(ing)
                    
                    if ing_name in inventory:
                        stock_info = inventory[ing_name]
                        stock_g = stock_info["weight"]
                        position = stock_info["position"]
                        remaining_days = stock_info["remaining_days"]
                        
                        if stock_g >= required_g:
                            # 库存足够
                            status = f"（位置：{position}，剩余天数：{remaining_days}，库存：{stock_g}g，需要：{required_g}g）"
                        else:
                            # 库存不足
                            needed = required_g - stock_g
                            status = f"（位置：{position}，剩余天数：{remaining_days}，库存：{stock_g}g，需要：{required_g}g，还需要：{needed}g）"
                    else:
                        # 缺少食材
                        status = "（库存中缺少该食材）"
                    
                    ingredients_with_inventory.append(f"{ing} {status}")
                
                ingredients_text = QTextEdit()
                ingredients_text.setReadOnly(True)
                ingredients_text.setMaximumHeight(120)  # 增大高度，显示更多信息
                ingredients_text.setStyleSheet("font-family: SimSun; font-size: 12px;")
                ingredients_text.setPlainText("\n".join(ingredients_with_inventory) if ingredients_with_inventory else "无")
                group_layout.addWidget(ingredients_text)
                
                # 需要的配料，添加默认值
                seasonings = recipe.get('seasonings', [])
                seasonings_label = QLabel("需要的配料：")
                seasonings_label.setStyleSheet("font-weight: bold;")
                group_layout.addWidget(seasonings_label)
                
                seasonings_text = QTextEdit()
                seasonings_text.setReadOnly(True)
                seasonings_text.setMaximumHeight(100)
                seasonings_text.setStyleSheet("font-family: SimSun; font-size: 12px;")
                seasonings_text.setPlainText("\n".join(seasonings) if seasonings else "无")
                group_layout.addWidget(seasonings_text)
                
                # 制作方式，添加默认值
                instructions = recipe.get('instructions', '暂无制作方式')
                instructions_label = QLabel("制作方式：")
                instructions_label.setStyleSheet("font-weight: bold;")
                group_layout.addWidget(instructions_label)
                
                instructions_text = QTextEdit()
                instructions_text.setReadOnly(True)
                instructions_text.setMaximumHeight(150)
                instructions_text.setStyleSheet("font-family: SimSun; font-size: 12px;")
                instructions_text.setPlainText(instructions)
                group_layout.addWidget(instructions_text)
                
                # 健康建议，添加默认值
                health_advice = recipe.get('health_advice', '暂无健康建议')
                health_advice_label = QLabel("健康建议：")
                health_advice_label.setStyleSheet("font-weight: bold;")
                group_layout.addWidget(health_advice_label)
                
                health_advice_text = QTextEdit()
                health_advice_text.setReadOnly(True)
                health_advice_text.setMaximumHeight(100)
                health_advice_text.setStyleSheet("font-family: SimSun; font-size: 12px; background-color: #f5f5f5;")
                health_advice_text.setPlainText(health_advice)
                group_layout.addWidget(health_advice_text)
                
                scroll_layout.addWidget(recipe_group)
            
            scroll.setWidget(scroll_widget)
            detail_layout.addWidget(scroll)
            
            detail_dialog.exec_()


class SettingsDialog(QDialog):
    """设置对话框"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.setModal(True)
        self.resize(500, 450)  # 增加窗口大小，容纳更多设置选项
        
        # 初始化UI
        self.init_ui()
        
    def init_ui(self):
        """初始化UI组件"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 读取当前设置
        self.load_settings()
        
        # 摄像头选择设置
        camera_layout = QHBoxLayout()
        
        camera_label = QLabel("选择摄像头：")
        camera_layout.addWidget(camera_label)
        
        self.camera_combobox = QComboBox()
        
        # 先添加一个默认项，提示正在检测USB设备
        self.camera_combobox.addItem("检测USB设备中...", -1)
        
        # 设置当前选中的摄像头索引
        self.camera_combobox.setCurrentIndex(0)
        
        camera_layout.addWidget(self.camera_combobox)
        layout.addLayout(camera_layout)
        
        # 摄像头帧大小设置
        camera_frame_layout = QHBoxLayout()
        
        camera_frame_label = QLabel("摄像头帧大小：")
        camera_frame_layout.addWidget(camera_frame_label)
        
        self.camera_frame_width_spinbox = QSpinBox()
        self.camera_frame_width_spinbox.setRange(320, 1920)
        self.camera_frame_width_spinbox.setValue(self.camera_frame_width)
        camera_frame_layout.addWidget(self.camera_frame_width_spinbox)
        
        camera_frame_layout.addWidget(QLabel("x"))
        
        self.camera_frame_height_spinbox = QSpinBox()
        self.camera_frame_height_spinbox.setRange(240, 1080)
        self.camera_frame_height_spinbox.setValue(self.camera_frame_height)
        camera_frame_layout.addWidget(self.camera_frame_height_spinbox)
        
        layout.addLayout(camera_frame_layout)
        
        # 扫码枪选择设置
        scanner_layout = QHBoxLayout()
        
        scanner_label = QLabel("选择扫码枪：")
        scanner_layout.addWidget(scanner_label)
        
        self.scanner_combobox = QComboBox()
        
        # 先添加一个默认项，提示正在检测USB设备
        self.scanner_combobox.addItem("检测USB设备中...", "")
        
        # 设置当前选中的扫码枪索引
        self.scanner_combobox.setCurrentIndex(0)
        
        scanner_layout.addWidget(self.scanner_combobox)
        layout.addLayout(scanner_layout)
        
        # MCU串口选择设置
        mcu_serial_layout = QHBoxLayout()
        
        mcu_serial_label = QLabel("选择MCU串口：")
        mcu_serial_layout.addWidget(mcu_serial_label)
        
        self.mcu_serial_combobox = QComboBox()
        
        # 先添加一个默认项，提示正在检测USB设备
        self.mcu_serial_combobox.addItem("检测串口设备中...", "")
        
        # 设置当前选中的MCU串口
        self.mcu_serial_combobox.setCurrentIndex(0)
        
        mcu_serial_layout.addWidget(self.mcu_serial_combobox)
        layout.addLayout(mcu_serial_layout)
        
        # 窗口设置
        window_layout = QHBoxLayout()
        
        window_label = QLabel("窗口大小：")
        window_layout.addWidget(window_label)
        
        self.window_width_spinbox = QSpinBox()
        self.window_width_spinbox.setRange(1000, 2000)
        self.window_width_spinbox.setValue(self.window_width)
        window_layout.addWidget(self.window_width_spinbox)
        
        window_layout.addWidget(QLabel("x"))
        
        self.window_height_spinbox = QSpinBox()
        self.window_height_spinbox.setRange(500, 1200)
        self.window_height_spinbox.setValue(self.window_height)
        window_layout.addWidget(self.window_height_spinbox)
        
        layout.addLayout(window_layout)
        
        # 回收站保留天数设置
        retention_layout = QHBoxLayout()
        
        retention_label = QLabel("回收站保留天数：")
        retention_layout.addWidget(retention_label)
        
        self.retention_spinbox = QSpinBox()
        self.retention_spinbox.setRange(1, 30)  # 保留天数范围1-30天
        self.retention_spinbox.setValue(self.retention_days)
        retention_layout.addWidget(self.retention_spinbox)
        
        retention_days_label = QLabel("天")
        retention_layout.addWidget(retention_days_label)
        
        layout.addLayout(retention_layout)
        
        # 保质期预警天数设置
        warning_days_layout = QHBoxLayout()
        
        warning_days_label = QLabel("保质期预警天数：")
        warning_days_layout.addWidget(warning_days_label)
        
        self.warning_days_spinbox = QSpinBox()
        self.warning_days_spinbox.setRange(1, 30)  # 预警天数范围1-30天
        self.warning_days_spinbox.setValue(self.warning_days)
        warning_days_layout.addWidget(self.warning_days_spinbox)
        
        warning_days_unit_label = QLabel("天")
        warning_days_layout.addWidget(warning_days_unit_label)
        
        layout.addLayout(warning_days_layout)
        
        # API密钥设置区域
        api_layout = QVBoxLayout()
        api_label = QLabel("API密钥设置")
        api_label.setStyleSheet("font-weight: bold;")
        api_layout.addWidget(api_label)
        
        # Baidu AI API Key
        baidu_api_key_layout = QHBoxLayout()
        baidu_api_key_label = QLabel("百度AI API Key：")
        baidu_api_key_layout.addWidget(baidu_api_key_label)
        self.baidu_api_key_input = QLineEdit()
        self.baidu_api_key_input.setText(self.baidu_api_key)
        baidu_api_key_layout.addWidget(self.baidu_api_key_input)
        api_layout.addLayout(baidu_api_key_layout)
        
        # Baidu AI Secret Key
        baidu_secret_key_layout = QHBoxLayout()
        baidu_secret_key_label = QLabel("百度AI Secret Key：")
        baidu_secret_key_layout.addWidget(baidu_secret_key_label)
        self.baidu_secret_key_input = QLineEdit()
        self.baidu_secret_key_input.setText(self.baidu_secret_key)
        baidu_secret_key_layout.addWidget(self.baidu_secret_key_input)
        api_layout.addLayout(baidu_secret_key_layout)
        
        # DeepSeek API Key
        deepseek_api_key_layout = QHBoxLayout()
        deepseek_api_key_label = QLabel("DeepSeek API Key：")
        deepseek_api_key_layout.addWidget(deepseek_api_key_label)
        self.deepseek_api_key_input = QLineEdit()
        self.deepseek_api_key_input.setText(self.deepseek_api_key)
        deepseek_api_key_layout.addWidget(self.deepseek_api_key_input)
        api_layout.addLayout(deepseek_api_key_layout)
        
        # Bing Search API Key
        bing_search_api_key_layout = QHBoxLayout()
        bing_search_api_key_label = QLabel("Bing Search API Key：")
        bing_search_api_key_layout.addWidget(bing_search_api_key_label)
        self.bing_search_api_key_input = QLineEdit()
        self.bing_search_api_key_input.setText(self.bing_search_api_key)
        bing_search_api_key_layout.addWidget(self.bing_search_api_key_input)
        api_layout.addLayout(bing_search_api_key_layout)
        
        layout.addLayout(api_layout)
        
        # 按钮布局
        button_layout = QHBoxLayout()
        
        # 恢复默认设置按钮
        self.reset_btn = QPushButton("一键恢复默认设置")
        self.reset_btn.clicked.connect(self.reset_to_defaults)
        button_layout.addWidget(self.reset_btn)
        
        button_layout.addStretch()
        
        # 取消按钮
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)
        
        # 确认按钮
        self.confirm_btn = QPushButton("确认")
        self.confirm_btn.clicked.connect(self.save_settings)
        button_layout.addWidget(self.confirm_btn)
        
        layout.addLayout(button_layout)
        
        # 启动检测线程
        self.start_detection_threads()
    
    def start_detection_threads(self):
        """启动所有检测线程"""
        # 启动摄像头检测线程
        self.start_camera_detection()
        # 启动扫码枪检测线程
        self.start_scanner_detection()
        # 启动MCU串口检测线程
        self.start_mcu_serial_detection()
    
    def start_camera_detection(self):
        """启动摄像头检测线程"""
        # 创建并启动摄像头检测线程
        self.camera_thread = CameraDetectionThread()
        self.camera_thread.detection_finished.connect(self.on_camera_detection_finished)
        self.camera_thread.start()
    
    def start_scanner_detection(self):
        """启动扫码枪检测线程"""
        # 创建并启动扫码枪检测线程
        self.scanner_thread = ScannerDetectionThread()
        self.scanner_thread.detection_finished.connect(self.on_scanner_detection_finished)
        self.scanner_thread.start()
    
    def start_mcu_serial_detection(self):
        """启动MCU串口检测线程"""
        # 创建并启动MCU串口检测线程
        self.mcu_serial_thread = MCUSerialDetectionThread()
        self.mcu_serial_thread.detection_finished.connect(self.on_mcu_serial_detection_finished)
        self.mcu_serial_thread.start()
    
    def on_camera_detection_finished(self, cameras):
        """处理摄像头检测完成信号"""
        # 保存检测到的摄像头列表
        self.available_cameras = cameras
        
        # 清空下拉列表
        self.camera_combobox.clear()
        
        # 添加检测到的摄像头
        for camera_id, camera_name in cameras:
            self.camera_combobox.addItem(camera_name, camera_id)
        
        # 如果没有检测到摄像头，添加一个提示项
        if not cameras:
            self.camera_combobox.addItem("未检测到USB设备", -1)
        
        # 设置当前选中的摄像头
        current_camera_found = False
        for i, (camera_id, camera_name) in enumerate(cameras):
            if camera_id == self.camera_index:
                self.camera_combobox.setCurrentIndex(i)
                current_camera_found = True
                break
        
        # 如果当前设置的摄像头不可用，添加到列表并选中
        if not current_camera_found and self.camera_index != -1:
            self.camera_combobox.addItem(f"摄像头 {self.camera_index} (不可用)", self.camera_index)
            self.camera_combobox.setCurrentIndex(len(cameras))
    
    def on_scanner_detection_finished(self, scanners):
        """处理扫码枪检测完成信号"""
        # 保存检测到的扫码枪列表
        self.available_scanners = scanners
        
        # 清空下拉列表
        self.scanner_combobox.clear()
        
        # 添加检测到的扫码枪
        for scanner_id, scanner_name in scanners:
            self.scanner_combobox.addItem(scanner_name, scanner_id)
        
        # 如果没有检测到扫码枪，添加一个提示项
        if not scanners:
            self.scanner_combobox.addItem("未检测到USB设备", "")
        
        # 设置当前选中的扫码枪
        current_scanner_found = False
        for i, (scanner_id, scanner_name) in enumerate(scanners):
            if str(scanner_id) == str(self.scanner_index):
                self.scanner_combobox.setCurrentIndex(i)
                current_scanner_found = True
                break
        
        # 如果当前设置的扫码枪不可用，添加到列表并选中
        if not current_scanner_found and self.scanner_index:
            self.scanner_combobox.addItem(f"扫码枪 {self.scanner_index} (不可用)", self.scanner_index)
            self.scanner_combobox.setCurrentIndex(len(scanners))
    
    def on_mcu_serial_detection_finished(self, serial_ports):
        """处理MCU串口检测完成信号"""
        # 保存检测到的MCU串口列表
        self.available_mcu_ports = serial_ports
        
        # 清空下拉列表
        self.mcu_serial_combobox.clear()
        
        # 添加检测到的MCU串口
        for port_path, port_name in serial_ports:
            self.mcu_serial_combobox.addItem(port_name, port_path)
        
        # 如果没有检测到MCU串口，添加一个提示项
        if not serial_ports:
            self.mcu_serial_combobox.addItem("未检测到串口设备", "")
        
        # 设置当前选中的MCU串口
        current_port_found = False
        for i, (port_path, port_name) in enumerate(serial_ports):
            if port_path == self.mcu_serial_port:
                self.mcu_serial_combobox.setCurrentIndex(i)
                current_port_found = True
                break
        
        # 如果当前设置的MCU串口不可用，添加到列表并选中
        if not current_port_found and self.mcu_serial_port:
            self.mcu_serial_combobox.addItem(f"{self.mcu_serial_port} (不可用)", self.mcu_serial_port)
            self.mcu_serial_combobox.setCurrentIndex(len(serial_ports))
    
    def load_settings(self):
        """加载当前设置"""
        # 默认设置
        self.retention_days = 3
        self.warning_days = 3  # 保质期预警天数，默认为3天
        self.camera_index = 0
        self.scanner_index = ""
        self.mcu_serial_port = ""
        # API密钥设置
        self.baidu_api_key = ""
        self.baidu_secret_key = ""
        self.deepseek_api_key = ""
        self.bing_search_api_key = ""
        # 窗口设置
        self.window_width = 1400
        self.window_height = 600
        # 摄像头帧大小设置
        self.camera_frame_width = 640
        self.camera_frame_height = 480
        try:
            import json
            with open("data/config.json", "r", encoding="utf-8") as f:
                config = json.load(f)
                self.retention_days = config.get("recycle_bin", {}).get("retention_days", 3)
                self.warning_days = config.get("app", {}).get("warning_days", 3)  # 读取保质期预警天数
                self.camera_index = config.get("camera", {}).get("device_index", 0)
                self.scanner_index = config.get("scanner", {}).get("device_id", "")
                self.mcu_serial_port = config.get("mcu_serial", {}).get("port", "")
                # API密钥
                self.baidu_api_key = config.get("baidu_ai", {}).get("api_key", "")
                self.baidu_secret_key = config.get("baidu_ai", {}).get("secret_key", "")
                self.deepseek_api_key = config.get("deepseek", {}).get("api_key", "")
                self.bing_search_api_key = config.get("bing_search", {}).get("api_key", "")
                # 窗口设置
                self.window_width = config.get("app", {}).get("window_width", 1400)
                self.window_height = config.get("app", {}).get("window_height", 600)
                # 摄像头帧大小
                self.camera_frame_width = config.get("camera", {}).get("frame_width", 640)
                self.camera_frame_height = config.get("camera", {}).get("frame_height", 480)
        except Exception as e:
            logger.error(f"读取配置文件出错：{str(e)}")
    
    def reset_to_defaults(self):
        """恢复默认设置"""
        from PyQt5.QtWidgets import QMessageBox
        
        # 显示确认对话框
        reply = QMessageBox.question(self, "确认", "确定要恢复默认设置吗？所有设置将恢复为预设值。",
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            try:
                # 定义用户提供的精确默认设置
                default_config = {
                    "camera": {
                        "frame_width": 640,
                        "device_index": 0,
                        "frame_height": 480
                    },
                    "baidu_ai": {
                        "api_key": "L9AUgPB70roGfKSTeZezlz81",
                        "secret_key": "6muhTlsX8Deybve6k0fMSbfMNyfhULxp"
                    },
                    "app": {
                        "window_height": 600,
                        "window_width": 1200,
                        "warning_days": 3  # 添加保质期预警天数默认值
                    },
                    "recycle_bin": {
                        "retention_days": 30
                    },
                    "mcu_serial": {
                        "port": ""
                    },
                    "bing_search": {
                        "api_key": "your_bing_api_key_here"
                    },
                    "deepseek": {
                        "api_key": "sk-cf5ab955cbb049c8a567034de2e8d6f8"
                    },
                    "scanner": {
                        "device_id": ":770"
                    }
                }
                
                # 更新UI组件，不直接写入配置文件
                # 只有当用户点击"确认"按钮后，才会保存到配置文件
                
                # 更新API密钥输入框
                self.baidu_api_key_input.setText(default_config["baidu_ai"]["api_key"])
                self.baidu_secret_key_input.setText(default_config["baidu_ai"]["secret_key"])
                self.deepseek_api_key_input.setText(default_config["deepseek"]["api_key"])
                self.bing_search_api_key_input.setText(default_config["bing_search"]["api_key"])
                
                # 更新回收站保留天数
                self.retention_spinbox.setValue(default_config["recycle_bin"]["retention_days"])
                
                # 更新窗口设置
                self.window_width_spinbox.setValue(default_config["app"]["window_width"])
                self.window_height_spinbox.setValue(default_config["app"]["window_height"])
                
                # 更新保质期预警天数
                self.warning_days_spinbox.setValue(default_config["app"]["warning_days"])
                
                # 更新摄像头帧大小
                self.camera_frame_width_spinbox.setValue(default_config["camera"]["frame_width"])
                self.camera_frame_height_spinbox.setValue(default_config["camera"]["frame_height"])
                
                # 重置下拉框选择为默认值
                # 摄像头索引
                for i in range(self.camera_combobox.count()):
                    if self.camera_combobox.itemData(i) == default_config["camera"]["device_index"]:
                        self.camera_combobox.setCurrentIndex(i)
                        break
                
                # 扫码枪设备ID
                for i in range(self.scanner_combobox.count()):
                    if self.scanner_combobox.itemData(i) == default_config["scanner"]["device_id"]:
                        self.scanner_combobox.setCurrentIndex(i)
                        break
                else:
                    # 如果找不到匹配的设备ID，添加一个新项
                    self.scanner_combobox.addItem(f"设备 :770 (预设)", ":770")
                    self.scanner_combobox.setCurrentIndex(self.scanner_combobox.count() - 1)
                
                # MCU串口 - 设置为空
                for i in range(self.mcu_serial_combobox.count()):
                    if self.mcu_serial_combobox.itemData(i) == default_config["mcu_serial"]["port"]:
                        self.mcu_serial_combobox.setCurrentIndex(i)
                        break
                
                logger.info("已恢复默认设置")
                QMessageBox.information(self, "成功", "默认设置已恢复！")
            except Exception as e:
                logger.error(f"恢复默认设置出错：{str(e)}")
                QMessageBox.critical(self, "错误", f"恢复默认设置出错：{str(e)}")
    
    def save_settings(self):
        """保存设置"""
        # 获取用户输入的设置
        self.retention_days = self.retention_spinbox.value()
        self.warning_days = self.warning_days_spinbox.value()  # 获取保质期预警天数
        self.camera_index = self.camera_combobox.currentData()
        self.scanner_index = self.scanner_combobox.currentData()
        self.mcu_serial_port = self.mcu_serial_combobox.currentData()
        # API密钥
        self.baidu_api_key = self.baidu_api_key_input.text().strip()
        self.baidu_secret_key = self.baidu_secret_key_input.text().strip()
        self.deepseek_api_key = self.deepseek_api_key_input.text().strip()
        self.bing_search_api_key = self.bing_search_api_key_input.text().strip()
        # 窗口设置
        self.window_width = self.window_width_spinbox.value()
        self.window_height = self.window_height_spinbox.value()
        # 摄像头帧大小
        self.camera_frame_width = self.camera_frame_width_spinbox.value()
        self.camera_frame_height = self.camera_frame_height_spinbox.value()
        
        # 保存到配置文件
        try:
            import json
            import os
            # 读取现有配置
            config = {}
            if os.path.exists("data/config.json"):
                with open("data/config.json", "r", encoding="utf-8") as f:
                    config = json.load(f)
            
            # 更新配置
            if "recycle_bin" not in config:
                config["recycle_bin"] = {}
            config["recycle_bin"]["retention_days"] = self.retention_days
            
            if "camera" not in config:
                config["camera"] = {}
            config["camera"]["device_index"] = self.camera_index
            config["camera"]["frame_width"] = self.camera_frame_width
            config["camera"]["frame_height"] = self.camera_frame_height
            
            if "scanner" not in config:
                config["scanner"] = {}
            config["scanner"]["device_id"] = self.scanner_index
            
            if "mcu_serial" not in config:
                config["mcu_serial"] = {}
            config["mcu_serial"]["port"] = self.mcu_serial_port
            
            # API密钥配置
            if "baidu_ai" not in config:
                config["baidu_ai"] = {}
            config["baidu_ai"]["api_key"] = self.baidu_api_key
            config["baidu_ai"]["secret_key"] = self.baidu_secret_key
            
            if "deepseek" not in config:
                config["deepseek"] = {}
            config["deepseek"]["api_key"] = self.deepseek_api_key
            
            if "bing_search" not in config:
                config["bing_search"] = {}
            config["bing_search"]["api_key"] = self.bing_search_api_key
            
            # 窗口配置
            if "app" not in config:
                config["app"] = {}
            config["app"]["window_width"] = self.window_width
            config["app"]["window_height"] = self.window_height
            config["app"]["warning_days"] = self.warning_days  # 保存保质期预警天数
            
            # 写入配置文件
            with open("data/config.json", "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4, ensure_ascii=False)
            
            logger.info(f"保存设置成功，摄像头：{self.camera_index}，扫码枪：{self.scanner_index}，MCU串口：{self.mcu_serial_port}，回收站保留天数：{self.retention_days}天，保质期预警天数：{self.warning_days}天")
            QMessageBox.information(self, "成功", "设置保存成功！")
            self.accept()
        except Exception as e:
            logger.error(f"保存配置文件出错：{str(e)}")
            QMessageBox.critical(self, "错误", f"保存设置出错：{str(e)}")
