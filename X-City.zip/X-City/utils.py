#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
USB摄像头AI识别应用 - 工具类和共享配置
"""

import sys
import os
import logging
from datetime import datetime

# 解决macOS上的一些系统级错误
os.environ['QT_LOGGING_RULES'] = 'qt.qpa.input=false'
os.environ['QT_MAC_WANTS_LAYER'] = '1'
os.environ['PYQT5_NO_IM_CONTEXT'] = '1'
os.environ['QT_IM_MODULE'] = 'none'  # 禁用输入法模块，减少输入法相关错误
os.environ['QT_MAC_BLOCK_NATIVE_MENUBAR'] = '1'  # 阻止本地菜单栏，减少系统交互
os.environ['TSM_ADJUST_CAPS_LOCK_LED'] = '0'  # 禁用Caps Lock指示灯调整，减少TSM错误

# 配置日志系统
log_dir = 'logs'
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(log_dir, 'app.log'), encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)
