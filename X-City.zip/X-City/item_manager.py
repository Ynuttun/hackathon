#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
USB摄像头AI识别应用 - 物品管理模块
"""

import json
import os
from datetime import datetime
from PyQt5.QtWidgets import (QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
                            QMessageBox, QScrollArea, QDialog)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap

from utils import logger
from dialogs import ItemEditDialog

class ItemWidget(QWidget):
    """单个物品信息显示组件"""
    
    # 定义信号
    delete_signal = pyqtSignal(dict)
    edit_signal = pyqtSignal(dict)
    
    def __init__(self, item_data, parent=None):
        super().__init__(parent)
        self.item_data = item_data
        self.init_ui()
    
    def init_ui(self):
        """初始化UI组件"""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # 物品图片
        self.image_label = QLabel()
        self.image_label.setFixedSize(100, 100)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("border: 1px solid #ccc; background-color: #f0f0f0;")
        layout.addWidget(self.image_label)
        
        # 加载图片
        if os.path.exists(self.item_data['image_path']):
            pixmap = QPixmap(self.item_data['image_path'])
            scaled_pixmap = pixmap.scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.image_label.setPixmap(scaled_pixmap)
        else:
            self.image_label.setText("图片缺失")
        
        # 物品信息布局
        info_layout = QVBoxLayout()
        info_layout.setContentsMargins(10, 0, 0, 0)
        
        # 物品名称
        name_label = QLabel(f"<strong>物品名称：</strong>{self.item_data['name']}")
        name_label.setWordWrap(True)
        info_layout.addWidget(name_label)
        
        # 物品编号
        number_label = QLabel(f"<strong>物品编号：</strong>{self.item_data['number']}")
        info_layout.addWidget(number_label)
        
        # 入库时间
        time_label = QLabel(f"<strong>入库时间：</strong>{self.item_data['time']}")
        info_layout.addWidget(time_label)
        
        # 生产日期
        production_date_label = QLabel(f"<strong>生产日期：</strong>{self.item_data['production_date']}")
        info_layout.addWidget(production_date_label)
        
        # id_code
        id_code = self.item_data.get('id_code', '无')
        id_code_label = QLabel(f"<strong>id_code：</strong>{id_code}")
        info_layout.addWidget(id_code_label)
        
        # 位置
        position = self.item_data.get('position', 1)
        position_label = QLabel(f"<strong>位置：</strong>{position}")
        info_layout.addWidget(position_label)
        
        # 重量
        weight = self.item_data.get('weight', 100.0)
        weight_label = QLabel(f"<strong>重量：</strong>{weight}g")
        info_layout.addWidget(weight_label)
        
        # 保质期
        shelf_life_label = QLabel(f"<strong>保质期：</strong>{self.item_data['shelf_life']}天")
        info_layout.addWidget(shelf_life_label)
        
        # 到期日期
        expiry_label = QLabel(f"<strong>到期日期：</strong>{self.item_data['expiry_date']}")
        info_layout.addWidget(expiry_label)
        
        # 添加一些间距
        info_layout.addStretch()
        
        layout.addLayout(info_layout)
        
        # 操作按钮布局
        button_layout = QVBoxLayout()
        button_layout.setContentsMargins(10, 0, 0, 0)
        
        # 修改按钮
        self.edit_btn = QPushButton("修改")
        self.edit_btn.setFixedSize(80, 30)
        self.edit_btn.clicked.connect(self.on_edit_clicked)
        button_layout.addWidget(self.edit_btn)
        
        # 删除按钮
        self.delete_btn = QPushButton("删除")
        self.delete_btn.setFixedSize(80, 30)
        self.delete_btn.setStyleSheet("background-color: #ff4444; color: white;")
        self.delete_btn.clicked.connect(self.on_delete_clicked)
        button_layout.addWidget(self.delete_btn)
        
        layout.addLayout(button_layout)
        
        # 设置样式
        self.setStyleSheet("border-bottom: 1px solid #eee; padding: 5px 0;")
    
    def on_edit_clicked(self):
        """修改按钮点击事件"""
        self.edit_signal.emit(self.item_data)
    
    def on_delete_clicked(self):
        """删除按钮点击事件"""
        self.delete_signal.emit(self.item_data)

class ItemManagerDialog(QDialog):
    """物品管理对话框"""
    
    def __init__(self, items_data, parent=None):
        super().__init__(parent)
        self.setWindowTitle("物品管理")
        self.setModal(True)
        self.resize(800, 600)
        
        # 保存物品数据
        self.items_data = items_data
        # 初始化回收站
        self.recycle_bin = []
        self.load_recycle_bin()
        
        # 初始化UI
        self.init_ui()
    
    def load_recycle_bin(self):
        """加载回收站数据"""
        try:
            bin_filename = "data/recycle_bin.json"
            if os.path.exists(bin_filename):
                with open(bin_filename, "r", encoding="utf-8") as f:
                    self.recycle_bin = json.load(f)
        except Exception as e:
            logger.error(f"加载回收站数据出错：{str(e)}")
            self.recycle_bin = []
    
    def clean_expired_items(self):
        """清理过期物品"""
        logger.info("开始清理过期物品")
        
        # 获取保留天数，默认为3天
        retention_days = 3
        # 尝试从配置文件中读取保留天数
        try:
            with open("data/config.json", "r", encoding="utf-8") as f:
                config = json.load(f)
                retention_days = config.get("recycle_bin", {}).get("retention_days", 3)
        except Exception as e:
            logger.error(f"读取配置文件出错：{str(e)}")
        
        # 当前时间
        now = datetime.now()
        expired_items = []
        remaining_items = []
        
        # 检查每个物品是否过期
        for item in self.recycle_bin:
            deletion_time_str = item.get('deletion_time')
            if deletion_time_str:
                try:
                    deletion_time = datetime.fromisoformat(deletion_time_str)
                    # 计算删除时间到现在的天数差
                    days_diff = (now - deletion_time).days
                    if days_diff > retention_days:
                        # 物品已过期
                        expired_items.append(item)
                    else:
                        # 物品未过期
                        remaining_items.append(item)
                except ValueError:
                    # 日期格式错误，保留该物品
                    remaining_items.append(item)
            else:
                # 没有删除时间，保留该物品
                remaining_items.append(item)
        
        # 更新回收站列表
        self.recycle_bin = remaining_items
        
        # 删除过期物品的图片
        for item in expired_items:
            if os.path.exists(item['image_path']):
                try:
                    os.remove(item['image_path'])
                    logger.info(f"删除过期物品图片：{item['image_path']}")
                except Exception as e:
                    logger.error(f"删除图片出错：{str(e)}")
        
        logger.info(f"清理完成，删除了 {len(expired_items)} 个过期物品，剩余 {len(self.recycle_bin)} 个物品")
    
    def save_recycle_bin(self):
        """保存回收站数据"""
        try:
            # 清理过期物品
            self.clean_expired_items()
            
            bin_filename = "data/recycle_bin.json"
            with open(bin_filename, "w", encoding="utf-8") as f:
                json.dump(self.recycle_bin, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"保存回收站数据出错：{str(e)}")
    
    def init_ui(self):
        """初始化UI组件"""
        main_layout = QVBoxLayout(self)
        
        # 标题
        title_label = QLabel("在库物品列表")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; margin-bottom: 10px;")
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # 物品总数
        self.total_label = QLabel(f"共 {len(self.items_data)} 件物品")
        self.total_label.setAlignment(Qt.AlignCenter)
        self.total_label.setStyleSheet("margin-bottom: 10px; color: #666;")
        main_layout.addWidget(self.total_label)
        
        # 创建滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("border: 1px solid #ccc;")
        
        # 创建滚动区域内的容器
        scroll_widget = QWidget()
        self.items_layout = QVBoxLayout(scroll_widget)
        self.items_layout.setAlignment(Qt.AlignTop)
        
        # 添加物品列表
        self.add_items_to_layout()
        
        scroll_area.setWidget(scroll_widget)
        main_layout.addWidget(scroll_area, 1)
        
        # 按钮布局
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 10, 0, 0)
        
        # 一键删除按钮
        self.delete_all_btn = QPushButton("一键删除")
        self.delete_all_btn.setFixedSize(120, 30)
        self.delete_all_btn.setStyleSheet("background-color: #ff4444; color: white;")
        self.delete_all_btn.clicked.connect(self.delete_all_items)
        button_layout.addWidget(self.delete_all_btn)
        
        # 回收站按钮
        self.recycle_btn = QPushButton(f"回收站 ({len(self.recycle_bin)})")
        self.recycle_btn.setFixedSize(120, 30)
        self.recycle_btn.clicked.connect(self.open_recycle_bin)
        button_layout.addWidget(self.recycle_btn)
        
        button_layout.addStretch()
        
        # 关闭按钮
        close_btn = QPushButton("关闭")
        close_btn.setFixedSize(80, 30)
        close_btn.clicked.connect(self.close)
        button_layout.addWidget(close_btn)
        
        main_layout.addLayout(button_layout)
    
    def open_recycle_bin(self):
        """打开回收站"""
        logger.info("打开回收站")
        self.current_recycle_dialog = QDialog(self)
        self.current_recycle_dialog.setWindowTitle(f"回收站 ({len(self.recycle_bin)})")
        self.current_recycle_dialog.setModal(True)
        self.current_recycle_dialog.resize(600, 400)
        
        layout = QVBoxLayout(self.current_recycle_dialog)
        
        # 回收站标题
        bin_title = QLabel("最近删除的物品")
        bin_title.setStyleSheet("font-size: 16px; font-weight: bold; margin-bottom: 10px;")
        bin_title.setAlignment(Qt.AlignCenter)
        layout.addWidget(bin_title)
        
        # 滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("border: 1px solid #ccc;")
        
        self.bin_scroll_widget = QWidget()
        self.bin_layout = QVBoxLayout(self.bin_scroll_widget)
        self.bin_layout.setAlignment(Qt.AlignTop)
        
        # 显示回收站物品
        self.update_recycle_bin_display()
        
        scroll_area.setWidget(self.bin_scroll_widget)
        layout.addWidget(scroll_area, 1)
        
        # 按钮布局
        bin_buttons_layout = QHBoxLayout()
        
        # 一键恢复按钮
        restore_all_btn = QPushButton("一键恢复")
        restore_all_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        restore_all_btn.clicked.connect(self.restore_all_items)
        bin_buttons_layout.addWidget(restore_all_btn)
        
        # 清空按钮
        clear_btn = QPushButton("清空回收站")
        clear_btn.setStyleSheet("background-color: #ff4444; color: white;")
        clear_btn.clicked.connect(self.clear_recycle_bin)
        bin_buttons_layout.addWidget(clear_btn)
        
        bin_buttons_layout.addStretch()
        
        # 关闭按钮
        bin_close_btn = QPushButton("关闭")
        bin_close_btn.clicked.connect(self.current_recycle_dialog.close)
        bin_buttons_layout.addWidget(bin_close_btn)
        
        layout.addLayout(bin_buttons_layout)
        
        self.current_recycle_dialog.exec_()
    
    def clear_recycle_bin(self):
        """清空回收站"""
        logger.info("清空回收站")
        
        # 检查回收站是否为空
        if not self.recycle_bin:
            # 回收站为空，直接提示
            QMessageBox.information(self, "提示", "已清空回收站中的所有空气。")
            logger.info("回收站为空，无需清空")
            return
        
        # 回收站不为空，确认清空
        reply = QMessageBox.question(self, "确认清空", 
                                   "确定要清空回收站吗？此操作不可撤销，物品将永远消失。",
                                   QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            # 删除所有物品图片
            for item in self.recycle_bin:
                # 根据timestamp生成图片路径，而不是直接使用image_path字段
                timestamp = item.get('timestamp')
                if timestamp:
                    image_dir = "captured_images"
                    image_path = os.path.join(image_dir, f"{timestamp}.jpg")
                    if os.path.exists(image_path):
                        try:
                            os.remove(image_path)
                            logger.info(f"删除物品图片：{image_path}")
                        except Exception as e:
                            logger.error(f"删除图片出错：{str(e)}")
            
            # 清空回收站列表
            self.recycle_bin = []
            self.save_recycle_bin()
            
            # 更新显示
            self.update_recycle_bin_display()
            
            logger.info("回收站已清空")
    
    def restore_all_items(self):
        """恢复回收站中的所有物品"""
        logger.info("恢复所有物品")
        
        # 检查回收站是否为空
        if not self.recycle_bin:
            # 回收站为空，直接提示
            QMessageBox.information(self, "提示", "已恢复回收站中的所有空气。")
            logger.info("回收站为空")
            return
        
        # 确认恢复
        reply = QMessageBox.question(self, "确认恢复所有物品", 
                                   f"确定要恢复回收站中的所有 {len(self.recycle_bin)} 件物品吗？",
                                   QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            # 恢复所有物品
            for item_data in self.recycle_bin.copy():
                self.restore_item(item_data)
            
            # 更新显示
            self.update_recycle_bin_display()
            
            logger.info(f"已恢复所有 {len(self.recycle_bin)} 件物品")
            QMessageBox.information(self, "成功", f"已恢复所有 {len(self.recycle_bin)} 件物品。")
    
    def update_recycle_bin_display(self):
        """更新回收站物品显示"""
        # 清空现有布局
        for i in reversed(range(self.bin_layout.count())):
            item = self.bin_layout.itemAt(i)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
            else:
                # 处理布局项
                sub_layout = item.layout()
                if sub_layout is not None:
                    for j in reversed(range(sub_layout.count())):
                        sub_widget = sub_layout.itemAt(j).widget()
                        if sub_widget is not None:
                            sub_widget.deleteLater()
                    sub_layout.deleteLater()
        
        # 添加回收物品
        for i, item_data in enumerate(self.recycle_bin):
            item_layout = QHBoxLayout()
            
            # 构建物品信息，包括id_code
            id_code = item_data.get('id_code', '无')
            # 支持两种字段名：'name'（来自load_items_data）和'item_name'（直接从recognition_log.json）
            item_name = item_data.get('name', item_data.get('item_name', '未知物品'))
            # 支持两种字段名：'number'（来自load_items_data）和'item_number'（直接从recognition_log.json）
            item_number = item_data.get('number', item_data.get('item_number', 0))
            item_label = QLabel(f"{i+1}. {item_name} (编号: {item_number}, id_code: {id_code})")
            item_label.setWordWrap(True)
            item_layout.addWidget(item_label)
            
            # 恢复按钮
            restore_btn = QPushButton("恢复")
            restore_btn.setFixedSize(60, 25)
            restore_btn.clicked.connect(lambda checked, data=item_data: self.restore_item(data))
            item_layout.addWidget(restore_btn)
            
            self.bin_layout.addLayout(item_layout)
        
        if not self.recycle_bin:
            empty_label = QLabel("回收站为空")
            empty_label.setAlignment(Qt.AlignCenter)
            empty_label.setStyleSheet("color: #999; margin: 20px;")
            self.bin_layout.addWidget(empty_label)
        
        # 更新对话框标题
        if hasattr(self, 'current_recycle_dialog') and self.current_recycle_dialog.isVisible():
            self.current_recycle_dialog.setWindowTitle(f"回收站 ({len(self.recycle_bin)})")
        
        # 更新主窗口的回收站按钮
        self.recycle_btn.setText(f"回收站 ({len(self.recycle_bin)})")
    
    def restore_item(self, item_data):
        """恢复物品"""
        # 从recognition_log.json中获取的字段是item_name和item_number
        item_name = item_data.get('item_name', '未知物品')
        logger.info(f"恢复物品：{item_name}")
        
        # 获取当前所有物品数据
        current_items = self.parent().load_items_data()
        
        # 检查编号冲突
        item_number = int(item_data.get('item_number', 0))
        
        # 获取当前同名称物品的所有编号
        current_numbers = [int(item['number']) for item in current_items if item['name'] == item_name]
        
        if item_number in current_numbers:
            # 编号冲突，弹窗提示
            reply = QMessageBox.question(self, "编号冲突", 
                                       f"物品 '{item_name}' 的编号 {item_number} 已存在\n" 
                                       f"1. 将列表中的物品改为新编号\n" 
                                       f"2. 将恢复的物品改为新编号\n" 
                                       f"选择处理方式:",
                                       QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            
            if reply == QMessageBox.Yes:
                # 选项1: 将列表中的物品改为新编号
                # 找到冲突的物品
                for item in current_items:
                    if item['name'] == item_name and int(item['number']) == item_number:
                        # 生成新编号
                        new_number = self.get_next_available_number(item_name)
                        # 更新冲突物品
                        updated_item = item.copy()
                        updated_item['number'] = str(new_number)
                        self.update_item_in_log(updated_item)
                        logger.info(f"将现有物品 '{item_name}' 编号从 {item_number} 改为 {new_number}")
                        break
                # 恢复原物品
                self.add_item_to_log(item_data)
            else:
                # 选项2: 将恢复的物品改为新编号
                # 生成新编号
                new_number = self.get_next_available_number(item_name)
                # 更新恢复物品的编号
                item_data = item_data.copy()
                item_data['number'] = str(new_number)
                # 恢复更新后的物品
                self.add_item_to_log(item_data)
                logger.info(f"将恢复的物品 '{item_name}' 编号从 {item_number} 改为 {new_number}")
        else:
            # 无冲突，直接恢复
            self.add_item_to_log(item_data)
        
        # 将物品从回收站中移除
        self.recycle_bin = [item for item in self.recycle_bin if item != item_data]
        self.save_recycle_bin()
        # 更新回收站显示
        self.update_recycle_bin_display()
        # 重新加载物品数据
        self.items_data = self.parent().load_items_data()
        self.total_label.setText(f"共 {len(self.items_data)} 件物品")
        self.add_items_to_layout()
    
    def get_next_available_number(self, item_name):
        """获取下一个可用的物品编号，优先补缺少的编号"""
        # 获取当前所有物品数据
        current_items = self.parent().load_items_data()
        # 获取同名称物品的所有编号
        current_numbers = [int(item['number']) for item in current_items if item['name'] == item_name]
        
        if not current_numbers:
            return 1
        
        # 排序编号
        current_numbers.sort()
        
        # 查找缺少的最小编号
        for i in range(1, len(current_numbers) + 2):
            if i not in current_numbers:
                return i
        
        # 如果没有缺少的编号，返回最大编号+1
        return max(current_numbers) + 1
    
    def add_item_to_log(self, item_data):
        """将物品添加到日志文件"""
        try:
            json_filename = "data/recognition_log.json"
            
            # 读取现有数据
            items = []
            if os.path.exists(json_filename):
                with open(json_filename, "r", encoding="utf-8") as f:
                    items = json.load(f)
            
            # 处理从回收站恢复的物品数据，确保字段名正确
            # 从recognition_log.json中获取的字段是item_name和item_number
            # 但方法中可能传入的是处理后的物品数据，所以需要兼容两种情况
            timestamp = item_data.get('timestamp')
            item_name = item_data.get('name', item_data.get('item_name', '未知物品'))
            item_number = item_data.get('number', item_data.get('item_number', 0))
            
            # 创建新物品记录，保存所有必要字段
            new_item = {
                "timestamp": timestamp,
                "item_name": item_name,
                "item_number": item_number,
                "shelf_life_days": item_data.get('shelf_life_days', 30),
                "production_date": item_data.get('production_date', ''),
                "expiry_date": item_data.get('expiry_date', ''),
                "ean_code": item_data.get('ean_code'),
                "id_code": item_data.get('id_code'),
                "position": item_data.get('position', 1),  # 保存位置信息，默认1
                "weight": item_data.get('weight', 100.0)  # 保存重量信息，默认100g
            }
            
            # 添加到物品列表
            items.append(new_item)
            
            # 写入日志文件
            with open(json_filename, "w", encoding="utf-8") as f:
                json.dump(items, f, indent=4, ensure_ascii=False)
            
            logger.info(f"将物品添加到日志文件：{item_name}")
        except Exception as e:
            logger.error(f"将物品添加到日志文件出错：{str(e)}")
    
    def add_items_to_layout(self):
        """将物品添加到布局中"""
        # 清空现有布局
        for i in reversed(range(self.items_layout.count())):
            widget = self.items_layout.itemAt(i).widget()
            if widget is not None:
                widget.deleteLater()
        
        # 添加所有物品
        for item_data in self.items_data:
            item_widget = ItemWidget(item_data)
            # 连接信号
            item_widget.delete_signal.connect(self.on_item_delete)
            item_widget.edit_signal.connect(self.on_item_edit)
            self.items_layout.addWidget(item_widget)
        
        if not self.items_data:
            # 空列表提示
            empty_label = QLabel("暂无物品记录")
            empty_label.setAlignment(Qt.AlignCenter)
            empty_label.setStyleSheet("color: #999; margin: 50px;")
            self.items_layout.addWidget(empty_label)
        
        # 添加一个占位符，确保最后一个物品也能完整显示
        self.items_layout.addStretch()
    
    def on_item_delete(self, item_data):
        """处理物品删除"""
        logger.info(f"删除物品：{item_data['name']}")
        # 确认删除
        reply = QMessageBox.question(self, "确认删除", f"确定要删除物品 '{item_data['name']}' 吗？",
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            # 将物品添加到回收站，添加删除时间
            item_data_with_deletion_time = item_data.copy()
            item_data_with_deletion_time['deletion_time'] = datetime.now().isoformat()
            self.recycle_bin.append(item_data_with_deletion_time)
            self.save_recycle_bin()
            # 更新回收站按钮
            self.recycle_btn.setText(f"回收站 ({len(self.recycle_bin)})")
            
            # 从日志文件中删除该物品
            self.remove_item_from_log(item_data)
            
            # 重新加载物品数据
            self.items_data = self.parent().load_items_data()
            self.total_label.setText(f"共 {len(self.items_data)} 件物品")
            self.add_items_to_layout()
    
    def delete_all_items(self):
        """删除所有物品，将它们转移到回收站"""
        logger.info("删除所有物品")
        
        # 检查是否有物品可以删除
        if not self.items_data:
            QMessageBox.information(self, "提示", "已删除物品列表中的所有空气。")
            logger.info("物品列表为空，无需删除")
            return
        
        # 确认删除
        reply = QMessageBox.question(self, "确认删除所有物品", 
                                   f"确定要将所有 {len(self.items_data)} 件物品转移到回收站吗？",
                                   QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            # 将所有物品添加到回收站，添加删除时间
            deletion_time = datetime.now().isoformat()
            for item_data in self.items_data:
                item_data_with_deletion_time = item_data.copy()
                item_data_with_deletion_time['deletion_time'] = deletion_time
                self.recycle_bin.append(item_data_with_deletion_time)
            
            # 保存回收站数据
            self.save_recycle_bin()
            
            # 清空日志文件，因为所有物品都被删除了
            json_filename = "data/recognition_log.json"
            try:
                with open(json_filename, "w", encoding="utf-8") as f:
                    json.dump([], f)  # 写入空列表
                logger.info("已清空日志文件")
            except Exception as e:
                logger.error(f"清空日志文件出错：{str(e)}")
            
            # 重新加载物品数据（现在应该为空）
            self.items_data = self.parent().load_items_data()
            self.total_label.setText(f"共 {len(self.items_data)} 件物品")
            self.add_items_to_layout()
            
            # 更新回收站按钮
            self.recycle_btn.setText(f"回收站 ({len(self.recycle_bin)})")
            
            logger.info(f"已将 {len(self.recycle_bin)} 件物品转移到回收站")
            QMessageBox.information(self, "成功", f"已将 {len(self.recycle_bin)} 件物品转移到回收站。")
    
    def on_item_edit(self, item_data):
        """处理物品修改"""
        logger.info(f"修改物品：{item_data['name']}")
        # 打开修改对话框
        dialog = ItemEditDialog(item_data, self)
        if dialog.exec_() == QDialog.Accepted:
            # 获取更新后的数据
            updated_data = dialog.get_updated_data()
            # 更新日志文件
            self.update_item_in_log(updated_data)
            # 重新加载物品数据
            self.items_data = self.parent().load_items_data()
            self.total_label.setText(f"共 {len(self.items_data)} 件物品")
            self.add_items_to_layout()
    
    def remove_item_from_log(self, item_data):
        """从日志文件中删除物品"""
        try:
            json_filename = "data/recognition_log.json"
            if not os.path.exists(json_filename):
                return
            
            # 读取所有物品数据
            with open(json_filename, "r", encoding="utf-8") as f:
                items = json.load(f)
            
            # 过滤掉要删除的物品
            new_items = []
            for item in items:
                # 根据时间戳判断是否是要删除的物品
                if item['timestamp'] != item_data.get('timestamp', ''):
                    new_items.append(item)
            
            # 写入更新后的内容
            with open(json_filename, "w", encoding="utf-8") as f:
                json.dump(new_items, f, indent=4, ensure_ascii=False)
            
            logger.info(f"从日志文件中删除物品：{item_data['name']}")
        except Exception as e:
            logger.error(f"从日志文件中删除物品出错：{str(e)}")
    
    def update_item_in_log(self, item_data):
        """更新日志文件中的物品信息"""
        try:
            json_filename = "data/recognition_log.json"
            if not os.path.exists(json_filename):
                return
            
            # 读取所有物品数据
            with open(json_filename, "r", encoding="utf-8") as f:
                items = json.load(f)
            
            # 更新物品信息
            updated_items = []
            for item in items:
                # 根据时间戳判断是否是要更新的物品
                if item['timestamp'] == item_data.get('timestamp', ''):
                    # 重新计算到期日期
                    try:
                        from datetime import timedelta
                        # 解析修改后的生产日期
                        production_date = item_data.get('production_date', '')
                        if production_date:
                            # 使用修改后的生产日期计算到期日期
                            dt = datetime.strptime(production_date, "%Y-%m-%d")
                        else:
                            # 如果没有生产日期，使用入库时间
                            dt_str = item['timestamp'][:15]  # 取YYYYMMDD_HHMMSS部分
                            dt = datetime.strptime(dt_str, "%Y%m%d_%H%M%S")
                        
                        # 计算到期日期：生产日期 + 保质期天数 - 1 = 到期日期
                        # 例如：今天（0101）生产，保质期两天，到期日期为0102
                        expiry_dt = dt + timedelta(days=int(item_data['shelf_life']) - 1)
                        expiry_date_str = expiry_dt.strftime("%Y-%m-%d")
                        
                        # 更新物品信息
                        updated_item = item.copy()
                        updated_item['item_name'] = item_data['name']
                        updated_item['shelf_life_days'] = int(item_data['shelf_life'])
                        updated_item['production_date'] = production_date  # 保存修改后的生产日期
                        updated_item['expiry_date'] = expiry_date_str
                        updated_items.append(updated_item)
                    except ValueError as e:
                        logger.error(f"更新物品日期出错：{str(e)}")
                        updated_items.append(item)
                else:
                    updated_items.append(item)
            
            # 写入更新后的内容
            with open(json_filename, "w", encoding="utf-8") as f:
                json.dump(updated_items, f, indent=4, ensure_ascii=False)
            
            logger.info(f"更新日志文件中的物品：{item_data['name']}")
        except Exception as e:
            logger.error(f"更新日志文件中的物品出错：{str(e)}")
