#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os

# 转换recognition_log.txt到recognition_log.json
def convert_recognition_log():
    txt_filename = "recognition_log.txt"
    json_filename = "recognition_log.json"
    
    if not os.path.exists(txt_filename):
        print(f"{txt_filename} 不存在，跳过转换")
        return
    
    print(f"开始转换 {txt_filename} 到 {json_filename}")
    
    items = []
    try:
        with open(txt_filename, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            if line:
                parts = line.split(",")
                if len(parts) >= 4:
                    timestamp = parts[0]
                    item_name = parts[1]
                    item_number = parts[2]
                    expiry_date = parts[3]
                    
                    item = {
                        "timestamp": timestamp,
                        "item_name": item_name,
                        "item_number": item_number,
                        "expiry_date": expiry_date
                    }
                    items.append(item)
        
        with open(json_filename, "w", encoding="utf-8") as f:
            json.dump(items, f, indent=4, ensure_ascii=False)
        
        print(f"成功转换 {len(items)} 条记录到 {json_filename}")
    except Exception as e:
        print(f"转换 {txt_filename} 出错：{str(e)}")

# 转换shelf_life_records.txt到shelf_life_records.json
def convert_shelf_life_records():
    txt_filename = "shelf_life_records.txt"
    json_filename = "shelf_life_records.json"
    
    if not os.path.exists(txt_filename):
        print(f"{txt_filename} 不存在，跳过转换")
        return
    
    print(f"开始转换 {txt_filename} 到 {json_filename}")
    
    records = {}
    try:
        with open(txt_filename, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            if line:
                parts = line.split(",")
                if len(parts) == 2:
                    item_name = parts[0].strip()
                    shelf_life = parts[1].strip()
                    if shelf_life.isdigit():
                        records[item_name] = int(shelf_life)
        
        with open(json_filename, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=4, ensure_ascii=False)
        
        print(f"成功转换 {len(records)} 条记录到 {json_filename}")
    except Exception as e:
        print(f"转换 {txt_filename} 出错：{str(e)}")

if __name__ == "__main__":
    convert_recognition_log()
    print()
    convert_shelf_life_records()
    print("转换完成！")
